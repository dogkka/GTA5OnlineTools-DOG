-- mndy.lua [DOG 适配版]
-- 原版基于其作者菜单的 Lua API；本适配版改为兼容 YimMenuV2(DOG) 的 Lua API：
--   * 下划线小写 imgui 控件 -> 本菜单的 ImGui 大写控件（返回值顺序已按本菜单约定调整）
--   * 原 gui 注册回调 -> menu 注册回调（画成菜单内独立窗口 MNDY）
--   * 原网络"选中玩家"接口 -> players.get_selected（无选中时回退自己）

natives.load_natives()

-- [DOG 适配] 替换原版的"选中玩家"接口：
-- 使用菜单"玩家"页当前选中的玩家；没有选中/无效时回退为自己。
local function get_selected_player()
    local ok, sel = pcall(function() return players.get_selected() end)
    if ok and sel and sel:is_valid() then
        local id = sel:get_id()
        if id and id >= 0 and id <= 31 then
            return id
        end
    end
    return PLAYER.PLAYER_ID()
end

local LuaName = "MNDY"
notify.info("NewWay", LuaName .. " Loaded")

-- State (all local, no globals)
local bad_sport_combo = 0
local transaction_names = {"Bank", "Wallet"}
local selected_transaction_method = 0
local transfer_amount = 0
local stat_value = 1
local stat_name_int = ""
local stat_name_float = ""
local stat_name_bool = ""
local stat_amount_int = 0
local stat_amount_float = 0.0
local selected_bool = 0
local triggermode_names = {"Realistic", "Unreal"}
local stat_true_false = {"false", "true"}
local selected_triggermode = 0
local watermark_names = {"MNDY", "NewWayMenu.vip", "NewWay"}
local watermark_index = 0
local watermark_enabled = false
local force_populate = false
local weapon_controller = false
local triggerbot = false
local aimbot = false
local esp_box = false
local draw_lines = false
local health_box = false
local armour_box = false
local infinite_roll = false
local bug_roll = false
local hide_dot = false
local show_crosshair_always = false
local crosshair_plus = false
local crosshair_square = false
local crosshair_bracket = false
local give_casino_chips = false
local safe_club_loop = false
local rp_drops = false
local fast_rp = false
local include_self_all = false
local explode_all = false
local ragdoll_all = false
local burn_all = false
local raygun_all = false
local rattle_screen = false
local speedy_vehicle = false
local slow_vehicle = false

-- Cached session info (updated in callback)
local cached_player_count = 0
local cached_host_name = ""

local function mpx()
    local pi = stats.get_int("MPPLY_LAST_MP_CHAR")
    if pi == 0 then return "MP0_" else return "MP1_" end
end

local function format_money(value)
    return "$" .. tostring(value):reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end

local function get_player_count()
    return PLAYER.GET_NUMBER_OF_PLAYERS()
end

local function get_host_name()
    local host_idx = NETWORK.NETWORK_GET_HOST_PLAYER_INDEX()
    if host_idx and host_idx >= 0 then
        return PLAYER.GET_PLAYER_NAME(host_idx)
    end
    return "?"
end

-- Money transaction using ScriptGlobal (no globals API)
local transaction_global_base = 4537945
local function money_transaction(hash, amount)
    local g = ScriptGlobal.new(transaction_global_base)
    g:at(1):set_int(2147483646)
    g:at(7):set_int(2147483647)
    g:at(6):set_int(0)
    g:at(5):set_int(0)
    g:at(3):set_int(hash)
    g:at(2):set_int(amount)
    g:at(0):set_int(2)
end

local function run_script(name, bit)
    script.run_in_callback(function()
        SCRIPT.REQUEST_SCRIPT(name)
        while not SCRIPT.HAS_SCRIPT_LOADED(name) do
            script.yield(0)
        end
        SYSTEM.START_NEW_SCRIPT(name, bit)
        SCRIPT.SET_SCRIPT_AS_NO_LONGER_NEEDED(name)
    end)
end

local function drop_function(model_hash, pickup_hash, amount, value)
    script.run_in_callback(function()
        local player_ped = PLAYER.GET_PLAYER_PED(get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(player_ped, false)
        STREAMING.REQUEST_MODEL(model_hash)
        while not STREAMING.HAS_MODEL_LOADED(model_hash) do
            script.yield(0)
        end
        if STREAMING.HAS_MODEL_LOADED(model_hash) then
            for i = 1, amount do
                OBJECT.CREATE_AMBIENT_PICKUP(pickup_hash, coords.x, coords.y, coords.z + 2.2, 0, value, model_hash, true, false)
            end
            notify.info(LuaName, "Dropping for: " .. PLAYER.GET_PLAYER_NAME(get_selected_player()))
        end
    end)
end

local function shoot_at()
    local player_ped = PLAYER.GET_PLAYER_PED(get_selected_player())
    local my_ped = PLAYER.PLAYER_PED_ID()
    local coords = ENTITY.GET_ENTITY_COORDS(player_ped, false)
    local weap_hash = util.joaat("WEAPON_RPG")
    MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS_IGNORE_ENTITY(coords.x, coords.y, coords.z + 5.5, coords.x, coords.y, coords.z + 0.1, 1000, true, weap_hash, my_ped, true, true, -1, player_ped, true)
end

local function drop_vehicle_on_player(vehicle_name)
    script.run_in_callback(function()
        local player_ped = PLAYER.GET_PLAYER_PED(get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(player_ped, false)
        local hash = util.joaat(vehicle_name)
        STREAMING.REQUEST_MODEL(hash)
        while not STREAMING.HAS_MODEL_LOADED(hash) do
            script.yield(0)
        end
        local veh = VEHICLE.CREATE_VEHICLE(hash, coords.x, coords.y, coords.z + 4, 0, true, true, false)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
        script.yield(1700)
        if veh and ENTITY.DOES_ENTITY_EXIST(veh) then
            local e = Entity.new(veh)
            e:set_visible(false)
            e:set_position(Vector3.new(0, 0, -1000))
            e:delete()
        end
    end)
end

local function fling_vehicle()
    local player_ped = PLAYER.GET_PLAYER_PED(get_selected_player())
    local veh = PED.GET_VEHICLE_PED_IS_USING(player_ped)
    if veh and veh ~= 0 then
        script.run_in_callback(function()
            local e = Entity.new(veh)
            if e:request_control() then
                ENTITY.SET_ENTITY_VELOCITY(veh, 0, 0, -180)
                VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, math.random(-10000, 10000))
                ENTITY.APPLY_FORCE_TO_ENTITY(veh, 3, math.random(-4, 4), math.random(-4, 4), math.random(-80, 60), 0, 0, 0, true, true)
            end
            script.yield(0)
        end)
    end
end

local function help_marker(text)
    ImGui.SameLine()
    ImGui.TextWrapped("(?) " .. text)
end

local function draw_text(str, x, y, scale_x, scale_y)
    HUD.SET_TEXT_FONT(0)
    HUD.SET_TEXT_PROPORTIONAL(1)
    HUD.SET_TEXT_SCALE(scale_x or 0.2, scale_y or 0.2)
    HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 255)
    HUD.SET_TEXT_EDGE(1, 0, 0, 0, 255)
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(str)
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y)
end

local function script_host_name()
    return PLAYER.GET_PLAYER_NAME(NETWORK.NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0))
end

local function icon_notification(icon, icon2, flash, icon_type, title, text)
    HUD.BEGIN_TEXT_COMMAND_THEFEED_POST(" ")
    HUD.END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT(icon, icon2, false, icon_type, title, text)
end

local function shoot_player(ped_handle, height)
    script.run_in_callback(function()
        script.yield(0)
        local head = PED.GET_PED_BONE_COORDS(ped_handle, 31086, 0, 0, 0)
        PED.SET_PED_SHOOTS_AT_COORD(PLAYER.PLAYER_PED_ID(), head.x, head.y, head.z + (height or 0), 1)
        notify.warn(LuaName, "Shooting")
    end)
end

-- Bad Sport using ScriptGlobal (no globals API)
local function set_bad_sport(state, overall, is_bad)
    script.run_in_callback(function()
        notify.info("Bad Sport", "Awaiting session change")
        script.yield(1000)
        stats.set_int("MPPLY_BADSPORT_MESSAGE", state)
        stats.set_float("MPPLY_OVERALL_BADSPORT", overall)
        stats.set_bool("MPPLY_CHAR_IS_BADSPORT", is_bad)
        ScriptGlobal.new(1575035):set_int(11)
        local g89 = ScriptGlobal.new(1574589)
        g89:set_int(1)
        script.yield(300)
        g89:set_int(0)
    end)
end

-- Update session cache every second
script.run_in_callback(function()
    while true do
        cached_player_count = get_player_count()
        cached_host_name = get_host_name()
        script.yield(1000)
    end
end)

-- Main menu UI
menu.add_imgui(function()
    ImGui.Begin("MNDY")
    ImGui.Text("Welcome: " .. PLAYER.GET_PLAYER_NAME(PLAYER.PLAYER_ID()) .. " to " .. LuaName)
    ImGui.Text("Session: Players " .. cached_player_count .. "/32 | Host: " .. cached_host_name)
    ImGui.Separator()

    if ImGui.BeginTabBar("MNDYTabs") then

        -- Self tab
        if ImGui.BeginTabItem("Self") then
            ImGui.Spacing()

            if ImGui.CollapsingHeader("Bad Sport") then
                if ImGui.Button("Remove Bad Sport") then
                    set_bad_sport(0, 0, false)
                end
                ImGui.SameLine()
                if ImGui.Button("Add Bad Sport") then
                    set_bad_sport(1, 3000, true)
                end
            end

            if ImGui.CollapsingHeader("Mental State") then
                if ImGui.Button("0% Mental State") then
                    script.run_in_callback(function()
                        notify.info(LuaName, "Changing mental state")
                        script.yield(500)
                        STATS.STAT_SET_FLOAT(util.joaat("MP0_PLAYER_MENTAL_STATE"), 0, true)
                    end)
                end
                ImGui.SameLine()
                if ImGui.Button("100% Mental State") then
                    script.run_in_callback(function()
                        notify.info(LuaName, "Changing mental state")
                        script.yield(500)
                        STATS.STAT_SET_FLOAT(util.joaat("MP0_PLAYER_MENTAL_STATE"), 100, true)
                    end)
                end
            end

            if ImGui.CollapsingHeader("Money Transfer") then
                local mt0 = selected_transaction_method == 0
                local mt1 = selected_transaction_method == 1
                if ImGui.Selectable("Bank", mt0) then selected_transaction_method = 0 end
                if ImGui.Selectable("Wallet", mt1) then selected_transaction_method = 1 end
                local tv, tc = ImGui.SliderInt("Amount", transfer_amount, 0, 2147483646)
                if tc then transfer_amount = tv end
                if ImGui.Button("Transfer") then
                    script.run_in_callback(function()
                        local idx = stats.get_int("MPPLY_LAST_MP_CHAR") == 0 and 0 or 1
                        if selected_transaction_method == 0 then
                            notify.warn(LuaName, "Transferring $" .. transfer_amount .. " to bank")
                            script.yield(1000)
                            NETSHOPPING.NET_GAMESERVER_TRANSFER_WALLET_TO_BANK(idx, transfer_amount)
                        else
                            notify.warn(LuaName, "Transferring $" .. transfer_amount .. " to wallet")
                            script.yield(1000)
                            NETSHOPPING.NET_GAMESERVER_TRANSFER_BANK_TO_WALLET(idx, transfer_amount)
                        end
                    end)
                end
            end

            if ImGui.CollapsingHeader("Misc") then
                if ImGui.Button("Unlock Fast Run") then
                    local px = mpx()
                    STATS.STAT_SET_INT(util.joaat(px .. "CHAR_ABILITY_1_UNLCK"), -1, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "CHAR_ABILITY_2_UNLCK"), -1, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "CHAR_ABILITY_3_UNLCK"), -1, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "CHAR_FM_ABILITY_1_UNLCK"), -1, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "CHAR_FM_ABILITY_2_UNLCK"), -1, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "CHAR_FM_ABILITY_3_UNLCK"), -1, true)
                    notify.info(LuaName, "Unlocked Fast Run")
                end
                ImGui.SameLine()
                if ImGui.Button("Unlock 77 Achievements") then
                    script.run_in_callback(function()
                        for i = 0, 77 do
                            script.yield(200)
                            PLAYER.GIVE_ACHIEVEMENT_TO_PLAYER(i)
                            if i == 77 then
                                notify.info("Achievements", "Unlocked 77 achievements")
                            end
                        end
                    end)
                end
                if ImGui.Button("Refill Snacks x300") then
                    local px = mpx()
                    STATS.STAT_SET_INT(util.joaat(px .. "NO_BOUGHT_YUM_SNACKS"), 300, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "NO_BOUGHT_HEALTH_SNACKS"), 300, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "NO_BOUGHT_EPIC_SNACKS"), 300, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "NUMBER_OF_CHAMP_BOUGHT"), 300, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "NUMBER_OF_ORANGE_BOUGHT"), 300, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "NUMBER_OF_BOURGE_BOUGHT"), 300, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "NUMBER_OF_SPRUNK_BOUGHT"), 300, true)
                    STATS.STAT_SET_INT(util.joaat(px .. "CIGARETTES_BOUGHT"), 300, true)
                    icon_notification("CHAR_FILMNOIR", "CHAR_FILMNOIR", true, 1, LuaName, "Snacks given")
                end
                ImGui.SameLine()
                if ImGui.Button("Remove Orbital Cooldown") then
                    STATS.STAT_SET_INT(util.joaat(mpx() .. "ORBITAL_CANNON_COOLDOWN"), 0, true)
                    icon_notification("CHAR_LESTER", "CHAR_LESTER", true, 1, LuaName, "Cooldown removed")
                end
                help_marker("Removes cooldown to fire again")
                local cv, cp = ImGui.Checkbox("Force Population", force_populate)
                if cp then force_populate = cv end
                for i, name in ipairs(watermark_names) do
                    if ImGui.Selectable(name, watermark_index == i - 1) then watermark_index = i - 1 end
                end
                local wv, wc = ImGui.Checkbox("Watermark", watermark_enabled)
                if wc then watermark_enabled = wv end
                if ImGui.Button("Add Snow") then
                    ScriptGlobal.new(262145 + 4413):set_int(1)
                end
                ImGui.SameLine()
                if ImGui.Button("Remove Snow") then
                    ScriptGlobal.new(262145 + 4413):set_int(0)
                end
            end

            if ImGui.CollapsingHeader("Debug") then
                local wv, wc = ImGui.Checkbox("Weapon Controller", weapon_controller)
                if wc then weapon_controller = wv end
                local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), false)
                ImGui.Text("Location: " .. pos.x .. " " .. pos.y .. " " .. pos.z)
                if ImGui.Button("Show GTA build (notification)") then
                    notify.info(LuaName, "Build info – see game version in pause menu")
                end
            end

            ImGui.EndTabItem()
        end

        -- Events tab (placeholder)
        if ImGui.BeginTabItem("Events") then
            ImGui.Text("Coming soon")
            ImGui.EndTabItem()
        end

        -- PvP tab
        if ImGui.BeginTabItem("PvP") then
            ImGui.Spacing()
            if ImGui.CollapsingHeader("Aimbot / Triggerbot") then
                for i, name in ipairs(triggermode_names) do
                    if ImGui.Selectable(name, selected_triggermode == i - 1) then selected_triggermode = i - 1 end
                end
                local tv, tc = ImGui.Checkbox("Triggerbot", triggerbot)
                if tc then triggerbot = tv end
                ImGui.SameLine()
                local av, ac = ImGui.Checkbox("Aimbot", aimbot)
                if ac then aimbot = av end
            end
            if ImGui.CollapsingHeader("Visuals") then
                local ev, ec = ImGui.Checkbox("ESP", esp_box)
                if ec then esp_box = ev end
                ImGui.SameLine()
                local dv, dc = ImGui.Checkbox("Draw Lines", draw_lines)
                if dc then draw_lines = dv end
                local hv, hc = ImGui.Checkbox("Health", health_box)
                if hc then health_box = hv end
                local av, ac = ImGui.Checkbox("Armour", armour_box)
                if ac then armour_box = av end
            end
            if ImGui.CollapsingHeader("Movement") then
                local iv, ic = ImGui.Checkbox("Infinite Roll", infinite_roll)
                if ic then infinite_roll = iv end
                help_marker("Removes roll wait")
                local bv, bc = ImGui.Checkbox("Bug Roll", bug_roll)
                if bc then bug_roll = bv end
            end
            if ImGui.CollapsingHeader("Crosshairs") then
                local hv, hc = ImGui.Checkbox("Hide Dot", hide_dot)
                if hc then hide_dot = hv end
                ImGui.SameLine()
                local sv, sc = ImGui.Checkbox("Show at all times", show_crosshair_always)
                if sc then show_crosshair_always = sv end
                local pv, pc = ImGui.Checkbox("Crosshair (+)", crosshair_plus)
                if pc then crosshair_plus = pv end
                ImGui.SameLine()
                local sqv, sqc = ImGui.Checkbox("Crosshair (Square)", crosshair_square)
                if sqc then crosshair_square = sqv end
                local brv, brc = ImGui.Checkbox("Crosshair ({ })", crosshair_bracket)
                if brc then crosshair_bracket = brv end
            end
            ImGui.EndTabItem()
        end

        -- Recovery tab
        if ImGui.BeginTabItem("Recovery") then
            ImGui.Spacing()
            if ImGui.CollapsingHeader("Loops") then
                local gv, gc = ImGui.Checkbox("5K Chips", give_casino_chips)
                if gc then give_casino_chips = gv end
            end
            ImGui.EndTabItem()
        end

        -- Business tab
        if ImGui.BeginTabItem("Business") then
            ImGui.Spacing()
            if ImGui.CollapsingHeader("Nightclub") then
                local safe = stats.get_int(mpx() .. "CLUB_SAFE_CASH_VALUE")
                local earnings = stats.get_int(mpx() .. "NIGHTCLUB_EARNINGS")
                local pop = stats.get_int(mpx() .. "CLUB_POPULARITY")
                local time_left = stats.get_int(mpx() .. "CLUB_PAY_TIME_LEFT")
                ImGui.Text("Popularity: " .. (pop / 10) .. "/100%")
                ImGui.Text("Safe: " .. format_money(safe))
                ImGui.Text("Earnings: " .. format_money(earnings))
                ImGui.Text("Time till pay: " .. time_left)
                local sv, sc = ImGui.Checkbox("Auto Fill Safe", safe_club_loop)
                if sc then safe_club_loop = sv end
                if ImGui.Button("Computer") then
                    run_script("appBusinessHub", 1424)
                end
            end
            ImGui.EndTabItem()
        end

        -- Player Options tab (no TSE; keep native-only actions)
        if ImGui.BeginTabItem("Player Options") then
            ImGui.Spacing()
            ImGui.Text("Selected: " .. PLAYER.GET_PLAYER_NAME(get_selected_player()))
            ImGui.Separator()
            if ImGui.CollapsingHeader("RP") then
                local rv, rc = ImGui.Checkbox("Drop RP", rp_drops)
                if rc then rp_drops = rv end
            end
            if ImGui.CollapsingHeader("Toxic (no TSE)") then
                if ImGui.Button("Rage Shoot") then shoot_at() end
                ImGui.SameLine()
                if ImGui.Button("Drop Bus on Player") then drop_vehicle_on_player("bus") end
                ImGui.SameLine()
                if ImGui.Button("Fling Vehicle") then fling_vehicle() end
            end
            ImGui.EndTabItem()
        end

        -- Stats tab
        if ImGui.BeginTabItem("Stats") then
            ImGui.Spacing()
            if ImGui.CollapsingHeader("Stat type") then
                if ImGui.Selectable("INT", stat_value == 1) then stat_value = 1 end
                if ImGui.Selectable("FLOAT", stat_value == 2) then stat_value = 2 end
                if ImGui.Selectable("BOOL", stat_value == 3) then stat_value = 3 end
            end
            if stat_value == 1 then
                local nv, nc = ImGui.InputTextWithHint("Hash (INT)", "e.g. MPPLY_KILLS_PLAYERS", stat_name_int)
                if nc then stat_name_int = nv end
                local av, ac = ImGui.SliderInt("Amount", stat_amount_int, 0, 2147483646)
                if ac then stat_amount_int = av end
                if ImGui.Button("Update INT") then
                    STATS.STAT_SET_INT(util.joaat(stat_name_int), stat_amount_int, true)
                    notify.warn(LuaName, "Updated: " .. stat_name_int .. " = " .. stat_amount_int)
                end
            elseif stat_value == 2 then
                local nv, nc = ImGui.InputTextWithHint("Hash (FLOAT)", "e.g. MPPLY_KILL_DEATH_RATIO", stat_name_float)
                if nc then stat_name_float = nv end
                local av, ac = ImGui.SliderFloat("Amount", stat_amount_float, 0, 1000)
                if ac then stat_amount_float = av end
                if ImGui.Button("Update FLOAT") then
                    STATS.STAT_SET_FLOAT(util.joaat(stat_name_float), stat_amount_float, true)
                    notify.warn(LuaName, "Updated: " .. stat_name_float .. " = " .. stat_amount_float)
                end
            else
                local nv, nc = ImGui.InputTextWithHint("Hash (BOOL)", "e.g. MPX_AWD_WIZHARD", stat_name_bool)
                if nc then stat_name_bool = nv end
                if ImGui.Selectable("false", selected_bool == 0) then selected_bool = 0 end
                if ImGui.Selectable("true", selected_bool == 1) then selected_bool = 1 end
                if ImGui.Button("Update BOOL") then
                    stats.set_bool(stat_name_bool, selected_bool == 1)
                    notify.warn(LuaName, "Updated: " .. stat_name_bool .. " = " .. tostring(selected_bool == 1))
                end
            end
            ImGui.EndTabItem()
        end

        -- All Players tab (no TSE; native-only loops)
        if ImGui.BeginTabItem("All Players") then
            ImGui.Spacing()
            ImGui.Separator()
            ImGui.Text("Settings")
            local inv, inc = ImGui.Checkbox("Include Self", include_self_all)
            if inc then include_self_all = inv end
            ImGui.Separator()
            ImGui.Text("Effects (natives only)")
            local ev, ec = ImGui.Checkbox("Explode All", explode_all)
            if ec then explode_all = ev end
            ImGui.SameLine()
            local rv, rc = ImGui.Checkbox("Ragdoll All", ragdoll_all)
            if rc then ragdoll_all = rv end
            local bv, bc = ImGui.Checkbox("Burn All", burn_all)
            if bc then burn_all = bv end
            ImGui.SameLine()
            local ryv, ryc = ImGui.Checkbox("Raygun All", raygun_all)
            if ryc then raygun_all = ryv end
            local rsv, rsc = ImGui.Checkbox("Rattle Screen", rattle_screen)
            if rsc then rattle_screen = rsv end
            local spv, spc = ImGui.Checkbox("Speedy Vehicle", speedy_vehicle)
            if spc then speedy_vehicle = spv end
            ImGui.SameLine()
            local slv, slc = ImGui.Checkbox("Slow Vehicle", slow_vehicle)
            if slc then slow_vehicle = slv end
            ImGui.Separator()
            ImGui.Text("Teleports (local player)")
            if ImGui.Button("Comedy Room") then
                script.run_in_callback(function()
                    local ped = PLAYER.PLAYER_PED_ID()
                    ENTITY.SET_ENTITY_COORDS(ped, 380.585, -1000.17566, -99.000015, false, false, true, true)
                end)
            end
            ImGui.SameLine()
            if ImGui.Button("Mugshot Room") then
                script.run_in_callback(function()
                    local ped = PLAYER.PLAYER_PED_ID()
                    ENTITY.SET_ENTITY_COORDS(ped, 399.26633, -1004.46765, -99.00412, false, false, true, true)
                end)
            end
            ImGui.SameLine()
            if ImGui.Button("Jail Cell") then
                script.run_in_callback(function()
                    local ped = PLAYER.PLAYER_PED_ID()
                    ENTITY.SET_ENTITY_COORDS(ped, 459.72223, -994.1862, 24.914667, false, false, true, true)
                end)
            end
            if ImGui.Button("Mount Chiliad") then
                script.run_in_callback(function()
                    local ped = PLAYER.PLAYER_PED_ID()
                    ENTITY.SET_ENTITY_COORDS(ped, 501.403, 5598.647, 796.137, false, false, true, true)
                end)
            end
            ImGui.EndTabItem()
        end

        ImGui.EndTabBar()
    end
    ImGui.End()
end)

-- Loops and overlays run in callback
script.run_in_callback(function()
    local local_player_id = PLAYER.PLAYER_ID()
    while true do
        script.yield(0)

        -- Force populate
        if force_populate then
            MISC.POPULATE_NOW()
        end

        -- Watermark overlay
        if watermark_enabled then
            local offset_x, offset_y = 0.6, 0.001
            HUD.SET_TEXT_FONT(0)
            HUD.SET_TEXT_SCALE(0.25, 0.25)
            HUD.SET_TEXT_CENTRE(false)
            HUD.SET_TEXT_DROPSHADOW(2, 2, 0, 0, 0)
            HUD.SET_TEXT_EDGE(1, 0, 0, 0, 205)
            HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
            HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~ws~" .. watermark_names[watermark_index + 1] .. " | " .. PLAYER.GET_PLAYER_NAME(local_player_id) .. " | " .. cached_player_count .. " | Host: " .. cached_host_name .. " | ScriptHost: " .. script_host_name())
            GRAPHICS.DRAW_RECT(offset_x + 0.187, offset_y, 0.39, 0.049, 0, 0, 0, 125, 0)
            HUD.END_TEXT_COMMAND_DISPLAY_TEXT(offset_x, offset_y)
        end

        -- Give casino chips loop (ScriptGlobal)
        if give_casino_chips then
            ScriptGlobal.new(1965183):set_int(1)
            script.yield(500)
        end

        -- Nightclub safe loop
        if safe_club_loop then
            STATS.STAT_SET_INT(util.joaat(mpx() .. "CLUB_POPULARITY"), 1000, true)
            script.yield(200)
            STATS.STAT_SET_INT(util.joaat(mpx() .. "CLUB_PAY_TIME_LEFT"), -1, true)
            script.yield(1900)
        end

        -- RP drops (pickups only)
        if rp_drops then
            drop_function(util.joaat("vw_prop_vw_colle_pogo"), util.joaat("PICKUP_CUSTOM_SCRIPT"), 4, 0)
            script.yield(200)
            drop_function(util.joaat("vw_prop_vw_colle_beast"), util.joaat("PICKUP_CUSTOM_SCRIPT"), 4, 0)
            script.yield(200)
            drop_function(util.joaat("vw_prop_vw_colle_sasquatch"), util.joaat("PICKUP_CUSTOM_SCRIPT"), 4, 0)
            script.yield(200)
            drop_function(util.joaat("vw_prop_vw_colle_prbubble"), util.joaat("PICKUP_CUSTOM_SCRIPT"), 4, 0)
            script.yield(200)
            drop_function(util.joaat("vw_prop_vw_colle_imporage"), util.joaat("PICKUP_CUSTOM_SCRIPT"), 4, 0)
            script.yield(200)
            drop_function(util.joaat("vw_prop_vw_colle_rsrcomm"), util.joaat("PICKUP_CUSTOM_SCRIPT"), 4, 0)
            script.yield(200)
            drop_function(util.joaat("vw_prop_vw_lux_card_01a"), util.joaat("PICKUP_CUSTOM_SCRIPT"), 4, 0)
            script.yield(200)
        end

        -- Weapon controller (debug)
        if weapon_controller then
            local found, obj = PLAYER.GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(PLAYER.PLAYER_ID())
            if found and obj then
                local pos = ENTITY.GET_ENTITY_COORDS(obj, false)
                GRAPHICS.DRAW_MARKER_SPHERE(pos.x, pos.y, pos.z, 1, 0, 255, 0, 0.3)
                draw_text("Aiming: " .. ENTITY.GET_ENTITY_MODEL(obj), 0.4738, 0.505, 0.2, 0.2)
                draw_text("E=delete Q=fling", 0.4798, 0.517, 0.2, 0.2)
                if PAD.IS_CONTROL_JUST_PRESSED(0, 38) then
                    local e = Entity.new(obj)
                    e:delete()
                end
                if PAD.IS_CONTROL_JUST_PRESSED(0, 52) then
                    local e = Entity.new(obj)
                    e:force_control()
                    ENTITY.SET_ENTITY_VELOCITY(obj, math.random(-180, 180), math.random(-180, 180), math.random(-180, 180))
                end
            end
        end

        -- Triggerbot
        if triggerbot then
            local found, entity = PLAYER.GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(PLAYER.PLAYER_ID())
            if found and entity and ENTITY.IS_ENTITY_A_PED(entity) and not PED.IS_PED_DEAD_OR_DYING(entity, 0) and PED.IS_PED_A_PLAYER(entity) then
                local h = (selected_triggermode == 1) and 0.63 or math.random(0, 1)
                shoot_player(entity, h)
            end
            script.yield(1)
        end

        -- Aimbot
        if aimbot then
            if PLAYER.IS_PLAYER_FREE_AIMING(PLAYER.PLAYER_ID()) then
                for i = 0, 32 do
                    if i ~= local_player_id then
                        local target = PLAYER.GET_PLAYER_PED(i)
                        if target and target ~= PLAYER.PLAYER_PED_ID() then
                            local pos = ENTITY.GET_ENTITY_COORDS(target, false)
                            if ENTITY.DOES_ENTITY_EXIST(target) and not PLAYER.IS_PLAYER_DEAD(i) then
                                local on_screen, sx, sy = GRAPHICS.GET_SCREEN_COORD_FROM_WORLD_COORD(pos.x, pos.y, pos.z, 0)
                                if ENTITY.IS_ENTITY_VISIBLE(target) and on_screen and ENTITY.HAS_ENTITY_CLEAR_LOS_TO_ENTITY(PLAYER.PLAYER_PED_ID(), target, 17) then
                                    local head = PED.GET_PED_BONE_COORDS(target, 31086, 0, 0, 0)
                                    PED.SET_PED_SHOOTS_AT_COORD(PLAYER.PLAYER_PED_ID(), head.x, head.y, head.z, 1)
                                    break
                                end
                            end
                        end
                    end
                end
            end
            script.yield(1)
        end

        -- Hide dot
        if hide_dot then
            HUD.HIDE_HUD_COMPONENT_THIS_FRAME(14)
        end

        -- Crosshairs
        if crosshair_plus and (show_crosshair_always or PLAYER.IS_PLAYER_FREE_AIMING(PLAYER.PLAYER_ID())) then
            draw_text("+", 0.496, 0.481, 0, 0.4)
        end
        if crosshair_square and (show_crosshair_always or PLAYER.IS_PLAYER_FREE_AIMING(PLAYER.PLAYER_ID())) then
            draw_text("☐", 0.4972, 0.491, 0.2, 0.2)
        end
        if crosshair_bracket and (show_crosshair_always or PLAYER.IS_PLAYER_FREE_AIMING(PLAYER.PLAYER_ID())) then
            draw_text("{ }", 0.496, 0.481, 0, 0.4)
        end

        -- Infinite roll
        if infinite_roll then
            for i = 0, 32 do
                STATS.STAT_SET_INT(util.joaat("mp" .. i .. "_shooting_ability"), 190, true)
            end
        end

        -- Bug roll
        if bug_roll and PLAYER.IS_PLAYER_FREE_AIMING(PLAYER.PLAYER_ID()) and PAD.IS_CONTROL_PRESSED(0, 22) then
            notify.warn(LuaName, "Bug roll")
            script.yield(500)
            local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), false)
            ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), pos.x + math.random(-4, 4), pos.y + math.random(-2, 2), pos.z - 1, false, false, true, true)
        end

        -- Draw lines to players
        if draw_lines then
            script.yield(100)
            local my_ped = PLAYER.PLAYER_PED_ID()
            local my_pos = ENTITY.GET_ENTITY_COORDS(my_ped, false)
            for i = 0, 32 do
                if i ~= local_player_id then
                    local target = PLAYER.GET_PLAYER_PED(i)
                    if target and target ~= my_ped then
                        local pos = ENTITY.GET_ENTITY_COORDS(target, false)
                        local z_off = PED.IS_PED_IN_ANY_VEHICLE(my_ped) and 6.7 or 2.7
                        GRAPHICS.DRAW_LINE(pos.x, pos.y, pos.z, my_pos.x, my_pos.y, my_pos.z + z_off, 0, 255, 50, 255)
                    end
                end
            end
        end

        -- ESP
        if esp_box then
            script.yield(100)
            if NETWORK.NETWORK_IS_IN_SESSION() then
                local cam = CAM.GET_GAMEPLAY_CAM_COORD()
                for i = 0, 32 do
                    local target = PLAYER.GET_PLAYER_PED(i)
                    if target and target ~= PLAYER.PLAYER_PED_ID() and not PED.IS_PED_DEAD_OR_DYING(target, 0) then
                        local bone = ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(target, 31086)
                        local pos = PED.GET_PED_BONE_COORDS(target, bone, 0, 0, 0.9)
                        if MISC.GET_DISTANCE_BETWEEN_COORDS(pos.x, pos.y, pos.z, cam.x, cam.y, cam.z, true) < 1000 and ENTITY.IS_ENTITY_ON_SCREEN(target) then
                            local dist = (MISC.GET_DISTANCE_BETWEEN_COORDS(pos.x, pos.y, pos.z, cam.x, cam.y, cam.z, true) * 0.002) / 2
                            local ok, sx, sy = GRAPHICS.GET_SCREEN_COORD_FROM_WORLD_COORD(pos.x, pos.y, pos.z)
                            if ok then
                                local w, h = 0.00045 / dist, 0.0023 / dist
                                GRAPHICS.DRAW_RECT(sx, sy, w, 0.0015, 0, 0, 255, 200)
                                GRAPHICS.DRAW_RECT(sx, sy + h, w, 0.0015, 0, 0, 255, 200)
                                GRAPHICS.DRAW_RECT(sx + w/2, sy + h/2, 0.001, h, 0, 0, 255, 200)
                                GRAPHICS.DRAW_RECT(sx - w/2, sy + h/2, 0.001, h, 0, 0, 255, 200)
                                draw_text(PLAYER.GET_PLAYER_NAME(i), sx + 0.007, sy, 0.2, 0.2)
                                if health_box then draw_text("Health: " .. ENTITY.GET_ENTITY_HEALTH(target), sx + 0.007, sy + 0.01, 0.2, 0.2) end
                                if armour_box then draw_text("Armour: " .. PED.GET_PED_ARMOUR(target), sx + 0.007, sy + 0.02, 0.2, 0.2) end
                            end
                        end
                    end
                end
            end
        end

        -- All Players: explode / ragdoll / burn / raygun / rattle / speedy / slow (natives only)
        for i = 0, 32 do
            local target_ped = PLAYER.GET_PLAYER_PED(i)
            if not target_ped or target_ped == 0 then goto continue end
            if not include_self_all and i == local_player_id then goto continue end
            local pos = ENTITY.GET_ENTITY_COORDS(target_ped, false)
            if not pos then goto continue end
            if explode_all then
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z, 2, 100000, true, false, 0, false)
                GRAPHICS.USE_PARTICLE_FX_ASSET("core")
                GRAPHICS.START_PARTICLE_FX_NON_LOOPED_AT_COORD("explosion_barrel", pos.x, pos.y, pos.z, 0, 0, 0, 1, false, true, false)
            end
            if ragdoll_all then
                local p = {x = pos.x, y = pos.y, z = pos.z - 2}
                FIRE.ADD_EXPLOSION(p.x, p.y, p.z, 11, 1, false, true, 100, false)
            end
            if burn_all then
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z + 0.8, 3, 1, true, false, 1, false)
            end
            if raygun_all then
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z + 0.8, 70, 1, true, false, 1, false)
            end
            if rattle_screen then
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z + 0.8, 74, 1, true, false, 1, false)
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z + 0.8, 75, 1, true, false, 1, false)
            end
            if speedy_vehicle and PED.IS_PED_IN_ANY_VEHICLE(target_ped) then
                local veh = PED.GET_VEHICLE_PED_IS_USING(target_ped)
                local vpos = ENTITY.GET_ENTITY_COORDS(veh, false)
                local model = util.joaat("stt_prop_track_speedup_t1")
                STREAMING.REQUEST_MODEL(model)
                if STREAMING.HAS_MODEL_LOADED(model) then
                    local obj = OBJECT.CREATE_OBJECT(model, vpos.x, vpos.y, vpos.z - 2.6, true, false, false)
                    if obj and ENTITY.DOES_ENTITY_EXIST(obj) then
                        ENTITY.SET_ENTITY_HEADING(obj, ENTITY.GET_ENTITY_HEADING(veh) - 90)
                        script.yield(1)
                        OBJECT.DELETE_OBJECT(obj)
                    end
                end
            end
            if slow_vehicle and PED.IS_PED_IN_ANY_VEHICLE(target_ped) then
                local veh = PED.GET_VEHICLE_PED_IS_USING(target_ped)
                local vpos = ENTITY.GET_ENTITY_COORDS(veh, false)
                local model = util.joaat("stt_prop_track_slowdown")
                STREAMING.REQUEST_MODEL(model)
                if STREAMING.HAS_MODEL_LOADED(model) then
                    local obj = OBJECT.CREATE_OBJECT(model, vpos.x, vpos.y, vpos.z - 2, true, false, false)
                    if obj and ENTITY.DOES_ENTITY_EXIST(obj) then
                        ENTITY.SET_ENTITY_HEADING(obj, ENTITY.GET_ENTITY_HEADING(veh) - 90)
                        script.yield(1)
                        OBJECT.DELETE_OBJECT(obj)
                    end
                end
            end
            ::continue::
        end
        if explode_all or ragdoll_all or burn_all or raygun_all or rattle_screen or speedy_vehicle or slow_vehicle then
            script.yield(1)
        end
    end
end)
