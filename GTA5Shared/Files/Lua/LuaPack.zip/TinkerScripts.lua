--[[

	This file is part of TinkerScripts.
	Copyright (C) 2026 ImagineNothing

	TinkerScripts is free software. You can redistribute it and/or modify it
	under the terms of the GNU GPLv3 (or later), as published by the Free Software Foundation:

	see LICENSE or <https://www.gnu.org/licenses/> for all the details.

]]

natives.load_natives()
local cls = "                                            \r"
local lual = "\r\27[9C]\27[94m[INFO/LuaScript]\27[m "
local lual_s = ": \27[92mInitialized successfully\27[m                           "
local function IsOnline() return NETWORK.NETWORK_IS_SESSION_STARTED() and not NETWORK.NETWORK_IS_IN_TRANSITION() and not STREAMING.IS_PLAYER_SWITCH_IN_PROGRESS() and not NETWORK.NETWORK_IS_ACTIVITY_SESSION() end

---|| Submenu ||----------------------------------------------------------------------------------

local TS_BUILD = "1158.16"
local versionPtrn = memory.scan_pattern("4C 8D 0D ? ? ? ? 48 8D 5C 24 ? 48 89 D9 48 89 FA") -- from the menu
local GameVersion = versionPtrn:add(3):rip():get_string()

if GameVersion ~= TS_BUILD then
    notify.error("TinkerScripts - 游戏版本不匹配", string.format("TinkeScripts: %s\nCurrent Game Build: %s", TS_BUILD, GameVersion))
    log.error(string.format("\27[2A]\r\27[18C\27[31m[EROR/LuaScript]\27[m TinkerScripts: WRONG GAME BUILD: %s | TinkeScripts: %s %s\27[B]                %s   \27[2A", GameVersion, TS_BUILD, cls, cls)) return
end

local TinkerPath = FileMgr.GetMenuRootPath()
local TS_PATH_Blips = FileMgr.ReadFileContent(TinkerPath.."/TinkerScripts/Blips.lua") load(TS_PATH_Blips)()
local TS_PATH_Unlocks = FileMgr.ReadFileContent(TinkerPath.."/TinkerScripts/TS_RecoveryPlus/Unlocks.lua") load(TS_PATH_Unlocks)()
local TS_PATH_Tunables = FileMgr.ReadFileContent(TinkerPath.."/TinkerScripts/TS_RecoveryPlus/Tunables.lua") load(TS_PATH_Tunables)()
local TS_PATH_FMCharTats = FileMgr.ReadFileContent(TinkerPath.."/TinkerScripts/HumanCanvas/FMCharTats.lua") load(TS_PATH_FMCharTats)()
local function TS_PATH_Settings() return FileMgr.ReadFileContent(TinkerPath.."/TinkerScripts/Settings/TS_Settings.lua") end load(TS_PATH_Settings())()
local function TS_PATH_FMCharTatCombo() return FileMgr.ReadFileContent(TinkerPath.."/TinkerScripts/HumanCanvas/Exported_TattooCombo.txt") end
local function TS_PATH_NoCloudSave() return FileMgr.ReadFileContent(TinkerPath.."/TinkerScripts/Settings/BlockCloudSaves/NoSave.txt") end

menu.set_menu_icon("\xef\x81\xae\xef\x81\xae")
local Tinker = menu.get_submenu("TinkerScripts")
local TS_Main = Tinker:add_category("主要功能")
local TS_Bizteroids = Tinker:add_category("商务强化")
local TS_PhoneMaster = Tinker:add_category("手机大师")
local TS_GoonVan = Tinker:add_category("枪店车")
local TS_RainbowVeh = Tinker:add_category("彩虹载具")
local TS_RecoveryPlus = Tinker:add_category("恢复 +")
local TS_SettingsPlus = Tinker:add_category("设置 +")

function FindNewSession()
	ScriptFunction("shop_controller", ScriptPointer("SendToClouds", "2D 00 02 00 00 72 5D ? ? ? 72")):call("") -- CALLTHEFUNCTIONCALLTHEFUNCTIONCALLTHEFUNCTION | from the menu
	ScriptGlobal(1575048):set_int(11)
end

function CurPlayerCoords()
	PlaCoords = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 0)
	PlaHeading = ENTITY.GET_ENTITY_HEADING(PLAYER.PLAYER_PED_ID())
	PlaFwdVec = ENTITY.GET_ENTITY_FORWARD_VECTOR(PLAYER.PLAYER_PED_ID())
end

function scripts.start_new_script(ScriptName, StackSize)
	script.run_in_callback(function()
		if scripts.is_active(ScriptName) then
			scripts.run_as_script(ScriptName, function() SCRIPT.TERMINATE_THIS_THREAD() end)
		end
		SCRIPT.REQUEST_SCRIPT(ScriptName)
		script.yield(50)
		if SCRIPT.HAS_SCRIPT_LOADED(ScriptName) then
			BUILTIN.START_NEW_SCRIPT(ScriptName, StackSize)
			SCRIPT.SET_SCRIPT_AS_NO_LONGER_NEEDED(ScriptName)
		end
	end)
end

local screenX, screenY = ImGui.GetDisplaySize()
local nomoretreeplease = util.time()

local function CenteredText(Text, NewSeparator, FakeSeparatorText)
	if not FakeSeparatorText then
		ImGui.SetCursorPosX((ImGui.GetWindowWidth() - ImGui.CalcTextSize(Text)) / 2)
		ImGui.TextDisabled(Text)
		if NewSeparator then ImGui.Separator() end
	else
		ImGui.SeparatorText("")
		ImGui.SameLine()
		ImGui.SetCursorPosX((ImGui.GetWindowWidth() - ImGui.CalcTextSize(Text)) / 2)
		ImGui.Text(Text)
	end
end

local function TpToBlip(KillDelPed, Blip, BEntity)
	if KillDelPed then
		script.run_in_callback(function()
			for _, MissionEnemy in ipairs(entities.get_all_peds_as_handles()) do
				if Ped(MissionEnemy):is_enemy() then
					Entity(MissionEnemy):kill()
				end
			end
			script.yield(300)
			for _, MissionEnemy in ipairs(entities.get_all_peds_as_handles()) do
				if Ped(MissionEnemy):is_dead() then
					Entity(MissionEnemy):delete()
				end
			end
		end)
	end
	local BlipID = HUD.GET_FIRST_BLIP_INFO_ID(Blip)
	if BEntity then
		local BlipH = HUD.GET_BLIP_INFO_ID_ENTITY_INDEX(BlipID)
		if Entity(BlipH):is_valid() then
			local BEntityPos = Entity(BlipH):get_position()
			PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), BEntityPos.x, BEntityPos.y, BEntityPos.z + 0.5)
		--else
		--	notify.error("TinkerScript - Teleport to Blip", "No coordinates available!", 3000)
		end
	else
		if HUD.DOES_BLIP_EXIST(BlipID) then
			local blip_coords = HUD.GET_BLIP_INFO_ID_COORD(BlipID)
			PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), blip_coords.x, blip_coords.y, blip_coords.z + 0.5)
		--else
		--	notify.error("TinkerScript - Teleport to Blip", "No coordinates available!", 3000)
		end
	end
end

local function TpToEntity(EntityModel)
	script.run_in_callback(function()
		for _, h in ipairs(entities.get_all_objects_as_handles()) do
			if Entity(h):get_model() == EntityModel then
				local EntityCoords = Entity(h):get_position()
				PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), EntityCoords.x, EntityCoords.y, EntityCoords.z + 0.5) break
			end
		end
	end)
end

---|| Main ||------------------------------------------------------------------------------

local LocationCoords = { -- some from rage.mp
	{ LocName = "富兰克林阿姨家",	LocDesc = "传送至：富兰克林阿姨家",					LocCoords = {-17.95, -1440.61, 31.10} },
	{ LocName = "富兰克林家",			LocDesc = "传送至：富兰克林家",							LocCoords = {7.61, 538.30, 176.03} },
	{ LocName = "迈克尔家",			LocDesc = "传送至：迈克尔家",							LocCoords = {-815.44, 178.77, 72.15} },
	{ LocName = "崔佛的拖车",			LocDesc = "传送至：崔佛的拖车",							LocCoords = {1972.90, 3816.28, 33.42} },
	{ LocName = "冠军房间", 	  	LocDesc = "Teleport to Match \"WINNER\" Room", 						LocCoords = {414.4, -977.6, -100.0042} },
	{ LocName = "角色创建房间",	LocDesc = "传送至：角色创建/选择房间",			LocCoords = {409.13, -999.44, -99.00} },
	{ LocName = "身高测量点", 			LocDesc = "传送至：角色身高测量点", 					LocCoords = {402.91, -996.90, -99.00} },
	{ LocName = "欧米伽的车库", 			LocDesc = "传送至：欧米伽的车库", 							LocCoords = {2331.344, 2574.073, 46.68137} },
	{ LocName = "莱斯特的家", 			LocDesc = "传送至：莱斯特的家", 							LocCoords = {1273.9, -1719.305, 54.77141} },
	{ LocName = "刑讯室", 		  	LocDesc = "传送至：刑讯室", 								LocCoords = {136.5146, -2203.149, 7.30914} },
	{ LocName = "笑裂喜剧俱乐部", 	LocDesc = "传送至：笑裂喜剧俱乐部", 					LocCoords = {382.71, -1001.45, -99.00} },
	{ LocName = "汽车旅馆",					LocDesc = "传送至：汽车旅馆",										LocCoords = {152.2605,-1004.471, -98.99999} },
	{ LocName = "FIB 大楼",				LocDesc = "传送至：FIB 大楼",								LocCoords = {134.5835,-749.339, 258.152} },
	{ LocName = "IAA 办公室",				LocDesc = "传送至：IAA 办公室",									LocCoords = {117.22,-620.938, 206.1398} }
}

local function FastRespawn()
	local logresp = {
		"已跳过 WASTED 画面！",
		"玩家已重生一千次！",
		"快速重生！",
		"mp_forcerespawnpla…… 抱歉，走错游戏了。",
		"总得想办法把脚本凑长一点。",
		"我需要治疗！",
		"我应该在玩《星际战甲》才对……",
		"想来把俄罗斯轮盘吗？",
		"我还不能死，时候未到，amigo！", -- Skye main since beta btw
		"Kifflom！（克利福德教）",
		--"Moar text"
	}
	if ScriptGlobal(2658296):at(PLAYER.PLAYER_ID(), 468):at(236):get_int() == -1 then
		CurPlayerCoords()
		ScriptGlobal(2635562 + 2924):set_int(1)
		--log.info(cls..lual.."Rejack: "..logresp[math.random(#logresp)]..cls)
		script.yield(1500)
		PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), PlaCoords.x, PlaCoords.y, PlaCoords.z)
		ENTITY.SET_ENTITY_HEADING(PLAYER.PLAYER_PED_ID(), PlaHeading)
	end
end

local function FastReload()
	if PAD.IS_CONTROL_JUST_PRESSED(0, 24) then
		local cur_weap = WEAPON.GET_SELECTED_PED_WEAPON(PLAYER.PLAYER_PED_ID())
		script.yield(20)
		WEAPON.SET_CURRENT_PED_WEAPON(PLAYER.PLAYER_PED_ID(), "WEAPON_STICKYBOMB", 0)
		script.yield(200)
		WEAPON.SET_CURRENT_PED_WEAPON(PLAYER.PLAYER_PED_ID(), cur_weap, 1)
	end
end

local function ClearWorld(CwToggle)
	ScriptGlobal(1690468):set_int(CwToggle) -- 1 is the minimum, 0 resets back to default value
	ScriptGlobal(1690469):set_int(CwToggle)
	ScriptGlobal(1690470):set_int(CwToggle)
end

local function GlobalSetBit(global, bitonoff, bits)
	local bitvalue = global:get_int()
	local togglebit = bitonoff
	if togglebit == 1 then
		bitvalue = bit.bor(bitvalue, bit.lshift(1, bits))
	elseif togglebit == 0 then
		bitvalue = bit.band(bitvalue, bit.bnot(bit.lshift(1, bits)))
	end
	global:set_int(bitvalue)
end

local function LocalSetBit(sLocal, bitonoff, bits)
	local bitvalue = sLocal:get_int()
	local togglebit = bitonoff
	if togglebit == 1 then
		bitvalue = bit.bor(bitvalue, bit.lshift(1, bits))
	elseif togglebit == 0 then
		bitvalue = bit.band(bitvalue, bit.bnot(bit.lshift(1, bits)))
	end
	sLocal:set_int(bitvalue)
end

local function RagdollPlayer()
	if PAD.IS_CONTROL_PRESSED(0, 19) then
		PED.SET_PED_TO_RAGDOLL(PLAYER.PLAYER_PED_ID(), 2000, 2000, 0, 0, 0, 0)
	end
end

commandmgr.add_looped_command("tinker_fastrespawn", "快速重生", "跳过死亡后的 WASTED 画面。", function()
	FastRespawn()
end, function()
	ScriptGlobal(2709139):set_int(1)
	notify.success("TinkerScript - 快速重生", "快速重生已开启！", 3000)
end, function()
	ScriptGlobal(2709139):set_int(0)
	notify.info("TinkerScript - 快速重生", "快速重生已关闭。", 3000)
end)

commandmgr.add_looped_command("fastreload", "快速换弹", "类似快速换弹宏（仅限第一人称）", function()
	FastReload()
end, function()
	notify.success("TinkerScript - 快速换弹", "快速换弹已开启！", 3000)
end, function()
	notify.info("TinkerScript - 快速换弹", "快速换弹已关闭。", 3000)
end)

commandmgr.add_bool_command("notm25_bst", "公牛鲨睾酮", "启用公牛鲨睾酮", false, function()
	GlobalSetBit(ScriptGlobal(2673276 + 3768), 1, 0)
	notify.success("TinkerScript - 公牛鲨睾酮", "公牛鲨睾酮已开启！", 3000)
end, function()
	GlobalSetBit(ScriptGlobal(2673276 + 3768), 1, 2)
	notify.info("TinkerScript - 公牛鲨睾酮", "公牛鲨睾酮已关闭。", 3000)
end)

local m25_yogaRmulti = 1.15
local m25_yogaSmulti = 2.0
commandmgr.add_bool_command("m25_runboost", "跑步/游泳强化", "Enables Run/Swim Boost.\n*This is essentially the same as \"Super Run\" from Self submenu, but using a global (Not to be confused with \"Fast Run\" stat).", false, function()
	GlobalSetBit(ScriptGlobal(2673276 + 3768), 1, 10)
	notify.success("TinkerScript - 跑步强化", "跑步强化已开启！", 3000)
end, function()
	GlobalSetBit(ScriptGlobal(2673276 + 3768), 0, 10)
	notify.info("TinkerScript - 跑步强化", "跑步强化已关闭。", 3000)
end)

commandmgr.add_bool_command("m25_strengthboost", "力量强化", "启用力量强化", false, function()
	GlobalSetBit(ScriptGlobal(2673276 + 3768), 1, 6)
	notify.success("TinkerScript - 力量强化", "力量强化已开启！", 3000)
end, function()
	GlobalSetBit(ScriptGlobal(2673276 + 3768), 0, 6)
	notify.info("TinkerScript - 力量强化", "力量强化已关闭。", 3000)
end)

commandmgr.add_bool_command("clearworld", "清空世界", "移除附近所有行人与载具。", false, function()
	ClearWorld(1)
	notify.success("TinkerScript - 清空世界", "清空世界已开启！", 3000)
end, function()
	ClearWorld(0)
	notify.info("TinkerScript - 清空世界", "清空世界已关闭。", 3000)
end)

commandmgr.add_looped_command("ragdoll", "布娃娃瘫倒", "按 [左Alt] 立即瘫倒", function()
	RagdollPlayer()
end, function()
	notify.success("TinkerScript - 布娃娃瘫倒", "手动瘫倒已开启！", 3000)
end, function()
	notify.info("TinkerScript - 布娃娃瘫倒", "手动瘫倒已关闭。", 3000)
end)

commandmgr.add_looped_command("infcombatroll", "无限翻滚", "附赠：无后坐力 / 无扩散 ;)", function()
	stats.set_int("MPX_SHOOTING_ABILITY", 500)
end, function()
	notify.success("TinkerScript - 无限翻滚", "无限翻滚已开启！", 3000)
end, function()
	notify.info("TinkerScript - 无限翻滚", "无限翻滚已关闭。", 3000)
end)

commandmgr.add_looped_command("noidlecam", "禁用待机镜头", "禁用长时间不动时的自动镜头。", CAMERA.INVALIDATE_IDLE_CAM)

local VehAutoDrive = {
	Toggle = false,
	Mode = 0,
	Label = { "正常", "匆忙", "GTA" },
	Flag = { 443, 787118, 1076625980 }
}

VehAutoDrive.SkipRedLight = function(PlaVeh)
	if VehAutoDrive.Flag[VehAutoDrive.Mode + 1] == 787118 and VEHICLE.IS_VEHICLE_STOPPED_AT_TRAFFIC_LIGHTS(PlaVeh) then
		script.yield(4000)
		TASK.SET_DRIVE_TASK_DRIVING_STYLE(PLAYER.PLAYER_PED_ID(), tonumber(bit.band(787118, bit.bnot(bit.lshift(1, 7)))))
		script.yield(2000)
		TASK.SET_DRIVE_TASK_DRIVING_STYLE(PLAYER.PLAYER_PED_ID(), 787118)
	end
end

local AutoDriveSpeed = 40
local function SelfTaxi()
	local PlaVeh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
    if PED.IS_PED_SITTING_IN_ANY_VEHICLE(PLAYER.PLAYER_PED_ID()) then
        local wp_blip = HUD.GET_FIRST_BLIP_INFO_ID(8)
        if not HUD.DOES_BLIP_EXIST(wp_blip) then
           notify.info("TinkerScript - 出租代驾", "请先设置一个导航点。", 3000) return
        end
        local wp_coords = HUD.GET_BLIP_INFO_ID_COORD(wp_blip)
        TASK.TASK_VEHICLE_DRIVE_TO_COORD(PLAYER.PLAYER_PED_ID(), PlaVeh, wp_coords.x, wp_coords.y, wp_coords.z, AutoDriveSpeed, 0, 0, VehAutoDrive.Flag[VehAutoDrive.Mode + 1], 10.0, 0)
        notify.info("TinkerScript - 出租代驾", "自动驾驶已开始，正在前往导航点。", 3000)
        while true do
			VEHICLE.SET_VEHICLE_MAX_SPEED(PlaVeh, AutoDriveSpeed)
			CurPlayerCoords()
            local dist = BUILTIN.VDIST(PlaCoords.x, PlaCoords.y, PlaCoords.z, wp_coords.x, wp_coords.y, wp_coords.z)
			if drivemodechanged then TASK.SET_DRIVE_TASK_DRIVING_STYLE(PLAYER.PLAYER_PED_ID(), VehAutoDrive.Flag[VehAutoDrive.Mode + 1]) end
			VehAutoDrive.SkipRedLight(PlaVeh)
            if dist < 70.0 then
                TASK.CLEAR_PED_TASKS(PLAYER.PLAYER_PED_ID())
				VEHICLE.BRING_VEHICLE_TO_HALT(PlaVeh, 3.0, 1, 0)
                notify.success("TinkerScript - 出租代驾", "已到达目的地。", 3000) return
            end
            if PAD.IS_CONTROL_JUST_PRESSED(0, 22) then -- SPACEBAR
                notify.info("TinkerScript - 出租代驾", "自动驾驶已取消。", 3000)
                TASK.CLEAR_PED_TASKS(PLAYER.PLAYER_PED_ID()) return
            end
            script.yield(0)
        end
    else
        notify.warn("TinkerScript - 出租代驾", "你不在载具中。", 3000)
    end
end

local function Wander() -- Shadow of The Collossus?
	local PlaVeh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
	if PED.IS_PED_SITTING_IN_ANY_VEHICLE(PLAYER.PLAYER_PED_ID()) then
		TASK.TASK_VEHICLE_DRIVE_WANDER(PLAYER.PLAYER_PED_ID(), PlaVeh, AutoDriveSpeed, VehAutoDrive.Flag[VehAutoDrive.Mode + 1])
		notify.info("TinkerScript - 自动漫游", "自动漫游已开始。", 3000)
		while true do
			VEHICLE.SET_VEHICLE_MAX_SPEED(PlaVeh, AutoDriveSpeed)
			if drivemodechanged then TASK.SET_DRIVE_TASK_DRIVING_STYLE(PLAYER.PLAYER_PED_ID(), VehAutoDrive.Flag[VehAutoDrive.Mode + 1]) end
			VehAutoDrive.SkipRedLight(PlaVeh)
			if PAD.IS_CONTROL_JUST_PRESSED(0, 22) then -- SPACEBAR
				notify.info("TinkerScript - 自动漫游", "你接管了方向盘。", 3000)
				TASK.CLEAR_PED_TASKS(PLAYER.PLAYER_PED_ID()) return
			end
			script.yield(0)
		end
	else
		notify.warn("TinkerScript - 自动漫游", "你不在载具中。", 3000)
	end
end

local jr_radius = 10
local function Joyrider(jr_radius)
	CurPlayerCoords()
	local vehicle = VEHICLE.GET_RANDOM_VEHICLE_IN_SPHERE(PlaCoords.x, PlaCoords.y, PlaCoords.z, jr_radius, 0, 101247)
	local drivernomore = VEHICLE.GET_PED_IN_VEHICLE_SEAT(vehicle, -1, 0)
	if vehicle ~= 0 and not Vehicle(vehicle):is_seat_free(-1) then
		Entity(drivernomore):delete() -- SPENT 2HRS TRYING TO USE NATIVES JUST TO FIND OUT THIS EXIST AHHHHHHHHHHHHHHHHHHHHHH (DELETE_ENTITY doesn't work)
		PED.SET_PED_INTO_VEHICLE(PLAYER.PLAYER_PED_ID(), vehicle, -1)
	elseif vehicle ~= 0 and Vehicle(vehicle):is_seat_free(-1) then
		PED.SET_PED_INTO_VEHICLE(PLAYER.PLAYER_PED_ID(), vehicle, -1)
		VEHICLE.SET_VEHICLE_UNDRIVEABLE(vehicle, 0)
		VEHICLE.SET_VEHICLE_ENGINE_ON(vehicle, 1, 1, 0)
	else
		notify.info("TinkerScript - 兜风模式", "附近没有载具（"..jr_radius.."m) detected.\nIncrease your Teleport Radius.", 3000)
	end
end

local DuffelBagSavePatch = {}
commandmgr.add_bool_command("DuffelBagSave", "允许保存挎包", "绕过服装店/衣柜对挎包的保存限制。", false, function()
	if not DuffelBagSavePatch.Shop then
		DuffelBagSavePatch.Shop = ScriptPatch("clothes_shop_mp", "DuffelBagSavePatch1", "2C 0D ? ? 56 ? ? 72 2E 01 01 71 2E 01 01 2D 02 04", 7, {0x00})
	end
	if not DuffelBagSavePatch.Wardrobe then
		DuffelBagSavePatch.Wardrobe = ScriptPatch("wardrobe_mp", "DuffelBagSavePatch2", "2C 0D ? ? 56 ? ? 72 2E 01 01 71 2E 01 01 2D 01 03", 7, {0x00})
	end
	DuffelBagSavePatch.Shop:enable()
	DuffelBagSavePatch.Wardrobe:enable()
end, function()
	if DuffelBagSavePatch.Shop then DuffelBagSavePatch.Shop:disable() end
	if DuffelBagSavePatch.Wardrobe then DuffelBagSavePatch.Wardrobe:disable() end
end)

local OR_offsets = {
	0x528, 0x568, 0x5A8, 0x5E8, 0x628,
	0x668, 0x6A8, 0x6E8, 0x728, 0x768,
	0x7A8, 0x7E8, 0x828, 0x868, 0x8A8,
	0x8E8, 0x928, 0x968, 0x9A8, 0x9E8
}

local OR_ptr
local OR_selected = 0
local New_Name = ""
local renamemode = false
local canrename = false
local ibox_checkbox = false
local function ReNameEditor() -- deprecated
	if not canrename then
		if MISC.UPDATE_ONSCREEN_KEYBOARD() == 0 then
			log.info(cls..lual.."Waiting for \"New Name\""..cls)
			MISC.DISPLAY_ONSCREEN_KEYBOARD(0, "CELL_7000", "", New_Name, nil, nil, nil, 64)
			canrename = true
		elseif MISC.UPDATE_ONSCREEN_KEYBOARD() ~= 0 then
			notify.info("TinkerScript - 改名工具", "Open an \"Input Box\" first.", 3000)
			log.info(cls..lual.."Re-Name Editor: \27[33mOpen an \"Input Box\" first.\27[m"..cls.."\n") return
		end
	end
	while canrename do
		local nn = MISC.GET_ONSCREEN_KEYBOARD_RESULT()
		if MISC.UPDATE_ONSCREEN_KEYBOARD() == 1 then
			notify.success("TinkerScript - 改名工具", "New name is:\n"..nn, 3000)
			log.info(string.format("%s%s\27[ARe-Name Editor: \27[32mNew name is:\27[m%s %s%s", cls, lual, nn, cls, cls))
			New_Name = ""
			canrename = false
			return
		elseif MISC.UPDATE_ONSCREEN_KEYBOARD() == 2 then
			notify.info("TinkerScript - 改名工具", "已取消。", 3000)
			log.info(cls..lual.."\27[ARe-Name Editor: Logic canceled.                             \27[B\r                                      "..cls)
			canrename = false
			return
		end
		script.yield(0)
	end
end

local ReN_Style = {
	{ tbLabel = "R* 标志",		tStyle = "∑"},
	{ tbLabel = "通缉星",	tStyle = "~ws~"},
	{ tbLabel = "R* 认证",	tStyle = "¦"},
	{ tbLabel = "锁形图标",	tStyle = "Ω"},
	{ tbLabel = "R* 出品",	tStyle = "‹"},
	{ tbLabel = "空白图标",	tStyle = "›"},
	{ tbLabel = "加粗",			tStyle = "~h~"},
	{ tbLabel = "斜体",		tStyle = "~italic~"},
	{ tbLabel = "换行",		tStyle = "~n~"},
	{ tbLabel = "重置",		tStyle = "~s~"}
}

local ReN_Color = {
	{ bName = "##Rednnf",		bTip = "红色",		 tColf = "~r~",	 bCol = {0.870, 0.196, 0.196, 1.0} },
	{ bName = "##Yellownnf",	bTip = "黄色",	 tColf = "~y~",	 bCol = {0.933, 0.776, 0.313, 1.0} },
	{ bName = "##Bluennf",		bTip = "蓝色",		 tColf = "~b~",	 bCol = {0.360, 0.705, 0.890, 1.0} },
	{ bName = "##DarkBluennf",	bTip = "深蓝色",	 tColf = "~d~",	 bCol = {0.184, 0.361, 0.451, 1.0} },
	{ bName = "##Orangennf",	bTip = "橙色",	 tColf = "~o~",	 bCol = {0.992, 0.517, 0.333, 1.0} },
	{ bName = "##Greennnf",		bTip = "绿色",		 tColf = "~g~",	 bCol = {0.443, 0.792, 0.443, 1.0} },
	{ bName = "##Pinknnf",		bTip = "粉色",		 tColf = "~q~",	 bCol = {0.886, 0.309, 0.502, 1.0} },
	{ bName = "##Purplennf",	bTip = "紫色",	 tColf = "~p~",	 bCol = {0.513, 0.396, 0.878, 1.0} },
	{ bName = "##Whitennf",		bTip = "白色",		 tColf = "~w~",	 bCol = {1, 1, 1, 1.0} }, -- doing 1.0 makes the button transparent for some reason
	{ bName = "##Greynnf",		bTip = "灰色",		 tColf = "~c~",	 bCol = {0.545, 0.545, 0.545, 1.0} },
	{ bName = "##DarkGreynnf",	bTip = "深灰色",	 tColf = "~m~",	 bCol = {0.388, 0.388, 0.388, 1.0} },
	{ bName = "##Blacknnf",		bTip = "黑色",		 tColf = "~u~",	 bCol = {0.0, 0.0, 0.0, 1.0} }
}

local ReN_selectedprop
-- local New_PropName = "" -- Replaced with original one
local ReN_Properties = {
	{ renProperty = "办公室",			renPropStat = "MPX_GB_OFFICE_NAME",			renPropStat2 = "MPX_GB_OFFICE_NAME2"},
	{ renProperty = "组织",		renPropStat = "MPX_GB_GANG_NAME",			renPropStat2 = "MPX_GB_GANG_NAME2"},
	{ renProperty = "摩托帮会所",		renPropStat = "MPX_MC_CLBHOSE_NAME",		renPropStat2 = "MPX_MC_CLBHOSE_NAME2"},
	{ renProperty = "摩托帮",			renPropStat = "MPX_MC_GANG_NAME",			renPropStat2 = "MPX_MC_GANG_NAME2"},
	{ renProperty = "游艇",			renPropStat = "MPX_YACHT_NAME",				renPropStat2 = "MPX_YACHT_NAME2"},
	{ renProperty = "夜总会",		renPropStat = "MPX_NIGHTCLUB_NAME",			renPropStat2 = "MPX_NIGHTCLUB_NAME2"},
	{ renProperty = "致幻实验室",			renPropStat = "MPX_ACID_LAB_NAME",			renPropStat2 = "MPX_ACID_LAB_NAME2"},
	{ renProperty = "致幻产品",	renPropStat = "MPX_ACIDLAB_PRODUCT_NAME",	renPropStat2 = "MPX_ACIDLAB_PRODUCT_NAME2"},
	{ renProperty = "豪宅的狗",		renPropStat = "MPX_MANSION_DOG_NAME1",		renPropStat2 = "MPX_MANSION_DOG_NAME2"},
	{ renProperty = "豪宅的猫",		renPropStat = "MPX_MANSION_CAT_NAME1",		renPropStat2 = "MPX_MANSION_CAT_NAME2"}
}

local JBvJG = {
	SoV = false,
	Phoenix = false,
	SoVLoop = 0,
	PhoenixLoop = 0,
	PhoenixReactToNoclip = false
}

local function RapidOxidation()
	if PAD.IS_CONTROL_JUST_PRESSED(0, 183) then -- G Key
		JBvJG.SoV = not JBvJG.SoV
	end
	if JBvJG.SoV then
		if (MISC.GET_GAME_TIMER() - JBvJG.SoVLoop) > 2200 then
			STREAMING.REQUEST_NAMED_PTFX_ASSET("core")
			for _, i in ipairs {{0x796e, 0.7}, {0x3779, 0.3}, {0xcc4d, 0.3}, {0xdead, 0.3}, {0x49d9, 0.3}} do
				GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_petrol_fire", PLAYER.PLAYER_PED_ID(), 0, 0, 0.0, 90.0, -100.0, 90.0, i[1], i[2], 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET()
			end
			JBvJG.SoVLoop = MISC.GET_GAME_TIMER()
		end
	end
	if PAD.IS_CONTROL_JUST_PRESSED(0, 29) then -- B Key
		JBvJG.Phoenix = not JBvJG.Phoenix
		--if not Phoenix then GRAPHICS.REMOVE_PARTICLE_FX_FROM_ENTITY(PLAYER.PLAYER_PED_ID()) end -- This works but the change is too abrupt, phoenix wings slowly fading away look cool anyway
	end
	if JBvJG.Phoenix then
		if (MISC.GET_GAME_TIMER() - JBvJG.PhoenixLoop) > 6200 then
			STREAMING.REQUEST_NAMED_PTFX_ASSET("core")
			for _, i in ipairs{{-0.30, 0}, {-0.35, 10.0}, {-0.40, 20.0}, {-0.45, 30.0}} do
				if JBvJG.PhoenixReactToNoclip then
					if commandmgr.get_command("noclip"):get_value() then
						GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER.PLAYER_PED_ID(), i[1] + 0.50, -0.15, 0.03, -25.0, i[2] - 28, 0, 0x60F2, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET()
						GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER.PLAYER_PED_ID(), i[1] + 0.50, -0.15, 0.03, 205.0, i[2] - 28, 0, 0x60F2, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET()
					else
						GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER.PLAYER_PED_ID(), i[1] + 0.50, -0.15, 0.03, -25.0, i[2] + 50, 0, 0x60F2, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET()
						GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER.PLAYER_PED_ID(), i[1] + 0.50, -0.15, 0.03, 205.0, i[2] + 50, 0, 0x60F2, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET()
					end
				else
					GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER.PLAYER_PED_ID(), i[1], -0.15, 0.03, -25.0, i[2], 0, 0x2e28, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET()
					GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER.PLAYER_PED_ID(), i[1], -0.15, 0.03, 205.0, i[2], 0, 0x2e28, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET()
				end
			end
			JBvJG.PhoenixLoop = MISC.GET_GAME_TIMER()
		end
	end
end

commandmgr.add_looped_command("rapidoxidation", "急速氧化（恶灵骑士）", "Johnny Blaze meets Jean Grey...\n\nPress [G] to become Ghost Rider.\nPress [B] to unleash The Phoenix!", function()
	RapidOxidation()
end, function()
	notify.success("TinkerScript - 急速氧化", "Rapid Oxidation enabled\nPress [G] to become Ghost Rider.\nPress [B] to unleash The Phoenix!", 3000)
	players.get_local():get_ped():set_invincible(true)
end, function()
	notify.info("TinkerScript - 急速氧化", "急速氧化已关闭。", 3000)
	players.get_local():get_ped():set_invincible(false)
end)

commandmgr.add_bool_command("phoenixnoclip", "凤凰之翼随穿墙状态开合", "根据穿墙（No Clip）状态折叠/展开凤凰之翼。", false, function()
	JBvJG.PhoenixReactToNoclip = true
end, function()
	JBvJG.PhoenixReactToNoclip = false
end)
commandmgr.add_bool_command("noclip_onscreen", "穿墙状态屏显", "开启穿墙时在屏幕上显示一个小窗口。", false, nil)

local NoClipWindowTop = false
menu.add_always_draw_imgui(function()
	if commandmgr.get_command("noclip_onscreen"):get_value() and commandmgr.get_command("noclip"):get_value() then
        if not NoClipWindowTop then ImGui.SetNextWindowPos(screenX / 2, screenY, 0, 0.5, 1.0) else ImGui.SetNextWindowPos(screenX / 2, 0, 0, 0.5, 0) end
        ImGui.SetNextWindowSize(150, 70)
		ImGui.PushStyleVar(ImGuiStyleVar.WindowTitleAlign, 0.5, 0.5)
        ImGui.Begin("穿墙飞行", nil, 2 + 4 + 32 + 256 + 512)
			ImGui.SetCursorPosX((ImGui.GetWindowWidth() - ImGui.CalcTextSize("已启用")) / 2)
            ImGui.TextColored(0.0, 1.0, 0.0, 1.0, "已启用")
        ImGui.End()
		ImGui.PopStyleVar()
	end
end)

local playing_anim = false
commandmgr.add_looped_command("noclip_anim", "穿墙动画", "开启穿墙时让角色播放飞行动画。", function() -- From YimMenu (I just wanted to clone my character and ended up with this... and completely forgot about cloning my character lol). I have no idea of what I have done here (if good or bad), but it works.
	if (commandmgr.get_command("noclip"):get_value() and ENTITY.GET_ENTITY_HEIGHT_ABOVE_GROUND(PLAYER.PLAYER_PED_ID()) > 3) and not PED.IS_PED_IN_ANY_VEHICLE(PLAYER.PLAYER_PED_ID(), false) then
		if (STREAMING.HAS_ANIM_DICT_LOADED("skydive@freefall") and STREAMING.HAS_ANIM_DICT_LOADED("missfam5_yoga")) and not playing_anim then
			TASK.CLEAR_PED_TASKS_IMMEDIATELY(PLAYER.PLAYER_PED_ID())
			playing_anim = true
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "skydive@parachute@first_person", "chute_idle_alt_lookright", 4, 1, -1, 1 + 1048576, 0, false, false, false)
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "missfam5_yoga", "c8_to_start", 4, 1, -1, 2 + 16 + 32 + 131072 + 1048576, 0, false, false, false)
		else
			STREAMING.REQUEST_ANIM_DICT("skydive@freefall")
			STREAMING.REQUEST_ANIM_DICT("skydive@parachute@first_person")
			STREAMING.REQUEST_ANIM_DICT("missfam5_yoga")
		end
		if playing_anim and PAD.IS_CONTROL_JUST_PRESSED(0, 150) then
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "skydive@freefall", "free_forward", 4.0, 1.0, -1, 1 + 64, 0, false, false, false)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "skydive@parachute@first_person", "chute_idle_alt_lookright", 6.0)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "missfam5_yoga", "c8_to_start", 6.0)
		end
		if playing_anim and PAD.IS_CONTROL_JUST_PRESSED(0, 151) then
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "skydive@freefall", "free_back", 4.0, 1.0, -1, 1 + 64, 0, false, false, false)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "skydive@parachute@first_person", "chute_idle_alt_lookright", 6.0)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "missfam5_yoga", "c8_to_start", 6.0)
		end
		if playing_anim and PAD.IS_CONTROL_JUST_PRESSED(0, 147) then
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "skydive@freefall", "free_left", 4.0, 1.0, -1, 1 + 64, 0, false, false, false)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "skydive@parachute@first_person", "chute_idle_alt_lookright", 6.0)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "missfam5_yoga", "c8_to_start", 6.0)
		end
		if playing_anim and PAD.IS_CONTROL_JUST_PRESSED(0, 148) then
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "skydive@freefall", "free_right", 4.0, 1.0, -1, 1 + 64, 0, false, false, false)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "skydive@parachute@first_person", "chute_idle_alt_lookright", 6.0)
			TASK.STOP_ANIM_TASK(PLAYER.PLAYER_PED_ID(), "missfam5_yoga", "c8_to_start", 6.0)
		end
		if playing_anim and (PAD.IS_CONTROL_JUST_RELEASED(0, 150) or PAD.IS_CONTROL_JUST_RELEASED(0, 151) or PAD.IS_CONTROL_JUST_RELEASED(0, 147) or PAD.IS_CONTROL_JUST_RELEASED(0, 148)) or PAD.IS_DISABLED_CONTROL_PRESSED(0, 36) then
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "skydive@parachute@first_person", "chute_idle_alt_lookright", 4, 1, -1, 1 + 1048576, 0, false, false, false)
			TASK.TASK_PLAY_ANIM(PLAYER.PLAYER_PED_ID(), "missfam5_yoga", "c8_to_start", 4, 1, -1, 2 + 16 + 32 + 131072 + 1048576, 0, false, false, false)
		end
	else
		if playing_anim then
			TASK.CLEAR_PED_TASKS(PLAYER.PLAYER_PED_ID())
			playing_anim = false
		end
	end
end)

local PTFXt = {
	{ 1, "爆炸"},
	{ 2, "电流"},
	{ 3, "闪耀"},
	{ 4, "闪光"},
	{ 5, "噗噗 1"},
	{ 6, "噗噗 2"},
}

local Particles = false
local function TransformFX()
	if Particles then
		if PTFX == 1 then
			GRAPHICS.USE_PARTICLE_FX_ASSET("core");GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("exp_grd_grenade_lod", PLAYER.PLAYER_PED_ID(),  0, 0, 0, 0, 0, 0, 0x2e28, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET();script.yield(100)
		elseif PTFX == 2 then
			GRAPHICS.USE_PARTICLE_FX_ASSET("scr_fm_mp_missioncreator");GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("scr_mp_elec_dst", PLAYER.PLAYER_PED_ID(),  0, 0, 0, 0, 0, 0, 0x2e28, 5, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET();script.yield(100)
		elseif PTFX == 3 then
			GRAPHICS.USE_PARTICLE_FX_ASSET("proj_indep_firework_v2");GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("scr_xmas_firework_sparkle_spawn", PLAYER.PLAYER_PED_ID(),  0, 0, 0, 0, 0, 0, 0x2e28, 15, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET();script.yield(100)
		elseif PTFX == 4 then
			GRAPHICS.USE_PARTICLE_FX_ASSET("scr_indep_fireworks");GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("scr_indep_firework_trailburst_spawn", PLAYER.PLAYER_PED_ID(),  0, 0, 0, 0, 0, 0, 0x2e28, 10, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET();script.yield(100)
		elseif PTFX == 5 then
			GRAPHICS.USE_PARTICLE_FX_ASSET("scr_rcbarry2");GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("scr_clown_appears", PLAYER.PLAYER_PED_ID(),  0.3, 0, 0, 0, 0, 0, 0x2e28, 1, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET();script.yield(300)
		elseif PTFX == 6 then
			GRAPHICS.USE_PARTICLE_FX_ASSET("scr_powerplay");GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("scr_powerplay_beast_appear", PLAYER.PLAYER_PED_ID(),  0.3, 0, 0, 0, 0, 0, 0x2e28, 1.3, 1, 1, 1);STREAMING.REMOVE_PTFX_ASSET();script.yield(300)
		end
	end
end

local function TinyPlayer()
	if not PED.GET_PED_CONFIG_FLAG(PLAYER.PLAYER_PED_ID(), 223, 1) then
		if PAD.IS_CONTROL_JUST_PRESSED(0, 73) then
			TransformFX()
			PED.SET_PED_CONFIG_FLAG(PLAYER.PLAYER_PED_ID(), 223, 1);STREAMING.REMOVE_PTFX_ASSET()
		end
	else
		if PAD.IS_CONTROL_JUST_PRESSED(0, 73) then
			TransformFX()
			PED.SET_PED_CONFIG_FLAG(PLAYER.PLAYER_PED_ID(), 223, 0);STREAMING.REMOVE_PTFX_ASSET()
		end
	end
end

commandmgr.add_looped_command("tinyplayer", "迷你玩家", "想变成蚁人？", function()
	TinyPlayer()
end, function()
	for _, i in ipairs {"core", "scr_fm_mp_missioncreator", "proj_indep_firework_v2", "scr_indep_fireworks", "scr_rcbarry2", "scr_powerplay"} do
		STREAMING.REQUEST_NAMED_PTFX_ASSET(i)
	end
end, function()
	for _, i in ipairs {"core", "scr_fm_mp_missioncreator", "proj_indep_firework_v2", "scr_indep_fireworks", "scr_rcbarry2", "scr_powerplay"} do
		STREAMING.REMOVE_NAMED_PTFX_ASSET(i)
	end
end)

commandmgr.add_bool_command("tinyp_ptfxtoggle", "粒子", "启用粒子特效", false, function()
	Particles = true
end, function()
	Particles = false
end)

commandmgr.add_list_command("tinyp_ptfxlist", "粒子特效", "", PTFXt, 1, nil)

commandmgr.add_bool_command("hiddenlocs", "隐藏地点", "传送至隐藏/随机地点。", false, nil)

local BoxWidth = 0.208
local BoxHeight = 0.492
local xPos = 0.8545
local yPos = 0.312
local MM_msg = [[

~y~      Welcome to
Kiddion's Modest Menu!~s~

This mod is offered free of charge
and wihout warranty!

For any help, please visit the
Modest Menu thread at
~HC_64~https://unknowncheats.me~s~ and
carefully read the FAQ and Known
Issues.

~r~This is for EDUCATIONAL AND
EVALUATION PURPOSES ONLY.
NO responsability is held or
accepted for misuse.
~h~Use at your own risk!~s~

]]

local function ModestMenu(msg, x, y)
    HUD.SET_TEXT_SCALE(0.0, 0.375)
    HUD.SET_TEXT_LEADING(3.0)
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("CELL_EMAIL_BCON")
    for i = 1, #msg, 99 do
        HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(string.sub(msg, i, i + 98))
    end
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0)
	GRAPHICS.REQUEST_STREAMED_TEXTURE_DICT("shared", true)
end

TS_Main:imgui(function() if not IsOnline() then ImGui.TextDisabled("请先进入自由模式战局。") return end

	ImGui.BeginTabBar("MainCatTab")
	if ImGui.BeginTabItem("常规") then

		if not windowcheck and ImGui.IsWindowHovered() then
			nomoretreeplease = util.time()
			windowcheck = true
		elseif windowcheck then
			if util.time() < nomoretreeplease + 5000 then
				--ImGui.SetCursorPosX((ImGui.GetWindowWidth() - 300) * 0.5) ImGui.SetCursorPosY(5.0) -- not perfectly centered but I'll leave it here as an example of what not to do
				CenteredText("TinkerScripts 原版由 ImagineNothing 制作", true, false)
			end
		end

		ImGui.Text("常规")ImGui.Separator()ImGui.Spacing()

		ImGui.BeginGroup()
	    commandmgr.get_command("tinker_fastrespawn"):draw()
		commandmgr.get_command("fastreload"):draw()
		commandmgr.get_command("infcombatroll"):draw()
	    commandmgr.get_command("ragdoll"):draw()
		ImGui.EndGroup()

		ImGui.SameLine() ImGui.BeginGroup()
		commandmgr.get_command("notm25_bst"):draw()
		ImGui.SameLine()
		commandmgr.get_command("noidlecam"):draw()
		commandmgr.get_command("m25_runboost"):draw()
		if commandmgr.get_command("m25_runboost"):get_value() then
			ImGui.PushItemWidth(80)
			ImGui.SameLine() m25_yogaRmulti = ImGui.SliderFloat("跑步倍率", m25_yogaRmulti, 1.15, 3.0)
			ImGui.SameLine() m25_yogaSmulti = ImGui.SliderFloat("游泳倍率", m25_yogaSmulti, 2.0, 3.0)
			ImGui.PopItemWidth()
			tunables.set_float(-1585694365, m25_yogaRmulti)
			tunables.set_float(-1986470272, m25_yogaSmulti)
		end
		commandmgr.get_command("m25_strengthboost"):draw()
	    commandmgr.get_command("clearworld"):draw()
		ImGui.EndGroup()

		if ImGui.Button("强制云存档") then
			STATS.STAT_SAVE(0, 0, 3, 0)
		end

		if ImGui.Button("传送进个人载具") then
			ScriptGlobal(2640101 + 8):set_int(1)
		end

		if ImGui.Button("传送进最近的载具") then
			Joyrider(jr_radius)
		end

		ImGui.SameLine()
		ImGui.SetNextItemWidth(100)
		jr_radius = ImGui.InputInt("传送搜索半径", jr_radius)

		ImGui.Spacing()ImGui.Spacing()

		ImGui.Text("自动驾驶") if ImGui.IsItemHovered() then ImGui.SetTooltip("启用 KnoWay 自动驾驶系统。") end ImGui.Separator()ImGui.Spacing()

		ImGui.SetNextItemWidth(130)
		VehAutoDrive.Mode, drivemodechanged = ImGui.Combo("驾驶风格", VehAutoDrive.Mode, VehAutoDrive.Label, 3) -- I'll stick to add_list_command next time

		ImGui.SameLine()
		ImGui.SetNextItemWidth(100)
		AutoDriveSpeed = ImGui.InputInt("速度##wander", AutoDriveSpeed)

		if ImGui.Button("自动驾驶（前往导航点）") then
			script.run_in_callback(SelfTaxi)
		end

		if ImGui.Button("自动漫游") then
			script.run_in_callback(Wander)
		end

		ImGui.Spacing()ImGui.Spacing()

		ImGui.Text("改名工具")ImGui.Separator()ImGui.Spacing()

		if OR_ptr == nil then
			OR_ptr = memory.scan_pattern("40 5D ? ? ? ? 00 00 90 5D ? ? ? ? 00 00 00 00 00 00 00 00 00 00 00"):deref()
		end

		ImGui.AlignTextToFramePadding()
		if renamemode then ImGui.Text("模式：产业改名") else ImGui.Text("模式：服装改名") end

		ImGui.SameLine()

		if ImGui.Button("切换模式") then
			renamemode = not renamemode
			New_Name = ""
		end ImGui.Spacing()

		if renamemode then
			if ImGui.BeginListBox("##renprops"..nomoretreeplease, 400, 232) then -- https://www.unknowncheats.me/forum/call-of-duty-modern-warfare-ii/571696-imgui-listbox.html
				for i, item in ipairs(ReN_Properties) do
					local is_selected = (selected_prop == i)
					if ImGui.Selectable(item.renProperty..": "..stats.get_string(item.renPropStat)..stats.get_string(item.renPropStat2), is_selected) and selected_prop ~= i then
						selected_prop = i
						New_Name = stats.get_string(item.renPropStat) .. stats.get_string(item.renPropStat2)
						ReN_selectedprop = item
					end
				end
				ImGui.EndListBox()

				ImGui.SetNextItemWidth(400)
				New_Name = ImGui.InputTextWithHint("##newrename", "新的组织/致幻实验室/宠物名称", New_Name)

				ImGui.SameLine()
				if ImGui.Button("改名") then
					stats.set_string(ReN_selectedprop.renPropStat, New_Name:sub(1, 10))
					stats.set_string(ReN_selectedprop.renPropStat2, New_Name:sub(11, 20))
				end
			end
			ImGui.SameLine() ibox_checkbox = ImGui.Checkbox("输入框覆写", ibox_checkbox)

			if ibox_checkbox then
				ImGui.SetNextItemWidth(400)
				New_Name = ImGui.InputTextWithHint("##iboxoverride", "新的输入框文本", New_Name)

				ImGui.SameLine() if ImGui.Button("覆写") then
					script.run_in_callback(ReNameEditor)
				end if ImGui.IsItemHovered() then ImGui.SetTooltip("R* 已修复输入框过滤，此功能已基本失效。") end
			end
		else
			if ImGui.BeginListBox("##outfitslots"..nomoretreeplease, 400, 232) then
				for i = 1, 20 do
					local outfitname = OR_ptr:add(OR_offsets[i]):get_string()
					local is_selected = (OR_selected == i)
					if ImGui.Selectable(i..". "..outfitname, is_selected) and OR_selected ~= i then
						OR_selected = i
						New_Name = outfitname
					end
				end
				ImGui.EndListBox()
			end

			ImGui.SetNextItemWidth(400)
			New_Name = ImGui.InputTextWithHint("##outfitname", "~ws~~r~¦~s~新名称~r~¦~ws~", New_Name)

			ImGui.SameLine()
			if ImGui.Button("应用##OR") then
				if New_Name ~= "" and OR_selected > 0 then
					OR_ptr:add(OR_offsets[OR_selected]):set_string(New_Name:sub(1, 31))
					notify.success("服装改名", "栏位 " .. (OR_selected) .. " 已重命名！", 3000)
					New_Name = ""
				elseif (New_Name ~= "" or New_Name == "") and OR_selected <= 0 then
					notify.error("TinkerScript - 改名", "请先选择一个目标！", 3000)
				elseif New_Name == "" and OR_selected > 0 then
					notify.error("TinkerScript - 改名", "Name is empty!\nPlease enter a name.", 3000)
				end
			end

			ImGui.SameLine() if ImGui.Button("复制") then
				if OR_selected > 0 then
					local copyoutfitname = OR_ptr:add(OR_offsets[OR_selected]):get_string()
					ImGui.SetClipboardText(copyoutfitname)
					notify.info("服装改名", "已复制： " .. copyoutfitname, 3000)
				else
					notify.error("TinkerScript - 改名", "请先选择一个目标！", 3000)
				end
			end

			ImGui.SameLine() if ImGui.Button("全部复制") then
				local AllOutfitNames = {}
				for i = 1, 20 do
					local outfitname = OR_ptr:add(OR_offsets[i]):get_string() or "（空）"
					table.insert(AllOutfitNames, i..". "..outfitname)
				end
				ImGui.SetClipboardText(table.concat(AllOutfitNames, "\n"))
				notify.info("服装改名", "已复制全部服装名称到剪贴板！", 3000)
			end
		end

		ImGui.Spacing()ImGui.Spacing() ImGui.SameLine(0, 3.8) if ImGui.TreeNodeEx("文本格式  ##"..nomoretreeplease, 8219) then

		ImGui.BeginGroup()

		for i, textformat in ipairs(ReN_Style) do
			if i % 2 == 0 then ImGui.SameLine() end

			if ImGui.Button(textformat.tbLabel, 100) then
				if selected_prop ~= nil or OR_selected > 0 then
					New_Name = New_Name .. textformat.tStyle
				else
					notify.error("TinkerScript - 改名", "请先选择一个目标！", 3000)
				end
			end if ImGui.IsItemHovered() then ImGui.SetTooltip(textformat.tStyle) end
		end

		ImGui.EndGroup()

		ImGui.SameLine()

		ImGui.BeginGroup() -- Table looks much better but this also work
		ImGui.InputTextMultiline("##Colors & Symbols", [[
Use HTML/Hex if symbols don't work.

R* Logo:    	      &#8721;   |   &#x2211;
R* Verified:	     &#166;     |   &#xa6;
R* Created: 	   &#8249;   |   &#x2039;
Lock Icon:           &#937;     |   &#x3a9;
Blank Icon:         &#8250;   |   &#x203a;]], 280, 142, ImGuiInputTextFlags.ReadOnly)
		ImGui.EndGroup()

		ImGui.Spacing()
		ImGui.BeginGroup()
		ImGui.Text("颜色")

		for i, textcolor in ipairs(ReN_Color) do
			if (i - 1) % 4 ~= 0 then ImGui.SameLine() end

			if ImGui.ColorButton(textcolor.bName, textcolor.bCol, 64) then
				if selected_prop ~= nil or OR_selected > 0 then
					New_Name = New_Name .. textcolor.tColf
				else
					notify.error("TinkerScript - 改名", "请先选择一个目标！", 3000)
				end
			end if ImGui.IsItemHovered() then ImGui.SetTooltip(textcolor.bTip..": "..textcolor.tColf) end
		end
		ImGui.EndGroup()
		ImGui.Spacing()
		end

		ImGui.EndTabItem()
	end

	if ImGui.BeginTabItem("杂项") then

		ImGui.Text("杂项")ImGui.Separator()ImGui.Spacing()

		commandmgr.get_command("DuffelBagSave"):draw()
		commandmgr.get_command("noclip_anim"):draw()
		ImGui.SameLine()
		commandmgr.get_command("noclip_onscreen"):draw()
		if commandmgr.get_command("noclip_onscreen"):get_value() then ImGui.SameLine() NoClipWindowTop = ImGui.Checkbox("顶部", NoClipWindowTop) end

		commandmgr.get_command("rapidoxidation"):draw()
		if commandmgr.get_command("rapidoxidation"):get_value() then
			ImGui.SameLine() commandmgr.get_command("phoenixnoclip"):draw()
		end

		commandmgr.get_command("tinyplayer"):draw()
		if commandmgr.get_command("tinyplayer"):get_value() then
			ImGui.SameLine() commandmgr.get_command("tinyp_ptfxtoggle"):draw()
			if commandmgr.get_command("tinyp_ptfxtoggle"):get_value() then
				ImGui.SameLine() commandmgr.get_command("tinyp_ptfxlist"):draw()
			end
		end

		PTFX = commandmgr.get_command("tinyp_ptfxlist"):get_value()

		ImGui.SameLine(0, 200)
		ImGui.PushStyleColor(ImGuiCol.Button, 0, 0, 0, 0)
		ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0, 0.5, 1, 0.05)
		ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0, 0, 0, 0)
		if ImGui.Button(" ##ModestMenuWelcomeMsg") then
			script.run_in_callback(function()
				for i = 1, 60*9 do
					GRAPHICS.DRAW_RECT(xPos, yPos, BoxWidth, BoxHeight, 0, 0, 0, 200, 1)
					GRAPHICS.DRAW_SPRITE("shared", "info_icon_32", 0.763, 0.090, 0.02, 0.036, 0.0, 255, 255, 255, 255, 0, 0)
					ModestMenu(MM_msg, 0.756, 0.048)
					script.yield(0)
				end
			end)
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("唤起回忆") end
		ImGui.PopStyleColor()ImGui.PopStyleColor()ImGui.PopStyleColor()

		commandmgr.get_command("hiddenlocs"):draw()
		if commandmgr.get_command("hiddenlocs"):get_value() then
			CurPlayerCoords()
			ImGui.SetNextItemWidth(240)
			ImGui.InputText("当前坐标", string.format("x: %.2f,   y: %.2f,   z: %.2f", PlaCoords.x, PlaCoords.y, PlaCoords.z), ImGuiInputTextFlags.ReadOnly)

			ImGui.SameLine()
			if ImGui.Button("复制到剪贴板") then
				ImGui.SetClipboardText(string.format("%.2f, %.2f, %.2f", PlaCoords.x, PlaCoords.y, PlaCoords.z))
				notify.success("TinkerScript - 隐藏地点", "当前坐标已复制到剪贴板！", 3000)
			end

			if ImGui.BeginListBox("##hiddenlocsbox"..nomoretreeplease, 354, 232) then
				for _, LocServ in ipairs(LocationCoords) do
					if ImGui.Selectable(LocServ.LocName) then
						PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), LocServ.LocCoords[1], LocServ.LocCoords[2], LocServ.LocCoords[3])
					end if ImGui.IsItemHovered() then ImGui.SetTooltip(LocServ.LocDesc) end
				end
				ImGui.EndListBox()
			end
		end

		ImGui.EndTabItem()
	end
	ImGui.EndTabBar()
end)

---|| Biz-Teroids ||------------------------------------------------------------------------------

local HGgoodtypeT = {
	{ 0, "动物材料" },
	{ 1, "艺术品与古董" },
	{ 2, "化学品" },
	{ 3, "假冒商品" },
	{ 4, "珠宝与宝石" },
	{ 5, "医疗用品" },
	{ 6, "麻醉品 " },
	{ 7, "烟草与酒精" }
}

local WHgoodtypeT = {
	{ 0,  "医疗用品" },
	{ 1,  "烟草与酒精" },
	{ 2,  "艺术品与古董" },
	{ 3,  "电子产品" },
	{ 4,  "武器与弹药" },
	{ 5,  "麻醉品" },
	{ 6,  "宝石" },
	{ 7,  "动物材料" },
	{ 8,  "假冒商品" },
	{ 9,  "珠宝" },
	{ 10, "金条" }
}

local PropGlob = {
	whprop = 1845347 + 260 + 128,
	hangarprop = 1845347 + 260 + 304,
	bbizprop = 1845347 + 260 + 205,
	ncprop = 1845347 + 260 + 364,
	syprop = 1845347 + 260 + 504,
	mcbar = 1845347 + 260 + 394
}

local BizRe_RestockSU = {
	methmc = {
		manuprod = {1370024930, 1944848251, 1577999189, 1678460062},
		manucost = {-730135062, -660914094}
	},
	weedmc = {
		manuprod = {-635596193, -1694873660, 1575359233, 102029883},
		manucost = {-373027461, 1195564032}
	},
	crackmc = {
		manuprod = {702413484, 2070857577, -1539796661, 396217128},
		manucost = {-161187879, 1500658261}
	},
	cashmc = {
		manuprod = {1310272402, 1690071006, -1454958662, -1913260493},
		manucost = {631857857, -891680742}
	},
	fakeidmc = {
		manuprod = {-959721585, 1672482518, -518264160, 489023341},
		manucost = {-1839004359, -192060672}
	},
	bunkermc = {
		manuprod = {215868155, 631477612, 818645907},
		manucost = {-1652502760, 1647327744}
	},
	acidmc = {
		manuprod = {-672998848, 494316332, -40235252},
		manucost = {-1506354854, -993236072}
	},
	nightclub = {
		manuprod = {-147565853, -1390027611, -1292210552, 1007184806, 18969287, -863328938, 1607981264}
	}
}

local function OpenMCT()
	if ScriptGlobal(1951071):get_int() ~= 0 then -- Credits to PazzoG
		ScriptGlobal(1951071):set_int(0)
	end
	scripts.start_new_script("apparcadebusinesshub", 1424)
	script.run_in_callback(function()
		while scripts.is_active("apparcadebusinesshub") do
			if ScriptGlobal(1971195):get_int() == -1 then
				ScriptGlobal(1971195):set_int(0)
			end
			script.yield(0)
		end
	end)
end


local BizRe_running = false
local BizRe_HGonly = false
local BizRe_WHonly = false
local BizRe_cancel = true
local function BizRe_lotoggle()
	if BizRe_cancel then
		notify.warn("TinkerScript - 商务强化", "已取消。", 3000)
		BizRe_running = false
		STATS.STAT_SAVE(0, 0, 3, 0)
	end
	return BizRe_cancel
end

local MCbizlocs = {
	[1] = "佩里托湾", [6] = "驴子高地", [11] = "大塞诺拉沙漠", [16] = "码头区",
	[2] = "奇力耶德山", [7] = "好麦坞市区", [12] = "圣奇安斯基山脉", [17] = "极乐岛",
	[3] = "佩里托湾", [8] = "晨木", [13] = "阿拉莫海", [18] = "极乐岛",
	[4] = "佩里托湾", [9] = "维斯特奇运河", [14] = "大塞诺拉沙漠", [19] = "柏树平地",
	[5] = "佩里托湾", [10] = "纺织城", [15] = "葡萄籽", [20] = "极乐岛",
	[21] = "大塞诺拉油田", [22] = "大塞诺拉沙漠", [23] = "68 号公路", [24] = "农场", [25] = "烟树路", [26] = "汤姆森废车场", [27] = "葡萄籽", [28] = "佩里托森林", [29] = "拉顿峡谷", [30] = "赞库多湖", [31] = "楚马什"
}

local MCbiz = {
	{ MCBname = "冰毒实验室", 		ID = { 1, 6, 11, 16 },  Blip = Blips.Property.PRODUCTION_METH.ID },
	{ MCBname = "大麻农场", 				ID = { 2, 7, 12, 17 },  Blip = Blips.Property.PRODUCTION_WEED.ID },
	{ MCBname = "可卡因藏匿处", 			ID = { 3, 8, 13, 18 },  Blip = Blips.Property.PRODUCTION_CRACK.ID },
	{ MCBname = "假钞工厂", ID = { 4, 9, 14, 19 },  Blip = Blips.Property.PRODUCTION_MONEY.ID },
	{ MCBname = "文件伪造办公室", 	ID = { 5, 10, 15, 20 }, Blip = Blips.Property.PRODUCTION_FAKE_ID.ID },
	{ MCBname = "地堡", 					ID = { 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 }, Blip = Blips.Property.PROPERTY_BUNKER.ID }
}

local function GetBusinessSlot(businessName, Blog)
	for _, business in ipairs(MCbiz) do -- Credit to Silenthy6 (SilentSalo) for this part https://www.unknowncheats.me/forum/4380348-post701.html (it was too much for my brain) | It's been a year and I sill don't add other businesses
		if business.MCBname == businessName then
			for i = 0, 5 do
				local slot = stats.get_int("MPX_FACTORYSLOT"..i)
				if slot > 0 then
					for _, id in ipairs(business.ID) do
						if slot == id then
							if Blog then
								local mcbizloc = MCbizlocs[slot]
								log.info(string.format("\r\27[1;36mBusiness:\27[1;92m %-25s \27[m| \27[1;36mLocation:\27[m %-27s | \27[1;36mSlot:\27[m %d | \27[1;36mID:\27[m %s            \r", businessName, mcbizloc, i, slot))
							end
							return true, i
						end
					end
				end
			end
		end
	end
end

local function BizRe_Hangar()
	if ScriptGlobal(PropGlob.hangarprop):at(PLAYER.PLAYER_ID(), 884):get_int() >= 1 then
		if not stats.get_packed_bool(15966) then stats.set_packed_bool(15966, true) end
		if ScriptGlobal(PropGlob.hangarprop + 3):at(PLAYER.PLAYER_ID(), 884):get_int() <= 49 then
			if HGWHmaxgoods then
				if HGsetgood then
					ScriptGlobal(1882787 + 8):set_int(HGgoodtype)
				end
				ScriptGlobal(1882787 + 7):set_int(50)
				stats.set_packed_bool(36828, true)
				STATS.STAT_SAVE(0, 0, 3, 0)
				notify.success("成功！", "机库货物已补满！", 3000)
			else
				notify.info("TinkerScript - 商务强化", "已关闭“瞬间满仓”。机库将按混合货物补货。", 3000)
				for HGl = 0, 49 do if BizRe_running and BizRe_lotoggle() then return end
					stats.set_packed_bool(36828, true)
					script.yield(1500)
				end
			end
		else
			notify.warn("哎呀！", "机库已是满仓。", 3000)
		end
		if BizRe_HGonly then BizRe_cancel = true BizRe_HGonly = false end
	else
		if BizRe_HGonly then BizRe_cancel = true BizRe_HGonly = false end
		notify.error("TinkerScript - 商务强化", "你还没有机库", 3000)
	end
end

local function BizRe_Warehouse()
	if ScriptGlobal(PropGlob.whprop):at(PLAYER.PLAYER_ID(), 884):at(0, 3):get_int() >= 1 then
		if HGWHmaxgoods then
			for WHp, c in ipairs({32359, 32360, 32361, 32362, 32363}) do if BizRe_running and BizRe_lotoggle() then return end
				if ScriptGlobal(PropGlob.whprop):at(PLAYER.PLAYER_ID(), 884):at(WHp - 1, 3):get_int() >= 1 then
					if BizRe_running and BizRe_lotoggle() then return end
					if ScriptGlobal(PropGlob.whprop + 1):at(PLAYER.PLAYER_ID(), 884):at(WHp - 1, 3):get_int() <= 110 then
						for i = 1, 2 do if BizRe_running and BizRe_lotoggle() then return end
							if WHsetgood then ScriptGlobal(1882762 + 16):set_int(WHgoodtype) end
							ScriptGlobal(1882762 + 13):set_int(111)
							stats.set_packed_bool(c, true)
							script.yield(2000)
						end
						STATS.STAT_SAVE(0, 0, 3, 0)
						notify.success("成功！", string.format("仓库(%d)货物已补满！", WHp))
					else
						notify.warn("哎呀！", string.format("仓库(%d)已是满仓。", WHp))
					end
				end
			end
			if BizRe_WHonly then BizRe_cancel = true BizRe_WHonly = false end
		else
			notify.info("TinkerScript - 商务强化", "已关闭“瞬间满仓”。仓库将按混合货物补货。", 3000) script.yield(3000)
			for WHl = 1, 111 do if BizRe_running and BizRe_lotoggle() then return end
				stats.set_packed_bool_range(32359, 32363, true)
				script.yield(1200)
			end
			if BizRe_WHonly then BizRe_cancel = true BizRe_WHonly = false end
		end
	else
		if BizRe_WHonly then BizRe_cancel = true BizRe_WHonly = false end
		notify.error("TinkerScript - 商务强化", "你还没有仓库", 3000)
	end
end

local function BizRe_MCresup()
	tunables.set_int(1712674055, 1)
	for b = 0, 7 do
		if ScriptGlobal(PropGlob.bbizprop):at(PLAYER.PLAYER_ID(), 884):at(b, 13):get_int() >= 1 then
			for bsup = 1, 7 do
				ScriptGlobal(1673820 + bsup):set_int(1)
			end
		end
	end
	notify.success("成功！", "全部产业原材料已补满！", 3000)
end

local function BizRe_MCrestock()

	tunables.set_int(728170457, 1)
	tunables.set_int(-2094564985, 1)

	local methmc, slot = GetBusinessSlot("冰毒实验室", true)
	if methmc then
		if ScriptGlobal(PropGlob.bbizprop + 1):at(PLAYER.PLAYER_ID(), 884):at(slot, 13):get_int() <= 19 then
			for _, manuprod in ipairs(BizRe_RestockSU.methmc.manuprod) do
				tunables.set_int(manuprod, 1)
			end
			for _, manucost in ipairs(BizRe_RestockSU.methmc.manucost) do
				tunables.set_int(manucost, 1)
			end
			script.yield(2000)
			notify.success("成功！", "Meth Business restock ready!\nPlease restart your business.", 3000)
		else
			notify.warn("哎呀！", "冰毒实验室库存已是满仓！", 3000)
		end
	else
		notify.error("TinkerScript - 商务强化", "你还没有冰毒实验室。", 3000)
	end

	if BizRe_running and BizRe_lotoggle() then return end
	local weedmc, slot = GetBusinessSlot("大麻农场", true)
	if weedmc then
		if ScriptGlobal(PropGlob.bbizprop + 1):at(PLAYER.PLAYER_ID(), 884):at(slot, 13):get_int() <= 79 then
			for _, manuprod in ipairs(BizRe_RestockSU.weedmc.manuprod) do
				tunables.set_int(manuprod, 1)
			end
			for _, manucost in ipairs(BizRe_RestockSU.weedmc.manucost) do
				tunables.set_int(manucost, 1)
			end
			script.yield(2000)
			notify.success("成功！", "Weed Business restock ready!\nPlease restart your business.", 3000)
		else
			notify.warn("哎呀！", "大麻农场库存已是满仓！", 3000)
		end
	else
		notify.error("TinkerScript - 商务强化", "你还没有大麻农场。", 3000)
	end

	if BizRe_running and BizRe_lotoggle() then return end
	local crackmc, slot = GetBusinessSlot("可卡因藏匿处", true)
	if crackmc then
		if ScriptGlobal(PropGlob.bbizprop + 1):at(PLAYER.PLAYER_ID(), 884):at(slot, 13):get_int() <= 9 then
			for _, manuprod in ipairs(BizRe_RestockSU.crackmc.manuprod) do
				tunables.set_int(manuprod, 1)
			end
			for _, manucost in ipairs(BizRe_RestockSU.crackmc.manucost) do
				tunables.set_int(manucost, 1)
			end
			script.yield(2000)
			notify.success("成功！", "Coke Business restock ready!\nPlease restart your business.", 3000)
		else
			notify.warn("哎呀！", "可卡因藏匿处库存已是满仓！", 3000)
		end
	else
		notify.error("TinkerScript - 商务强化", "你还没有可卡因藏匿处。", 3000)
	end

	if BizRe_running and BizRe_lotoggle() then return end
	local cashmc, slot = GetBusinessSlot("假钞工厂", true)
	if cashmc then
		if ScriptGlobal(PropGlob.bbizprop + 1):at(PLAYER.PLAYER_ID(), 884):at(slot, 13):get_int() <= 39 then
			for _, manuprod in ipairs(BizRe_RestockSU.cashmc.manuprod) do
				tunables.set_int(manuprod, 1)
			end
			for _, manucost in ipairs(BizRe_RestockSU.cashmc.manucost) do
				tunables.set_int(manucost, 1)
			end
			script.yield(2000)
			notify.success("成功！", "Cash Business restock ready!\nPlease restart your business.", 3000)
		else
			notify.warn("哎呀！", "假钞工厂库存已是满仓！", 3000)
		end
	else
		notify.error("TinkerScript - 商务强化", "你还没有假钞工厂。", 3000)
	end

	if BizRe_running and BizRe_lotoggle() then return end
	local fakeidmc, slot = GetBusinessSlot("文件伪造办公室", true)
	if fakeidmc then
		if ScriptGlobal(PropGlob.bbizprop + 1):at(PLAYER.PLAYER_ID(), 884):at(slot, 13):get_int() <= 59 then
			for _, manuprod in ipairs(BizRe_RestockSU.fakeidmc.manuprod) do
				tunables.set_int(manuprod, 1)
			end
			for _, manucost in ipairs(BizRe_RestockSU.fakeidmc.manucost) do
				tunables.set_int(manucost, 1)
			end
			script.yield(2000)
			notify.success("成功！", "Documents Business restock ready!\nPlease restart your business.", 3000)
		else
			notify.warn("哎呀！", "文件伪造办公室库存已是满仓！", 3000)
		end
	else
		notify.error("TinkerScript - 商务强化", "你还没有文件伪造办公室。", 3000)
	end

	if BizRe_running and BizRe_lotoggle() then return end
	local bunkermc, slot = GetBusinessSlot("地堡", true)
	if bunkermc then
		if ScriptGlobal(PropGlob.bbizprop + 1):at(PLAYER.PLAYER_ID(), 884):at(slot, 13):get_int() <= 99 then
			for _, manuprod in ipairs(BizRe_RestockSU.bunkermc.manuprod) do
				tunables.set_int(manuprod, 1)
			end
			for _, manucost in ipairs(BizRe_RestockSU.bunkermc.manucost) do
				tunables.set_int(manucost, 1)
			end
			script.yield(2000)
			notify.success("成功！", "Bunker Business restock ready!\nPlease restart your business.", 3000)
		end
	else
		notify.error("TinkerScript - 商务强化", "你还没有地堡。", 3000)
	end

	if BizRe_running and BizRe_lotoggle() then return end
	if ScriptGlobal(PropGlob.bbizprop):at(PLAYER.PLAYER_ID(), 884):at(6, 13):get_int() >= 1 then
		if not stats.get_packed_bool(36689) then stats.set_packed_bool(36689, true) end
		if ScriptGlobal(PropGlob.bbizprop + 1):at(PLAYER.PLAYER_ID(), 884):at(6, 13):get_int() <= 159 then
			for _, manuprod in ipairs(BizRe_RestockSU.acidmc.manuprod) do
				tunables.set_int(manuprod, 1)
			end
			for _, manucost in ipairs(BizRe_RestockSU.acidmc.manucost) do
				tunables.set_int(manucost, 1)
			end
			script.yield(2000)
			notify.success("成功！", "Acid Lab Business restock ready!\nPlease restart your business.", 3000)
		end
	else
		notify.error("TinkerScript - 商务强化", "你还没有致幻实验室。", 3000)
	end
end


local function BizRe_NCrestock()
	if ScriptGlobal(PropGlob.ncprop):at(PLAYER.PLAYER_ID(), 884):get_int() >= 1 then
		if ScriptGlobal(PropGlob.ncprop + 4):get_float() <= 99.0 then
			stats.set_int("MPX_CLUB_POPULARITY", 1000)
			notify.success("成功！", "夜总会人气已拉满！", 3000)
		end
		for _, manuprod in ipairs(BizRe_RestockSU.nightclub.manuprod) do
			tunables.set_int(manuprod, 1)
		end
		notify.success("成功！", "Nightclub restock ready!\nPlease re-assign your technicians.", 3000)
		script.yield(2000)
	else
		notify.error("TinkerScript - 商务强化", "你还没有夜总会。", 3000)
	end
end

local function BizRe_SalvPop()
	if ScriptGlobal(PropGlob.syprop):at(PLAYER.PLAYER_ID(), 884):get_int() >= 1 then
		stats.set_packed_int(51051, 100)
		notify.success("成功！", "拆车场热度已拉满！", 3000)
	else
		notify.error("TinkerScript - 商务强化", "你还没有拆车场。", 3000)
	end
end

local function BizRe_MFheat()
	if stats.get_int("MPX_SB_CAR_WASH_OWNED") == 1 then
		for tycoonh = 24924, 24926 do
			stats.set_packed_int(tycoonh, 0)
		end
		notify.success("成功！", "洗钱产业热度已清除！", 3000)
		script.yield(2000)
	else
		notify.error("TinkerScript - 商务强化", "你还没有“亲手洗车行”。", 3000)
	end
end

local BizRe_count = true
local function BusinessOnSteroids()

local function Countdown()
	local cd_cls = "\r                                                                                \r"
	for i = 10, 1, -1 do if BizRe_lotoggle() then return end
		notify.info("TinkerScript - 商务强化（ImagineNothing 制作）", "主逻辑将在倒计时结束后启动 "..i..".", 999)
		log.info(cd_cls.."主逻辑将在倒计时结束后启动： "..i.."  \r\27[1A") script.yield(999)
	end
	log.info(cd_cls.."\27[1AStarting...                           \r")
	log.info(cd_cls.."\27[1A\27[42;30m Start \27[m                           \r\n")
end

	log.warn("\r                                                                                 \r"..[[
           __     This script will Restock/Refill:
  \ ______/ V`-,  ]].."\27[38;5;124mHangar and Warehouses\27[m\n"..[[
   }        /~~  ]].."\27[32mMC Businesses\27[m\n"..[[
  /_)^ --,r'    ]].."\27[95mNightclub\27[m and \27[95mPopularity Bar\27[m"..[[

 |b      |b   ]].."\27[38;5;27mSalvage Yard Reputation\27[m"..[[
 ]].."Remove heat levels: \27[38;5;208mMoney Fronts Businesses\27[m"..[[
 ]].."\n\27[2;37;3mYOU MUST RESTART YOUR MC BUSINESSES AND RE-ASSIGN YOUR NIGHTCLUB TECHS AFTER RUNNING THE SCRIPT IF *RESTOCK* IS ENABLED.\27[m\n\n")--\27[1;100;37m


	if BizRe_count then Countdown() end

	if BizRe_lotoggle() then return end

	if HGWHrestock then
		BizRe_Hangar()
		if BizRe_lotoggle() then return end
		BizRe_Warehouse()
	else
		notify.info("TinkerScript - 商务强化", "机库与仓库补货已关闭，跳过……", 3000)
	end

	script.yield(3000)

	if BizRe_lotoggle() then return end
	if MCresup then BizRe_MCresup() else notify.info("TinkerScript - 商务强化", "摩托帮产业原材料补给已关闭，跳过……", 3000) end

	script.yield(3000)

	if BizRe_lotoggle() then return end
	if MCrestock then
		notify.info("TinkerScript - 商务强化", "摩托帮产业备货已开启。", 3000)
		BizRe_MCrestock()
	else
		notify.info("TinkerScript - 商务强化", "摩托帮产业备货已关闭，跳过……", 3000)
	end

	script.yield(3000)

	if BizRe_lotoggle() then return end
	if NCgoods then BizRe_NCrestock() else notify.info("TinkerScript - 商务强化", "夜总会备货已关闭，跳过……", 3000) end

	script.yield(3000)

	BizRe_SalvPop()
	if BizRe_lotoggle() then return end
	BizRe_MFheat()

	STATS.STAT_SAVE(0, 0, 3, 0)
	BizRe_cancel = true
	BizRe_running = false

	log.info("\r                                                                                \r\n\r\27[1B\27[42;30m End \27[m\n")
	notify.success("TinkerScript - 商务强化", "已完成！", 3000)

end

commandmgr.add_bool_command("HGWH_restock", "机库/仓库补货", "是否自动补满你的机库与仓库货物？", true, nil)
commandmgr.add_bool_command("HGWH_maxgoods", "机库/仓库瞬间满仓", "Should the script instantly max out your Hangar and Warehouses stock?\nIf disabled, restock will be a bit slower, but you'll receive mixed goods", true, nil)
commandmgr.add_bool_command("HG_setgood", "机库指定货物", "关闭时，机库货物类型将随机", false, nil)
commandmgr.add_bool_command("WH_setgood", "仓库指定货物", "关闭时，仓库货物类型将随机", false, nil)
commandmgr.add_bool_command("MC_resup", "摩托帮产业补原料", "是否自动为全部摩托帮产业补给原材料？", true, nil)
commandmgr.add_bool_command("MC_restock", "摩托帮产业备货", "是否自动备货全部摩托帮产业？", true, nil)
commandmgr.add_bool_command("NC_goods", "夜总会备货", "是否自动补满夜总会库存？", true, nil)
commandmgr.add_list_command("HG_goodtype", "机库货物类型", "", HGgoodtypeT, 0, nil)
commandmgr.add_list_command("WH_goodtype", "仓库货物类型", "", WHgoodtypeT, 0, nil)

local CEO_instantbuy_amount = 1

local ncgotgood = false
local ncstealamount = 1
local NC_goodstype = {
	{ 1, "货物与运输", 	goodTunable = 910739098,   goodDefaultAmount =  1},
	{ 2, "体育用品", 			goodTunable = -188055253,  goodDefaultAmount =  2},
	{ 3, "南美进口货", 	goodTunable = -1924406700, goodDefaultAmount =  1},
	{ 4, "药品研究", goodTunable = 1386540504,  goodDefaultAmount =  1},
	{ 5, "有机农产品", 		goodTunable = -1407470929, goodDefaultAmount =  7},
	{ 6, "印刷与复印", 		goodTunable = -681418413,  goodDefaultAmount =  10},
	{ 7, "假钞制作", 			goodTunable = -655270102,  goodDefaultAmount =  3}
}

commandmgr.add_list_command("NC_goodtype", "货物##ncgoodtype", "", NC_goodstype, 0, function()
	local NC_goodst = commandmgr.get_command("NC_goodtype"):get_value()
	if scripts.is_active("fm_content_club_source") then
		ScriptLocal("fm_content_club_source", 3726 + 728 + 3):set_int(NC_goodst - 1)
		ncstealamount = NC_goodstype[NC_goodst].goodDefaultAmount
	end
end)

TS_Bizteroids:imgui(function() if not IsOnline() then ImGui.TextDisabled("请先进入自由模式战局。") return end

	HGWHrestock = commandmgr.get_command("HGWH_restock"):get_value()
	HGWHmaxgoods = commandmgr.get_command("HGWH_maxgoods"):get_value()
	HGsetgood = commandmgr.get_command("HG_setgood"):get_value()
	WHsetgood = commandmgr.get_command("WH_setgood"):get_value()
	MCresup = commandmgr.get_command("MC_resup"):get_value()
	MCrestock = commandmgr.get_command("MC_restock"):get_value()
	NCgoods = commandmgr.get_command("NC_goods"):get_value()
	HGgoodtype = commandmgr.get_command("HG_goodtype"):get_value()
	WHgoodtype = commandmgr.get_command("WH_goodtype"):get_value()

	ImGui.Text("控制面板")ImGui.Separator()ImGui.Spacing()

	ImGui.BeginGroup()
	commandmgr.get_command("HGWH_restock"):draw()
	commandmgr.get_command("HGWH_maxgoods"):draw()
	commandmgr.get_command("HG_setgood"):draw()

	if commandmgr.get_command("HG_setgood"):get_value() then
		commandmgr.get_command("HG_goodtype"):draw()
		ImGui.Spacing()
	end

	commandmgr.get_command("WH_setgood"):draw()

	if commandmgr.get_command("WH_setgood"):get_value() then
		commandmgr.get_command("WH_goodtype"):draw()
		ImGui.Spacing()
	end

	commandmgr.get_command("MC_resup"):draw()
	commandmgr.get_command("MC_restock"):draw()
	commandmgr.get_command("NC_goods"):draw()

	ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()
	if BizRe_cancel and ImGui.Button("运行！", 80, 40) then
		BizRe_running = true
		BizRe_cancel = false
		script.run_in_callback(BusinessOnSteroids)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("产业大祝福。") end

	if BizRe_cancel then
		ImGui.SameLine()
		ImGui.BeginGroup()
		ImGui.Spacing()ImGui.Spacing()
		BizRe_count = ImGui.Checkbox("倒计时", BizRe_count)
		ImGui.EndGroup()
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("关闭运行“商务强化”前的 10 秒倒计时") end

	if not BizRe_cancel and BizRe_running then
		if ImGui.Button("取消", 80, 40) then
			BizRe_cancel = true
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("取消“商务强化”流程。") end
	end
	ImGui.EndGroup()

    ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()
	ImGui.Text("单项功能")ImGui.Separator()ImGui.Spacing()

	ImGui.BeginGroup()
	if ImGui.Button("主控终端", 185) then
		script.run_in_callback(OpenMCT)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("管理你的各项产业。") end ImGui.SameLine()

	if ImGui.Button("已拥有的产业", 185) then
		for _, Business in ipairs(MCbiz) do
			GetBusinessSlot(Business.MCBname, true)
		end
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("在控制台列出你拥有的产业。") end ImGui.NewLine()

	if ImGui.Button("机库补货", 185) then
		BizRe_HGonly = true
		BizRe_running = true
		BizRe_cancel = false
		script.run_in_callback(BizRe_Hangar)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("补满你的机库货物。") end ImGui.SameLine()

	if ImGui.Button("仓库补货", 185) then
		BizRe_WHonly = true
		BizRe_running = true
		BizRe_cancel = false
		script.run_in_callback(BizRe_Warehouse)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("补满你的仓库货物。") end

	if ImGui.Button("摩托帮产业备货", 185) then
		BizRe_running = true
		BizRe_cancel = false
		script.run_in_callback(BizRe_MCrestock)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("补满全部摩托帮产业") end ImGui.SameLine()

	if ImGui.Button("摩托帮产业补给", 185) then
		BizRe_MCresup()
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("为全部摩托帮产业补满原材料。") end

	if ImGui.Button("夜总会备货", 185) then
		script.run_in_callback(BizRe_NCrestock)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("补满你的夜总会库存。") end ImGui.SameLine()

	if ImGui.Button("产业热度", 185) then
		script.run_in_callback(BizRe_MFheat)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("清除洗钱产业的热度。") end

	if ImGui.Button("夜总会人气", 185) then
		if ScriptGlobal(PropGlob.ncprop):at(PLAYER.PLAYER_ID(), 884):get_int() >= 1 then
			if stats.get_int("MPX_CLUB_POPULARITY") <= 999 then
				stats.set_int("MPX_CLUB_POPULARITY", 1000)
				notify.success("成功！", "夜总会人气已拉满！", 3000)
			end
		else
			notify.error("TinkerScript - 商务强化", "你还没有夜总会。", 3000)
		end
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("把夜总会人气拉满。") end ImGui.SameLine()

	if ImGui.Button("拆车场热度", 185) then
		BizRe_SalvPop()
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("把拆车场热度拉满。") end
	ImGui.EndGroup()

	ImGui.SameLine()
	ImGui.Spacing()
	ImGui.SameLine(0, 3.8)

	ImGui.BeginGroup()
	if ImGui.TreeNodeEx("传送至产业  ##"..nomoretreeplease, 8219) then
		ImGui.NewLine()
		ImGui.Spacing()
		ImGui.SameLine(-3.8, 0)
		if ImGui.BeginChild("##bizteroidstptoprop", 210, 112) then

			if ImGui.Button("机库", 193) then
				if stats.get_int("MPX_HANGAR_OWNED") >= 1 then
					TpToBlip(false, Blips.Property.SM_HANGAR.ID, false)
				else
					notify.error("TinkerScripts - 商务强化", "你还没有机库。")
				end
			end

			if ImGui.Button("仓库", 193) then
				if stats.get_int("MPX_WARHOUSESLOT0") >= 1 then
					TpToBlip(false, Blips.Property.WAREHOUSE.ID, false)
				else
					notify.error("TinkerScripts - 商务强化", "你还没有仓库。")
				end
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("其他仓库懒得加了，抱歉。") end

			for _, Business in ipairs(MCbiz) do
				if ImGui.Button(Business.MCBname, 193) then
					local owned, _ = GetBusinessSlot(Business.MCBname, false)
					if owned then
						TpToBlip(false, Business.Blip, false)
					else
						notify.error("TinkerScripts - 商务强化", string.format("你还没有 %s。", Business.MCBname))
					end
				end
			end

			if ImGui.Button("夜总会", 193) then
				if stats.get_int("MPX_NIGHTCLUB_OWNED") >= 1 then
					TpToBlip(false, Blips.Property.BAT_CLUB_PROPERTY.ID, false)
				else
					notify.error("TinkerScripts - 商务强化", "夜总会。")
				end
			end

			for _, Mfronts in ipairs({"SMOKE_SHOP", "HELITOURS", "CAR_WASH_BUSINESS"}) do
				local Business = Blips.Property[Mfronts]
				if ImGui.Button(Business.Name, 193) then
					if stats.get_int(Business.Stat) == 1 then
						TpToBlip(false, Business.ID, false)
					else
						notify.error("TinkerScripts - 商务强化", string.format("你还没有 %s。", Business.Name))
					end
				end
			end

		end ImGui.EndChild()
	end
	ImGui.EndGroup()

	ImGui.SetWindowFontScale(0.6)
	ImGui.TextDisabled("\nYOU MUST RESTART YOUR MC BUSINESSES AND RE-ASSIGN YOUR NIGHTCLUB TECHS IF *RESTOCK* IS ENABLED")
	ImGui.SetWindowFontScale(1.0)

	ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()
	ImGui.Text("即时出售")ImGui.Separator()ImGui.Spacing()

	if ImGui.Button("特种货物##sell", 185) then
		if scripts.is_active("gb_contraband_sell") then
			ScriptLocal("gb_contraband_sell", 576 + 1):set_int(67230)
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次特种货物出售任务！", 3000)
		end
	end

	ImGui.SameLine() if ImGui.Button("空运货物（空运）", 185) then
		if scripts.is_active("gb_smuggler") then
			ScriptLocal("gb_smuggler", 1998 + 1035):set_int(0)
			ScriptLocal("gb_smuggler", 1998 + 1078):set_int(1)
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次空运货物出售任务！", 3000)
		end
	end

	if ImGui.Button("武器", 185) then
		if scripts.is_active("gb_gunrunning") then
			ScriptLocal("gb_gunrunning", 1275 + 774):set_int(0)
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次武器出售任务！", 3000)
		end
	end

	ImGui.SameLine() if ImGui.Button("摩托帮产业产品", 185) then
		if scripts.is_active("gb_biker_contraband_sell") then
			ScriptLocal("gb_biker_contraband_sell", 738 + 122):set_int(ScriptLocal("gb_biker_contraband_sell", 738 + 174):get_int())
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次产品出售任务！", 3000)
		end
	end

	if ImGui.Button("夜总会货物", 185) then
		if scripts.is_active("business_battles_sell") then
			ScriptLocal("business_battles_sell", 2395 + 205):set_int(0)
			ScriptLocal("business_battles_sell", 2395 + 204):set_int(1)
			ScriptLocal("business_battles_sell", 2395 + 33):set_int(0)
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次货物出售任务！", 3000)
		end
	end

	if CAMERA.IS_SCREEN_FADED_OUT() and (scripts.is_active("gb_biker_contraband_sell") or scripts.is_active("business_battles_sell")) then
		script.run_in_callback(function()
			CAMERA.DO_SCREEN_FADE_IN(500)
			script.yield(2000)
			CAMERA.DO_SCREEN_FADE_IN(500)
		end)
	end

	ImGui.SameLine() if CAMERA.IS_SCREEN_FADED_OUT() and (scripts.is_active("gb_biker_contraband_sell") or scripts.is_active("business_battles_sell")) then
		if ImGui.Button("画面淡入") then
			CAMERA.DO_SCREEN_FADE_IN(500)
		end
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("卡黑屏时用这个。") end

	ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()
	ImGui.Text("即时购买")ImGui.Separator()ImGui.Spacing()

	if ImGui.Button("特种货物##buy", 185) then
		if scripts.is_active("gb_contraband_buy") then
			ScriptLocal("gb_contraband_buy", 634 + 5):set_int(1)
			ScriptLocal("gb_contraband_buy", 634 + 1):set_int(CEO_instantbuy_amount)
			ScriptLocal("gb_contraband_buy", 634 + 191):set_int(6)
			ScriptLocal("gb_contraband_buy", 634 + 192):set_int(4)
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次特种货物采购任务！", 3000)
		end
	end

	ImGui.PushItemWidth(100) ImGui.SameLine() CEO_instantbuy_amount = ImGui.InputInt("箱数", CEO_instantbuy_amount) ImGui.PopItemWidth()

	if ImGui.Button("夜总会货物##steal", 185) then
		if scripts.is_active("fm_content_club_source") then
			script.run_in_callback(function()
				TpToBlip(true, Blips.LEVEL, false)
				script.yield(500) TpToBlip(true, Blips.CONTRABAND, false)
				CurPlayerCoords()
				local veh = VEHICLE.GET_RANDOM_VEHICLE_IN_SPHERE(PlaCoords.x, PlaCoords.y, PlaCoords.z, 10, 2053223216, 101247)
				if Entity(veh):get_model() == 2053223216 then
					local drivernomore = VEHICLE.GET_PED_IN_VEHICLE_SEAT(veh, -1, 0)
					if not Vehicle(veh):is_seat_free(-1) then Entity(drivernomore):delete() end
					script.yield(500) PED.SET_PED_INTO_VEHICLE(PLAYER.PLAYER_PED_ID(), veh, -1)
					TpToBlip(true, Blips.LEVEL, false)
				end
				script.yield(500) TpToBlip(true, Blips.LEVEL, false)
			end)
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次货物盗窃任务！", 3000)
		end
	end

	ImGui.SameLine() commandmgr.get_command("NC_goodtype"):draw()
	ImGui.SetNextItemWidth(100) ImGui.SameLine()
	ImGui.SameLine()
	ncstealamount = ImGui.InputInt("数量##ncgoodtype", ncstealamount)
	if ncstealamount == 0 then ncstealamount = 1 end

	if scripts.is_active("fm_content_club_source") then
		if not ncgotgood then
			script.run_in_callback(function()
				script.yield(300)
				local ncgoodtype = ScriptLocal("fm_content_club_source", 3726 + 728 + 3):get_int() + 1
				ncstealamount = tunables.get_int(NC_goodstype[ncgoodtype].goodTunable)
				commandmgr.get_command("NC_goodtype"):set_value(ncgoodtype)
				ncgotgood = true
			end)
		else
			tunables.set_int(NC_goodstype[commandmgr.get_command("NC_goodtype"):get_value()].goodTunable, ncstealamount)
		end
	else
		ncgotgood = false
	end

	if ImGui.Button("载具货物##steal", 185) then
		if scripts.is_active("gb_vehicle_export") then
			ScriptLocal("gb_vehicle_export", 889 + 459):set_int(12)
			script.run_in_callback(function()
				TpToBlip(true, Blips.LEVEL, false)
				script.yield(500) TpToBlip(true, Blips.SPORTS_CAR, false)
				Joyrider(10)
				script.yield(500) TpToBlip(true, Blips.LEVEL, false)
				players.get_local():set_wanted_level(0)
			end)
		else
			notify.info("TinkerScript - 商务强化", "你必须先开始一次载具货物盗窃任务！", 3000)
		end
	end

	ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()

	ImGui.Text("额外功能")ImGui.Separator()ImGui.Spacing()

	if ImGui.Button("触发多余武器零件") then
		GlobalSetBit(ScriptGlobal(2658296):at(PLAYER.PLAYER_ID(), 468):at(465), 1, 1)
	end

	if scripts.is_active("fm_content_ammunation") then
		ImGui.SameLine()
		if ImGui.Button("交付") then
			ScriptLocal("fm_content_ammunation", 2217 + 208):set_int(3)
			ScriptLocal("fm_content_ammunation", 2154 + 1):set_int(-1071628608)
		end
	end

	if ImGui.Button("触发酒吧收益") then
		script.run_in_callback(function()
			for i = 1, 5 do
				stats.set_packed_int(36620, 1)
				script.yield(1500)
				ScriptGlobal(1882760):set_int(1)
			end
		end)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("Fills your MC Clubhouse Bag\nCurrent Bar Earnings: $"..stats.get_int("MPX_BIKER_BAR_RESUPPLY_CASH")) end
end)

---|| Phone Master ||------------------------------------------------------------------------------

local function PhoneMaster(deftheme, theme, oldmodel)
	ScriptGlobal(80362):set_int(deftheme)
	ScriptGlobal(114990 + 14060):at(ScriptGlobal(21666):get_int(), 20):set_string(theme)
	ScriptGlobal(21609):set_int(oldmodel)
end

local function LetMeTakeASelfie()
	script.run_in_callback(function()
		if PAD.IS_CONTROL_JUST_PRESSED(0, 73) then
			ScriptGlobal(24076):set_int(1)
			script.yield(500)
			ScriptGlobal(24075):set_int(8)
			script.yield(2000)
			ScriptGlobal(24075):set_int(0)
		end
	end)
end

local pm_ContactOverrideList = {
	{ 104, "朱丽叶" },
	{ 105, "妮琪" },
	{ 106, "查丝蒂" },
	{ 107, "猎豹" },
	{ 108, "蓝宝石" },
	{ 109, "地狱火" },
	{ 110, "芙芙" },
	{ 111, "桃子" }
}

local pm_Themes = {
	{ 1, "默认主题",  "CELLPHONE_IFRUIT" },
	{ 2, "富兰克林", "CELLPHONE_BADGER" },
	{ 3, "迈克尔",  "CELLPHONE_IFRUIT" },
	{ 4, "崔佛",   "CELLPHONE_FACADE" },
	{ 5, "Celltowa", "CELLPHONE_PROLOGUE" }
}

local pm_SoundSets = {
	{ 1, "富兰克林",  "Phone_SoundSet_Franklin" },
	{ 2, "迈克尔（默认）", "Phone_SoundSet_Michael" },
	{ 3, "崔佛",   "Phone_SoundSet_Trevor" },
	{ 4, "序章", "Phone_SoundSet_Prologue" },
	{ 5, "默认（？）",  "Phone_SoundSet_Default" }
}

local pm_Background = {
	{ 0,  "帮会徽章" },
	{ 10,  "蓝色角纹" },
	{ 11,  "蓝色碎片" },
	{ 12,  "蓝色圆环" },
	{ 13, "菱形" },
	{ 14, "绿色辉光" },
	{ 9,  "绿色碎片" },
	{ 5,  "绿色方块" },
	{ 8,  "绿色三角" },
	{ 15, "橙色像素" },
	{ 7,  "橙色半调" },
	{ 6,  "橙色人字纹" },
	{ 16, "橙色三角" },
	{ 4,  "紫色辉光" },
	{ 17, "紫色格纹" }
}

local pm_ColorScheme = {
	{ 1, "蓝色" },
	{ 2, "绿色" },
	{ 3, "红色" },
	{ 4, "橙色" },
	{ 5, "灰色" },
	{ 6, "紫色" },
	{ 7, "粉色" }
}


local pm_celltowaon = false
local selected_theme = pm_Themes[1]
local function pm_AnimToggle(anim)

	PED.SET_PED_CONFIG_FLAG(PLAYER.PLAYER_PED_ID(), 242, not anim)
	PED.SET_PED_CONFIG_FLAG(PLAYER.PLAYER_PED_ID(), 243, not anim)
	PED.SET_PED_CONFIG_FLAG(PLAYER.PLAYER_PED_ID(), 244, not anim)

	if PAD.IS_CONTROL_JUST_PRESSED(0, 172) or PAD.IS_CONTROL_JUST_PRESSED(0, 181) then
		GTA.CELL_SET_INPUT(1)
	elseif PAD.IS_CONTROL_JUST_PRESSED(0, 173) or PAD.IS_CONTROL_JUST_PRESSED(0, 180) then
		GTA.CELL_SET_INPUT(2)
	elseif PAD.IS_CONTROL_JUST_PRESSED(0, 174) then
		GTA.CELL_SET_INPUT(3)
	elseif  PAD.IS_CONTROL_JUST_PRESSED(0, 175) then
		GTA.CELL_SET_INPUT(4)
	elseif PAD.IS_CONTROL_JUST_PRESSED(0, 176) or PAD.IS_CONTROL_JUST_PRESSED(0, 177) then
		GTA.CELL_SET_INPUT(5)
	end

	if scripts.is_active("appmpemail") then
		GTA.CELL_HORIZONTAL_MODE_TOGGLE(true)
	elseif not scripts.is_active("appmpemail") then
		if not commandmgr.get_command("pm_LeanKey"):get_value() then GTA.CELL_HORIZONTAL_MODE_TOGGLE(false) end
	end

	script.run_in_callback(function()
		if scripts.is_active("appemail") and not scripts.is_active("appmpemail") then
			if CAMERA.GET_FOLLOW_PED_CAM_VIEW_MODE() ~= 4 then
				PhoneMaster(1, selected_theme[3], 0)
			end
			SCRIPT.REQUEST_SCRIPT("appmpemail")
			script.yield(50)
			if SCRIPT.HAS_SCRIPT_LOADED("appmpemail") then
				scripts.run_as_script("appemail", function() SCRIPT.TERMINATE_THIS_THREAD() end)
				BUILTIN.START_NEW_SCRIPT("appmpemail", 2600)
				SCRIPT.SET_SCRIPT_AS_NO_LONGER_NEEDED("appmpemail")
			end
		end
	end)

	-- Closest I can get to hide the phone when player is in first person mode like in sp
	if commandmgr.get_command("pm_ThemeList"):get_value() == 1 then
		if ScriptGlobal(21666 + 1):get_int() == 3 then
			PhoneMaster(1, "CELLPHONE_IFRUIT", 0)
		elseif ScriptGlobal(21666 + 1):get_int() == 6 and CAMERA.GET_FOLLOW_PED_CAM_VIEW_MODE() ~= 4 then
			PhoneMaster(1, "CELLPHONE_IFRUIT", 0)
		elseif ScriptGlobal(21666 + 1):get_int() >= 6 and CAMERA.GET_FOLLOW_PED_CAM_VIEW_MODE() == 4 then
			PhoneMaster(0, "CELLPHONE_IFRUIT", 0)
		end
	elseif commandmgr.get_command("pm_ThemeList"):get_value() >= 1 then
		if ScriptGlobal(21666 + 1):get_int() == 6 then
			PhoneMaster(0, selected_theme[3], 0)
		end
	end

end

local pm_pitch = -90.0
local pm_yaw   = 0
local pm_roll  = 0
local pm_gotphonepos = false

local pm_isphonelean = false
local function pm_Lean()
	if PAD.IS_CONTROL_JUST_PRESSED(0, 183) then
		GTA.CELL_HORIZONTAL_MODE_TOGGLE(not pm_isphonelean)
		pm_isphonelean = not pm_isphonelean
	end
end

commandmgr.add_looped_command("pm_Anims", "手机动画", "启用手机动画", function()

	pm_AnimToggle(true)

end, function()
	if commandmgr.get_command("pm_ThemeList"):get_value() > 1 then
		commandmgr.get_command("pm_Anims"):set_value(false)
		notify.info("TinkerScript - 手机大师", "Enable \"Phone Animations\" before selecting a Theme.", 3000)
	end
	if commandmgr.get_command("pm_ModelCelltowa"):get_value() then
		notify.info("TinkerScript - 手机大师", "Enable \"Phone Animations\" before enabling \"Celltowa Phone Model\".", 3000)
	end

end, function()

	pm_AnimToggle(false)
	if commandmgr.get_command("pm_ThemeList"):get_value() == 1 then
		PhoneMaster(1, "CELLPHONE_IFRUIT", 0)
	end

end)

commandmgr.add_looped_command("pm_LeanKey", "手动横屏", "按 [G] 把手机切到横屏。", function()
	pm_Lean()
end, function()
end, function()
	pm_AnimToggle(false)
end)

commandmgr.add_looped_command("pm_ModelCelltowa", "Celltowa 手机模型", "呃…… iFruit", function()

	PhoneMaster(0, "CELLPHONE_IFRUIT", 1)

	if CAMERA.GET_FOLLOW_PED_CAM_VIEW_MODE() == 4 then
		pm_AnimToggle(true)
	end
	if commandmgr.get_command("pm_Anims"):get_value() then
		commandmgr.get_command("pm_Anims"):set_value(false)
	end
	if commandmgr.get_command("pm_ThemeList"):get_value() > 1 then
		commandmgr.get_command("pm_ThemeList"):set_value(1)
		notify.info("TinkerScript - 手机大师", "Disable \"Celltowa Phone Model\" before selecting a Phone Theme.", 3000)
	end

end, function()
	pm_celltowaon = true
end, function()

	pm_AnimToggle(false)
	PhoneMaster(1, "CELLPHONE_IFRUIT", 0)
	pm_celltowaon = false

end)

commandmgr.add_looped_command("pm_ScreenShot", "远程 Snapmatic", "随时按 [X] 用 Snapmatic 拍快照。", function()
	LetMeTakeASelfie()
end)

commandmgr.add_list_command("pm_contactslist", "脱衣舞娘", "", pm_ContactOverrideList, 104)

commandmgr.add_looped_command("pm_ContactOverride", "联系人替换", "把来电转接到自定义联系人（会覆盖莱斯特）。", function()
	if ScriptGlobal(8817):get_int() == 12 then
		ScriptGlobal(8817):set_int(commandmgr.get_command("pm_contactslist"):get_value())
	end
end)

commandmgr.add_list_command("pm_ThemeList", "主题", "使用故事模式里的手机主题", pm_Themes, 1, function()
	selected_theme = pm_Themes[commandmgr.get_command("pm_ThemeList"):get_value()]
	PhoneMaster(0, selected_theme[3], 0)
	if selected_theme[1] == 1 then
		PhoneMaster(1, "CELLPHONE_IFRUIT", 0)
	end
end)

commandmgr.add_list_command("pm_SoundSetList", "铃声包", "使用故事模式里的手机铃声包", pm_SoundSets, 2, function()
	selected_soundset = pm_SoundSets[commandmgr.get_command("pm_SoundSetList"):get_value()]
	if selected_soundset[1] == 1 then
		ScriptGlobal(21655):set_string("Phone_SoundSet_Michael")
	end
end)

commandmgr.add_list_command("pm_BackgroundList", "背景", "使用故事模式里的手机铃声包", pm_Background, stats.get_int("MPX_FM_CELLPHONE_BACKGROUND"), function()
	local selected_background = commandmgr.get_command("pm_BackgroundList"):get_value()
	stats.set_int("MPX_FM_CELLPHONE_BACKGROUND", selected_background)
end)

commandmgr.add_list_command("pm_ColorSchemeList", "配色方案", "使用故事模式里的手机铃声包", pm_ColorScheme, stats.get_int("MPX_FM_CELLPHONE_THEME"), function()
	local selected_colscheme = commandmgr.get_command("pm_ColorSchemeList"):get_value()
	stats.set_int("MPX_FM_CELLPHONE_THEME", selected_colscheme)
end)

local pm_resetpos = false
TS_PhoneMaster:imgui(function() if not IsOnline() then ImGui.TextDisabled("请先进入自由模式战局。") return end

	--ImGui.SeparatorText("Phone Master")
	ImGui.Text("主要功能")ImGui.Separator()ImGui.Spacing()
	if not pm_gotphonepos and ScriptGlobal(44938):get_int() == 15 and ScriptGlobal(21666 + 1):get_int() == 6 then
		pm_gotStartpos = ScriptGlobal(21612 + 1):get_vector3()
		pm_gotEndpos   = ScriptGlobal(21619 + 1):get_vector3()
		pm_StartXPos = pm_gotStartpos.x
		pm_StartYPos = pm_gotStartpos.y
		pm_StartZPos = pm_gotStartpos.z
		pm_EndXPos   = pm_gotEndpos.x
		pm_EndYPos   = pm_gotEndpos.y
		pm_EndZPos   = pm_gotEndpos.z
		pm_gotphonepos = true
	elseif pm_gotphonepos and ScriptGlobal(44938):get_int() == 15 and ScriptGlobal(21666):get_int() >= 2 then
		ScriptGlobal(21612 + 1):set_vector3(Vector3(pm_StartXPos, pm_StartYPos, pm_StartZPos))
    	ScriptGlobal(21619 + 1):set_vector3(Vector3(pm_EndXPos, pm_EndYPos, pm_EndZPos))
    	ScriptGlobal(21626):set_float(pm_pitch)
    	ScriptGlobal(21626 + 1):set_float(pm_yaw)
    	ScriptGlobal(21626 + 2):set_float(pm_roll)
    end
	if selected_soundset then
		ScriptGlobal(21655):set_string(selected_soundset[3])
	end

	commandmgr.get_command("pm_Anims"):draw()
	if commandmgr.get_command("pm_Anims"):get_value() then
		ImGui.SameLine() commandmgr.get_command("pm_LeanKey"):draw()
	end

    commandmgr.get_command("pm_ScreenShot"):draw()
	commandmgr.get_command("pm_ContactOverride"):draw()

	if commandmgr.get_command("pm_ContactOverride"):get_value() then
		ImGui.SameLine() commandmgr.get_command("pm_contactslist"):draw()
	end

	ImGui.Spacing()

	ImGui.Text("自定义")ImGui.Separator()ImGui.Spacing()

    commandmgr.get_command("pm_ThemeList"):draw()
    commandmgr.get_command("pm_SoundSetList"):draw() if ImGui.IsItemHovered() then ImGui.SetTooltip("Last one is not the \"Default\" in freemode.") end

	if commandmgr.get_command("pm_BackgroundList"):get_value() == nil then commandmgr.get_command("pm_BackgroundList"):set_value(stats.get_int("MPX_FM_CELLPHONE_BACKGROUND")) end
	if commandmgr.get_command("pm_ColorSchemeList"):get_value() == nil then commandmgr.get_command("pm_ColorSchemeList"):set_value(stats.get_int("MPX_FM_CELLPHONE_THEME")) end

	commandmgr.get_command("pm_BackgroundList"):draw()
	commandmgr.get_command("pm_ColorSchemeList"):draw()

	if commandmgr.get_command("pm_ThemeList"):get_value() > 1 and CAMERA.GET_FOLLOW_PED_CAM_VIEW_MODE() ~= 4 then
		pm_AnimToggle(false)
	end
	if commandmgr.get_command("pm_ThemeList"):get_value() > 1 and CAMERA.GET_FOLLOW_PED_CAM_VIEW_MODE() == 4 then
		pm_AnimToggle(true)
	end

	ImGui.Spacing()

	commandmgr.get_command("pm_ModelCelltowa"):draw()

	ImGui.Spacing()ImGui.Spacing()
	ImGui.Text("手机朝向")ImGui.Separator()ImGui.Spacing()
	ImGui.PushItemWidth(350)

	pm_pitch = ImGui.SliderFloat("俯仰", pm_pitch, -360.0, 360.0) if ImGui.IsItemHovered() then ImGui.SetTooltip("+ = Forward\n- = Backward") end ImGui.SameLine() if ImGui.Button("重置##pitch") then pm_pitch = -90.0 end
	pm_yaw 	 = ImGui.SliderFloat("偏航", pm_yaw, -360.0, 360.0)     if ImGui.IsItemHovered() then ImGui.SetTooltip("+ = Right\n- = Left") end ImGui.SameLine(0, 13) if ImGui.Button("重置##yaw") then pm_yaw = 0 end
	pm_roll	 = ImGui.SliderFloat("翻滚", pm_roll, 360.0, -360.0)   if ImGui.IsItemHovered() then ImGui.SetTooltip("+ = Left\n- = Right") end ImGui.SameLine(0, 16) if ImGui.Button("重置##roll") then pm_roll = 0 end
	ImGui.Spacing()
	if ImGui.Button("重置手机朝向") then
		pm_pitch = -90.0
		pm_yaw = 0
		pm_roll = 0
	end
	ImGui.Spacing()

	ImGui.PopItemWidth()

	ImGui.Text("手机位置") if ImGui.IsItemHovered() then ImGui.SetTooltip("把它当作一段关键帧动画") end ImGui.Separator()ImGui.Spacing()
	if pm_gotphonepos then
		ImGui.PushItemWidth(350)

		pm_StartXPos = ImGui.SliderFloat("起始 X 位置", pm_StartXPos, -360.0, 360.0) ImGui.SameLine(0, 7) if ImGui.Button("重置##StartXPos") then pm_StartXPos = pm_gotStartpos.x end
		pm_StartYPos = ImGui.SliderFloat("起始 Y 位置", pm_StartYPos, -360.0, 360.0) ImGui.SameLine(0, 7) if ImGui.Button("重置##StartYPos") then pm_StartYPos = pm_gotStartpos.y end
		pm_StartZPos = ImGui.SliderFloat("起始 Z 位置", pm_StartZPos, -360.0, 360.0) ImGui.SameLine(0, 6) if ImGui.Button("重置##StartZPos") then pm_StartZPos = pm_gotStartpos.z end

		ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()

		pm_EndXPos = ImGui.SliderFloat("结束 X 位置", pm_EndXPos, -360.0, 360.0) ImGui.SameLine(0, 7) if ImGui.Button("重置##EndXPos") then pm_EndXPos = pm_gotEndpos.x end
		pm_EndYPos = ImGui.SliderFloat("结束 Y 位置", pm_EndYPos, -360.0, 360.0) ImGui.SameLine() if ImGui.Button("重置##EndYPos") then pm_EndYPos = pm_gotEndpos.y end
		pm_EndZPos = ImGui.SliderFloat("结束 Z 位置", pm_EndZPos, -360.0, 360.0) ImGui.SameLine(0, 6) if ImGui.Button("重置##EndZPos") then pm_EndZPos = pm_gotEndpos.z end

		ImGui.Spacing()

		if ImGui.Button("重置手机位置") or pm_resetpos then
			pm_StartXPos = pm_gotStartpos.x
			pm_StartYPos = pm_gotStartpos.y
			pm_StartZPos = pm_gotStartpos.z
			pm_EndXPos = pm_gotEndpos.x
			pm_EndYPos = pm_gotEndpos.y
			pm_EndZPos = pm_gotEndpos.z
			pm_resetpos = false
		end
		ImGui.PopItemWidth()


		if ImGui.Button("全部重置") then
			pm_pitch = -90.0
			pm_yaw = 0
			pm_roll = 0
			pm_resetpos = true
		end
	else
		ImGui.TextDisabled("先把手机掏出来才能使用该功能。")
	end
end)


---|| Gun Van Halen ||------------------------------------------------------------------------------

local GVweapons = {
    { 0,	"" },
    { -1357824103,	"高级步枪" },
    { -1834847097,	"古董骑兵匕首" },
    { 584646201,	"AP 手枪" },
    { 961495388,	"突击步枪 Mk II" },
    { -1074790547,	"突击步枪" },
    { -494615257,	"突击霰弹枪" },
    { -270015777,	"突击冲锋枪" },
    { -1786099057,	"棒球棍" },
    { -853065399,	"战斧" },
    { 1924557585,	"战斗步枪" },
    { -102323637,	"酒瓶" },
    { -2066285827,	"无托步枪 Mk II" },
    { 2132975508,	"无托步枪" },
    { -1654528753,	"无托霰弹枪" },
    { 1703483498,	"拐杖糖" },
    { -86904375,	"卡宾步枪 Mk II" },
    { -2084633992,	"卡宾步枪" },
    { 727643628,	"陶瓷手枪" },
    { -608341376,	"战斗机枪 Mk II" },
    { 2144741730,	"战斗机枪" },
    { 171789620,	"战斗 PDW" },
    { 1593441988,	"战斗手枪" },
    { 94989220,		"战斗霰弹枪" },
    { -618237638,	"紧凑型电磁发射器" },
    { 125959754,	"紧凑型榴弹发射器" },
    { 1649403952,	"紧凑型步枪" },
    { -2067956739,	"撬棍" },
    { -275439685,	"双管霰弹枪" },
    { -1746263880,	"双动式左轮" },
    { -1916886713,	"斯特里克勒左轮" },
    { 2138347493,	"烟花发射器" },
    { 1198879012,	"信号枪" },
    { -1951375401,	"手电筒" },
    { -1568386805,	"榴弹发射器" },
    { 1627465347,	"古森伯格扫射枪" },
    { 1317494643,	"锤子" },
    { -102973651,	"短柄斧" },
    { -771403250,	"重型手枪" },
    { -879347409,	"重型左轮 Mk II" },
    { -1045183535,	"重型左轮" },
    { -947031628,	"重型步枪" },
    { 984333226,	"重型霰弹枪" },
    { 177293209,	"重型狙击枪 Mk II" },
    { 205991906,	"重型狙击枪" },
    { 1672152130,	"追踪导弹发射器" },
    { -1716189206,	"小刀" },
    { -656458692,	"指虎" },
    { -581044007,	"砍刀" },
    { -619010992,	"冲锋手枪" },
    { -598887786,	"神射手手枪" },
    {  1785463520,	"射手步枪 Mk II" },
    { -952879014,	"射手步枪" },
    { -1660422300,	"MG" },
    { 324215364,	"微型冲锋枪" },
    { -1658906650,	"军用步枪" },
    { -1121678507,	"迷你冲锋枪" },
    { 1119849093,	"加特林机枪" },
    { -1466123874,	"火枪" },
    { -1853920116,	"海军左轮" },
    { 1737195953,	"警棍" },
    { 1470379660,	"佩里科手枪" },
    { 419712736,	"管钳" },
    { -1716589765,	".50 手枪" },
    { -1075685676,	"手枪 Mk II" },
    { 453432689,	"手枪" },
    { -1810795771,	"台球杆" },
    { 1853742572,	"精准步枪" },
    { 1432025498,	"泵动霰弹枪 Mk II" },
    { 487013001,	"泵动霰弹枪" },
    { -22923932,	"电磁炮" },
    { -1312131151,	"RPG" },
    { 2017895192,	"截短霰弹枪" },
    { -774507221,	"制式卡宾枪" },
    { 2024373456,	"冲锋枪 Mk II" },
    { 736523883,	"SMG" },
    { 100416529,	"狙击步枪" },
    { 62870901,		"雪球发射器" },
    { -2009644972,	"SNS 手枪 Mk II" },
    { -1076751822,	"SNS 手枪" },
    { -1768145561,	"特种卡宾枪 Mk II" },
    { -1063057011,	"特种卡宾枪" },
    { 1171102963,	"电击枪" },
    { 317205821,	"扫除霰弹枪" },
    { -538741184,	"弹簧刀" },
    { 350597077,	"战术冲锋枪" },
    { -624951259,	"电击棒" },
    { 1198256469,	"邪恶使者" },
    { -1355376991,	"原子分解枪" },
    { 137902532,	"复古手枪" },
    { -1238556825,	"寡妇制造者" }
}

local GVthrowweapons = {
    { 0,	"" },
    { -1813897027,	"手雷" },
    { -37975472,	"催泪瓦斯" },
    { 741814745,	"粘性炸弹" },
    { -1420407917,	"感应地雷" },
    { -1169823560,	"管状炸弹" },
    { 883325847,	"汽油罐" },
    { 615608432,	"燃烧瓶" }
}

for i = 1, 10 do
	commandmgr.add_list_command("gv_weaponlist"..i, "栏位 "..i.."##weapl"..i, "", GVweapons, tunables.get_int("XM22_GUN_VAN_SLOT_WEAPON_TYPE_"..i - 1), function()
		local GV_selectedweap  = commandmgr.get_command("gv_weaponlist"..i):get_value()
		tunables.set_int("XM22_GUN_VAN_SLOT_WEAPON_TYPE_"..i - 1, GV_selectedweap)
	end)
end

for i = 1, 3 do
	commandmgr.add_list_command("gv_throwlist"..i, "栏位 "..i.."##throwl"..i, "", GVthrowweapons, tunables.get_int("XM22_GUN_VAN_SLOT_THROWABLE_TYPE_"..i - 1), function()
		local GV_selectedthrow  = commandmgr.get_command("gv_throwlist"..i):get_value()
		tunables.set_int("XM22_GUN_VAN_SLOT_THROWABLE_TYPE_"..i - 1, GV_selectedthrow)
	end)
end

commandmgr.add_bool_command("gv_getcurweap", "##getcurweap", "", false, function() -- used to print the current gun van weapons, now it just reloads the slots
	for i = 1, 10 do
		commandmgr.get_command("gv_weaponlist"..i):set_value(tunables.get_int("XM22_GUN_VAN_SLOT_WEAPON_TYPE_"..i - 1))
	end
	for i = 1, 3 do
		commandmgr.get_command("gv_throwlist"..i):set_value(tunables.get_int("XM22_GUN_VAN_SLOT_THROWABLE_TYPE_"..i - 1))
	end
end)

local gunvanlocs = {
	{ locname = "佩里托湾",         	GVcoords = {-29.532, 6435.136, 31.162}	 },
	{ locname = "葡萄籽",          	GVcoords = {1705.214, 4819.167, 41.75}	 },
	{ locname = "桑迪海岸",       	GVcoords = {1795.522, 3899.753, 33.869}	 },
	{ locname = "大塞诺拉沙漠",	GVcoords = {1335.536, 2758.746, 51.099}	 },
	{ locname = "好麦坞标志",     	GVcoords = {795.583, 1210.78, 338.962}	 }, -- *Galileo Park - Vinewood Hills
	{ locname = "楚马什",            	GVcoords = {-3192.67, 1077.205, 20.594}	 },
	{ locname = "佩里托森林",      	GVcoords = {-789.719, 5400.921, 33.915}	 },
	{ locname = "赞库多河",      	GVcoords = {-24.384, 3048.167, 40.703}	 },
	{ locname = "发电站",      	GVcoords = {2666.786, 1469.324, 24.237}	 }, -- *Palmer-Taylor Power Station
	{ locname = "赞库多湖",      	GVcoords = {-1454.966, 2667.503, 3.2}	 }, -- *Fort Zancudo Approach Rd
	{ locname = "汤姆森废车场", 	GVcoords = {2340.418, 3054.188, 47.888}	 },
	{ locname = "驴子高地",  	GVcoords = {1509.183, -2146.795, 76.853} }, -- *Car Scrapyard
	{ locname = "穆列塔高地",  	GVcoords = {1137.404, -1358.654, 34.322} },
	{ locname = "极乐岛",    	GVcoords = {-57.208, -2658.793, 5.737}	 },
	{ locname = "塔塔维亚山脉",	GVcoords = {1905.017, 565.222, 175.558}	 }, -- *Land Act Reservoir
	{ locname = "拉梅萨",           	GVcoords = {974.484, -1718.798, 30.296}	 }, -- *Fridgit, Forced Labor Place
	{ locname = "码头区",          	GVcoords = {779.077, -3266.297, 5.719}	 },
	{ locname = "拉普埃尔塔",         	GVcoords = {-587.728, -1637.208, 19.611} }, -- *Rogers Salvage & Scrap
	{ locname = "拉梅萨",           	GVcoords = {733.99, -736.803, 26.165}	 }, -- *Popular Street
	{ locname = "德尔佩罗",         	GVcoords = {-1694.632, -454.082, 40.712} },
	{ locname = "麦哲伦大道",      	GVcoords = {-1330.726, -1163.948, 4.313} }, -- *Vespucci Beach
	{ locname = "西好麦坞",     	GVcoords = {-496.618, 40.231, 52.316}	 },
	{ locname = "好麦坞市区", 	GVcoords = {275.527, 66.509, 94.108}	 },
	{ locname = "胶囊山",      	GVcoords = {260.928, -763.35, 30.559}	 },
	{ locname = "小首尔",      	GVcoords = {-478.025, -741.45, 30.299}	 }, -- *Caesars Auto Parking
	{ locname = "阿拉莫海",         	GVcoords = {894.94, 3603.911, 32.56}	 }, -- *Joshua Road
	{ locname = "北楚马什",     	GVcoords = {-2166.511, 4289.503, 48.733} }, -- *Hookies
	{ locname = "奇力耶德山",     	GVcoords = {1465.633, 6553.67, 13.771}	 }, -- *Procopio Beach
	{ locname = "镜湖公园",       	GVcoords = {1101.032, -335.172, 66.944}	 }, -- *Hearty Taco
	{ locname = "戴维斯",             	GVcoords = {149.683, -1655.674, 29.028}	 } -- *Bishop's Chicken
}

TS_GoonVan:imgui(function() if not IsOnline() then ImGui.TextDisabled("请先进入自由模式战局。") return end

	ImGui.Text("枪店车当前位置")ImGui.Separator()ImGui.Spacing()

	local GVteleport = gunvanlocs[stats.get_packed_int(41239) + 1]
	if ImGui.Button("传送至："..GVteleport.locname) then
		local GVloc = GVteleport.GVcoords
		PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), GVloc[1], GVloc[2], GVloc[3]+1.0)
	end  --ImGui.SameLine()
	ImGui.Spacing()ImGui.Spacing()

	ImGui.Text("栏位编辑")ImGui.Separator()ImGui.Spacing()

	ImGui.BeginGroup()
	ImGui.Text("武器栏位") ImGui.Spacing()
	for i = 1, 10 do
		commandmgr.get_command("gv_weaponlist"..i):draw()
	end
	ImGui.EndGroup()

	ImGui.SameLine(0, 20)
	ImGui.BeginGroup()
	ImGui.Text("投掷物栏位") ImGui.Spacing()
	for i = 1, 3 do
		commandmgr.get_command("gv_throwlist"..i):draw()
	end ImGui.EndGroup()

	ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()

	if not commandmgr.get_command("gv_getcurweap"):get_value() then
		commandmgr.get_command("gv_getcurweap"):set_value(true)
	end

	if ImGui.Button("重载栏位") then
		commandmgr.get_command("gv_getcurweap"):set_value(false)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("重载枪店车的货物栏位。") end -- just because, probably not too useful

	ImGui.Spacing()ImGui.Text("其他")ImGui.Separator()ImGui.Spacing()

	ImGui.SameLine(0, 3.8)
	ImGui.BeginGroup()
	if ImGui.TreeNodeEx("解锁武器  ##"..nomoretreeplease, 8219) then
		ImGui.Spacing()
		ImGui.SameLine(-3.8, 0)

		--if ImGui.Button("WM29 Pistol") then
		--	if transactions.can_use_transactions() then
		--		--baskettranscationsdon'twork
		--		--notify.success("TinkerScript - Gun Van Halen", "WM29 Pistol unlocked!\nPlease change sesions to see the changes", 3000)
		--	else
		--		stats.set_masked_int("MPX_CHAR_WEAP_FM_PURCHASE3", 31, 0, 1)
		--		notify.success("TinkerScript - Gun Van Halen", "WM29 Pistol unlocked!\nPlease change sesions to see the changes", 3000)
		--	end
		--end
		ImGui.BeginGroup()
		if ImGui.Button("高尔夫球杆") then
			stats.set_int("MPX_GCLUB_FM_AMMO_BOUGHT", 1) -- from https://www.unknowncheats.me/forum/4165404-post4.html
			notify.success("TinkerScript - 枪店车", "高尔夫球杆已解锁！", 3000)
		end

		if ImGui.Button("石斧") then
			stats.set_packed_int(7315, 6)
			stats.set_packed_bool(22073, true)
			notify.success("TinkerScript - 枪店车", "石斧已解锁！", 3000)
		end

		if ImGui.Button("原子分解枪") then
			stats.set_packed_bool(25002, true)
			notify.success("TinkerScript - 枪店车", "原子分解枪已解锁！", 3000)
		end

		if ImGui.Button("制式卡宾枪") then
			stats.set_packed_bool(32318, true)
			notify.success("TinkerScript - 枪店车", "制式卡宾枪已解锁！", 3000)
		end

		if ImGui.Button("雪球发射器") then
			stats.set_packed_bool(42148, true)
			notify.success("TinkerScript - 枪店车", "雪球发射器已解锁！", 3000)
		end

		if ImGui.Button("拐杖糖") then
			stats.set_packed_bool(42249, true)
			notify.success("TinkerScript - 枪店车", "拐杖糖已解锁！", 3000)
		end

		if ImGui.Button("电击棒") then
			stats.set_packed_bool(51196, true)
			notify.success("TinkerScript - 枪店车", "电击棒已解锁！", 3000)
		end
		ImGui.EndGroup()
		ImGui.SameLine()
		ImGui.Dummy(15.7, 0)
	else
		if ImGui.IsItemHovered() then ImGui.SetTooltip("Allows you to unlock login bonus weapons and the ones that can't be purchased from the Gun Van.\nChange sessions if the unlocked weapon doesn't appear on the Weapon Wheel.") end
	end
	ImGui.EndGroup()

	ImGui.SameLine()
	ImGui.BeginGroup()
	if ImGui.Button("启用球棒/小刀涂装") then
		stats.set_packed_bool_range(36789, 36808, true)
	end if ImGui.IsItemHovered() then ImGui.SetTooltip("永久启用球棒与小刀的涂装") end
	ImGui.EndGroup()

end)

---|| Rainbow Vehicles ||------------------------------------------------------------------------------

local hue_speed = 0.0574 -- Base Speed
local flicker_intensity = 15

local rainbow_speed_boost = false
	local rainbow_boost_amount = 0.1 -- Set this to 0.5 and press "E" 6 times for a "IDKWHATTOCALLTHIS" effect

local speed_level_max = 10 -- Set this to a higher value for a *CRT-ish(?) effect -- Default 10

local xenon = true -- Enable Xenon lights
local xenon_lspeed = 2

local set_plate = true -- Enable custom plates
	local plate_speed = 0.2
	local set_plate_styles = true -- Enable Custom Plates Styles
	local set_plate_animT = { { 1, "滚动"}, {2, "闪烁"} } -- Enable Custom Plates Text Animation - 0/false = disabled | 1 = scroll | 2 = flicker
		local plate_text_scroll = "Unknown Cheats FTW    "
		local plate_scroll_speed = 200
		local plate_text_flicker = {"Unknown", "Cheats", "FTW"} -- 8 characters limit per word

local set_wheels = true -- Enable Custom Wheels - Only Big Bar w/ Retro White Wall Design for now

local hue = 0.0
local color_modeT = { {1, "彩虹"}, {2, "柔和"}, {3, "闪烁"}, {4, "黑白脉冲"}, {5, "过热"} }
local plate_char = 0
local plate_text_current = 1
local wheel = 0
local speed_level = 0

local function RainbowDash()
	local PlaVeh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), 0)
	if PED.IS_PED_SITTING_IN_ANY_VEHICLE(PLAYER.PLAYER_PED_ID()) then

		local dynamic_speed = hue_speed + (speed_level * rainbow_boost_amount)
		hue = hue + dynamic_speed

		if color_mode == 1 then -- Rainbow Default
			r = math.floor(math.sin(hue) * 127 + 128)
			g = math.floor(math.sin(hue + 2) * 127 + 128)
			b = math.floor(math.sin(hue + 4) * 127 + 128)
		elseif color_mode == 2 then -- Pastel Mode
			r = math.floor(math.sin(hue) * 50 + 205)
			g = math.floor(math.sin(hue + 2) * 50 + 205)
			b = math.floor(math.sin(hue + 4) * 50 + 205)
		elseif color_mode == 3 then -- Flicker Mode
			if math.random(1, 200) <= flicker_intensity then
				r, g, b = math.random(0, 255), math.random(0, 255), math.random(0, 255)
			end
		elseif color_mode == 4 then -- Black/White Pulse Mode
			r = math.floor(math.sin(hue) * 127 + 128)
			g = math.floor(math.sin(hue) * 127 + 128)
			b = math.floor(math.sin(hue) * 127 + 128)
		elseif color_mode == 5 then -- Overheat Mode
			local speed = Vehicle(PlaVeh):get_speed() * 3.6 -- ENTITY.GET_ENTITY_SPEED(PlaVeh) * 3.5
			if speed < 2 then
				speed_level = 0
			elseif speed < 5 then
				r, g, b = 0, 0, 0
			elseif speed < 40 then
				speed_level = 4
				local moo = (speed - 5) / 35 -- sMOOth
				r = 0
				g = math.floor(moo * 255)
				b = math.floor(moo * 255)
			elseif speed < 80 then
				speed_level = 6
				local moo = (speed - 40) / 40
				r = math.floor(moo * 255)
				g = 255
				b = math.floor(255 - (moo * 255))
			elseif speed < 120 then
				speed_level = 8
				local moo = (speed - 80) / 40
				r = 255
				g = math.floor(255 - (moo * 255))
				b = 0
			else
				speed_level = 10
				r = 255
				g = math.min(255, math.floor(((speed - 120) / 60) * 255))
				b = math.min(255, math.floor(((speed - 120) / 60) * 255))
			end
			if speed == 0 then
				plate_scroll_speed = 100000
				plate_speed = 0
			else
				plate_scroll_speed = 200 - (speed_level * 18)
				plate_speed = 0.2 + (speed_level / 160)
			end
		end

		VEHICLE.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(PlaVeh, r, g, b);VEHICLE.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(PlaVeh, r, g, b)
		VEHICLE.TOGGLE_VEHICLE_MOD(PlaVeh, 20, 1);VEHICLE.TOGGLE_VEHICLE_MOD(PlaVeh, 22, 1);VEHICLE.TOGGLE_VEHICLE_MOD(PlaVeh, 23, 1)
		for i = 0, 3 do VEHICLE.SET_VEHICLE_NEON_ENABLED(PlaVeh, i, 1) end
		VEHICLE.SET_VEHICLE_TYRE_SMOKE_COLOR(PlaVeh, r, g, b)
		VEHICLE.SET_VEHICLE_NEON_COLOUR(PlaVeh, r, g, b)
		VEHICLE.SET_VEHICLE_WHEEL_TYPE(PlaVeh, 8)

		if xenon then
			local xenon_i = {5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3, 4}
			local xenon_color = math.floor(hue * xenon_lspeed % #xenon_i) + 1
			VEHICLE.SET_VEHICLE_XENON_LIGHT_COLOR_INDEX(PlaVeh, xenon_i[xenon_color])
		end
		if set_plate then
			if set_plate_anim == 1 then
				if MISC.GET_GAME_TIMER() - plate_char > plate_scroll_speed then
					local plate_segment = string.sub(plate_text_scroll, plate_text_current, plate_text_current + 7) -- 8 = Character limit
					if #plate_segment < 8 then
						plate_segment = plate_segment .. string.sub(plate_text_scroll, 1, 8 - #plate_segment)
					end
					Vehicle(PlaVeh):set_plate_text(plate_segment)
					plate_char = MISC.GET_GAME_TIMER()
					plate_text_current = plate_text_current + 1
					if plate_text_current > #plate_text_scroll then
						plate_text_current = 1
					end
				end
			elseif set_plate_anim == 2 then
				local plate_iterf = math.floor(hue * plate_speed % #plate_text_flicker) + 1
				Vehicle(PlaVeh):set_plate_text(plate_text_flicker[plate_iterf])
			end
			if set_plate_styles then
				local plate_style_id = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12} -- Blue on White 1 = 0 | Yellow on Black = 1 | Yellow on Blue = 2 | Blue on White 2 = 3 | Blue on White 3 = 4 | North Yankton = 5 | Ecola = 6 | Las Venturas = 7 | Liberty City = 8 | Los Santos Car Meet = 9 | Los Santos Panicc = 10 | Los Santos Pounders = 11 | Sprunk = 12
				local plate_style = math.floor(hue * plate_speed % #plate_style_id) + 1
				VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(PlaVeh, plate_style_id[plate_style])
			end
		end
		if set_wheels then
			VEHICLE.SET_VEHICLE_MOD(PlaVeh, 23, 115, 1)
			wheel = wheel + 1
			if wheel > 160 then
				wheel = 0
			end
			VEHICLE.SET_VEHICLE_EXTRA_COLOURS(PlaVeh, 157, wheel)
		end
		VEHICLE.SET_VEHICLE_MOD_KIT(PlaVeh, 0)
	end
end

local function RainbowVehReset()
	speed_level = 0;plate_scroll_speed = 200;plate_speed = 0.2;flicker_intensity = 15
end

local rainbowveh_up = true
local function RainbowSpeed()
	if color_mode ~= 5 and rainbowveh_up then
		speed_level = speed_level + 1
		plate_scroll_speed = plate_scroll_speed - 20
		plate_speed = plate_speed + 0.05
		flicker_intensity = flicker_intensity + 10
	elseif color_mode ~= 5 and not rainbowveh_up then
		if speed_level < 1 then speed_level = 1; plate_scroll_speed = 200; flicker_intensity = 15 end
		speed_level = speed_level - 1
		plate_scroll_speed = plate_scroll_speed + 20
		plate_speed = plate_speed - 0.05
		flicker_intensity = flicker_intensity - 10
	end

	if speed_level == speed_level_max then
		HUD.BEGIN_TEXT_COMMAND_THEFEED_POST("STRING");HUD.THEFEED_SET_BACKGROUND_COLOR_FOR_NEXT_POST(6)
		HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("彩虹速度：~y~~h~Ω 最大 Ω")
		HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER(1, 0)
	elseif speed_level > speed_level_max then
		RainbowVehReset()
		HUD.BEGIN_TEXT_COMMAND_THEFEED_POST("STRING")
		HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("彩虹速度：~b~默认")
		HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER(1, 0)
	else
		HUD.BEGIN_TEXT_COMMAND_THEFEED_POST("STRING");HUD.THEFEED_SET_BACKGROUND_COLOR_FOR_NEXT_POST(105)
		HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("彩虹速度：~y~"..speed_level) -- speed or cycle?
		HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER(1, 0)
	end
end

commandmgr.add_looped_command("rainbowveh_toggle", "彩虹载具", "启用彩虹载具", RainbowDash)

commandmgr.add_bool_command("rainbowveh_rainbowsb", "彩虹速度加速", "启用彩虹速度加速", true, function()
	if commandmgr.get_command("rainbowveh_toggle"):get_value() then
		notify.warn("警告：彩虹速度加速已开启！", "光敏性癫痫患者可能因此发作，请谨慎使用。", 3000) -- template from wiklmedia ¯\_(ツ)_/¯
	end
end, RainbowVehReset)

commandmgr.add_list_command("rainbowveh_colormode", "彩虹/色彩模式", "", color_modeT, 1, RainbowVehReset)
commandmgr.add_bool_command("rainbowveh_setplates", "自定义车牌", "启用自定义车牌", true, nil)
commandmgr.add_bool_command("rainbowveh_setplatestyle", "车牌样式轮换", "启用车牌样式轮换", true, nil)
commandmgr.add_list_command("rainbowveh_plateanimtype", "车牌文字动画类型", "", set_plate_animT, 2, nil)
commandmgr.add_bool_command("rainbowveh_xenonl", "氙气灯", "启用氙气灯", true, nil)
commandmgr.add_bool_command("rainbowveh_setwheels", "自定义轮毂", "启用自定义轮毂", true, nil)

local newtext = 3
local NewFlicker1, NewFlicker2, NewFlicker3 = 0, 0, 0
local testcheckbox = false
TS_RainbowVeh:imgui(function() -- I was going to rework this part since I don't think it looks too good, but it just works so I probably won't be touching this anytime soon

	color_mode = commandmgr.get_command("rainbowveh_colormode"):get_value()
	rainbow_speed_boost = commandmgr.get_command("rainbowveh_rainbowsb"):get_value()
	set_plate = commandmgr.get_command("rainbowveh_setplates"):get_value()
	set_plate_anim = commandmgr.get_command("rainbowveh_plateanimtype"):get_value()
	set_plate_styles = commandmgr.get_command("rainbowveh_setplatestyle"):get_value()
	xenon = commandmgr.get_command("rainbowveh_xenonl"):get_value()
	set_wheels = commandmgr.get_command("rainbowveh_setwheels"):get_value()

	commandmgr.get_command("rainbowveh_toggle"):draw()

	if not commandmgr.get_command("rainbowveh_toggle"):get_value() then
		ImGui.TextDisabled("Somewhere over the rainbow\nOppressors fly.\nOppressors fly over the rainbow\nWhy, then, oh why don't I have money for GTA VI and a PS5?") return
	end

	ImGui.SameLine() commandmgr.get_command("rainbowveh_colormode"):draw()
	commandmgr.get_command("rainbowveh_rainbowsb"):draw()

	if rainbow_speed_boost then
		ImGui.SetNextItemWidth(40)
		ImGui.SameLine() ImGui.InputText("##rainbowspeedorcycleidk", "  "..speed_level, ImGuiInputTextFlags.ReadOnly)

		ImGui.SameLine(0, 4) if ImGui.Button("-", 25) then
			rainbowveh_up = false
			RainbowSpeed()
		end
		ImGui.SameLine(0, 4) if ImGui.Button("+", 25) then
			rainbowveh_up = true
			RainbowSpeed()
		end
		ImGui.SameLine() ImGui.Text("彩虹速度")
	end

	commandmgr.get_command("rainbowveh_setplates"):draw()
	if set_plate then
		ImGui.SameLine() commandmgr.get_command("rainbowveh_setplatestyle"):draw()
		ImGui.Indent()
		commandmgr.get_command("rainbowveh_plateanimtype"):draw()
		ImGui.SameLine() if commandmgr.get_command("rainbowveh_plateanimtype"):get_value() == 2 and ImGui.Button("添加文字") then
			newtext = newtext + 1
			if newtext == 4 then
				NewFlicker1 = 4
				table.insert(plate_text_flicker, "")
			elseif newtext == 5 then
				NewFlicker2 = 5
				table.insert(plate_text_flicker, "")
			elseif newtext == 6 then
				NewFlicker3 = 6
				table.insert(plate_text_flicker, "")
			elseif newtext > 6 then newtext = 6 notify.warn("TinkerScript - 彩虹载具", "不能再加词了！", 3000) return end
		end
		if newtext > 3 then ImGui.SameLine() if ImGui.Button("移除文字")then
			if newtext == 6 then
				NewFlicker3 = 0
				newtext = newtext - 1
				table.remove(plate_text_flicker, 6)
			elseif newtext == 5 then
				NewFlicker2 = 0
				newtext = newtext - 1
				table.remove(plate_text_flicker, 5)
			elseif newtext == 4 then
				NewFlicker1 = 0
				newtext = newtext - 1
				table.remove(plate_text_flicker, 4)
			elseif newtext > 3 then newtext = 3 return end
		end end

		if set_plate_anim == 2 then if ImGui.IsItemHovered() then ImGui.SetTooltip("每个词最多 8 个字符") end
			ImGui.PushItemWidth(100)
			plate_text_flicker[1] = ImGui.InputText("车牌文字 1", plate_text_flicker[1])
			plate_text_flicker[2] = ImGui.InputText("车牌文字 2", plate_text_flicker[2])
			plate_text_flicker[3] = ImGui.InputText("车牌文字 3", plate_text_flicker[3])
			if NewFlicker1 == 4 then plate_text_flicker[NewFlicker1] = ImGui.InputText("车牌文字 "..NewFlicker1.."", plate_text_flicker[NewFlicker1]) end
			if NewFlicker2 == 5 then plate_text_flicker[NewFlicker2] = ImGui.InputText("车牌文字 "..NewFlicker2.."", plate_text_flicker[NewFlicker2]) end
			if NewFlicker3 == 6 then plate_text_flicker[NewFlicker3] = ImGui.InputText("车牌文字 "..NewFlicker3.."", plate_text_flicker[NewFlicker3]) end
			ImGui.PopItemWidth()
		else
			ImGui.NewLine() ImGui.PushItemWidth(250) plate_text_scroll = ImGui.InputText("车牌文字", plate_text_scroll) ImGui.PopItemWidth()
		end
		ImGui.Unindent()
		ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()
	end

	commandmgr.get_command("rainbowveh_xenonl"):draw()
	commandmgr.get_command("rainbowveh_setwheels"):draw()

	ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()

	testcheckbox = ImGui.Checkbox("基础设置", testcheckbox) if ImGui.IsItemHovered() then ImGui.SetTooltip("允许编辑底层变量") end

	if testcheckbox then
		ImGui.SameLine() ImGui.TextDisabled("请谨慎修改。")
		ImGui.Spacing()ImGui.Spacing()ImGui.Spacing()
		ImGui.PushItemWidth(180)
		hue_speed = ImGui.SliderFloat("色相速度", hue_speed, 0.001, 2.0)
		rainbow_boost_amount = ImGui.SliderFloat("彩虹速度倍率", rainbow_boost_amount, 0.001, 2.0)
		speed_level_max = ImGui.SliderInt("最大彩虹速度", speed_level_max, 5, 50)
		ImGui.PopItemWidth()
	else
		hue_speed = 0.0574
		rainbow_boost_amount = 0.1
		speed_level_max = 10
	end


end)

---|| Recovery + (Safe Cracker) ||------------------------------------------------------------------------------

local function CrackCB()
	if ScriptLocal("fm_mission_controller_2020", 29373 + 12):get_int() == -1 then
		notify.error("TinkerScript - 克拉克飞贼", "你必须先到保险柜旁边！", 3000) return
	end

	for i = 0, 2 do
		ScriptLocal("fm_mission_controller_2020", 32726 + 1 + 1):at(i, 2):set_int(0)
		ScriptLocal("fm_mission_controller_2020", 32726 + 1):at(i, 2):set_float(0)
		script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 237, 1.0)
	end
end

local function CBTpToPC()
	local CB_PCcoords = ScriptLocal("fm_mission_controller_2020", 34538 + 5):get_vector3()
	PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), CB_PCcoords.x, CB_PCcoords.y, CB_PCcoords.z + 1.0)
end

local function CBTpToCrate()
	if ScriptLocal("fm_mission_controller_2020", 21088):get_int() ~= 1149534208 then
		notify.error("TinkerScript - 克拉克飞贼", "你必须先到储藏库旁边！", 3000) return
	end

	local CB_Cratecoords = ScriptLocal("fm_mission_controller_2020", 29373 + 1192):get_vector3()
	PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), CB_Cratecoords.x, CB_Cratecoords.y, CB_Cratecoords.z)
end

commandmgr.add_looped_command("cbr_opendoors", "打开所有门##cbr", "打开所有门", function()
	for _, h in ipairs(entities.get_all_objects_as_handles()) do
		if Entity(h):get_model() == 258537691 then
			if ENTITY.IS_ENTITY_A_MISSION_ENTITY(h)	then
				ENTITY.SET_ENTITY_AS_MISSION_ENTITY(h, false, true)
			end
			Entity(h):delete()
		end
	end
	if not scripts.is_active("fm_mission_controller_2020") then
		commandmgr.get_command("cbr_opendoors"):set_value(false)
	end
	end, function()
	for _, h in ipairs(entities.get_all_objects_as_handles()) do
		if Entity(h):get_model() == -952356348 then
			if ENTITY.IS_ENTITY_A_MISSION_ENTITY(h)	then
				ENTITY.SET_ENTITY_AS_MISSION_ENTITY(h, false, true)
			end
			Entity(h):delete() break
		end
	end
end)

local function CrackSH()
	if ScriptLocal("fm_content_stash_house", 153 + 16):get_int() == -1 then
		notify.error("TinkerScript - 藏匿屋", "你必须先到保险柜旁边！", 3000) return
	end

	for i = 0, 2 do
		ScriptLocal("fm_content_stash_house", 153 + 22 + 1):at(i, 2):set_int(0)
		ScriptLocal("fm_content_stash_house", 153 + 22):at(i, 2):set_float(0)
		script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 237, 1.0)
	end
end

local function TS_KortzStart()
	if ScriptGlobal(1893070):at(PLAYER.PLAYER_ID(), 625):at(10):get_int() == -1 then
		notify.error("TinkerScript - 科兹中心破解", "你必须先注册为 CEO/老大！", 3000) return
	end
	if not scripts.is_active("fm_maintain_transition_players") then
		ScriptGlobal(1980570 + 732 + 5):set_int(1)
		for i = 1, 5 do
			script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 187, 1.0)
			script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 190, 1.0)
		end
		script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 201, 1.0)
	else
		script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 188, 1.0)
		script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 201, 1.0)
	end
end

local function TS_KortzFP()
	ScriptLocal("fm_mission_controller_v3", 26866):set_int(5)
end

local function TS_KortzPCAC()
	for i = 0, 2 do
		ScriptLocal("fm_mission_controller_v3", 32818 + 1 + 1):at(i, 2):set_int(0)
		script.yield(100) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 237, 1.0)
	end
end

local K26_Leasy = false
local K26_Lnodamage = false
local function TS_KortzPwrL()
	ScriptLocal("fm_mission_controller_v3", 70416):set_int(4294784)
	ScriptGlobal(1935711):set_int(1)
end

local function TS_KortzSN()
	ScriptLocal("fm_mission_controller_v3", 27914):set_int(5)
end

local function TS_KortzPaint()
	ScriptLocal("fm_mission_controller_v3", 29355 + 11):set_int(15)
	ScriptLocal("fm_mission_controller_v3", 29355 + 11):set_int(17)
	script.yield(1000) PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 237, 1.0)
end

local function TS_KortzPaint2()
	ScriptLocal("fm_mission_controller_v3", 29355 + 11):set_int(3)
	PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 219, 1.0)
end

local function TS_KortzDC()
	for b = 0, 7 do
		ScriptLocal("fm_mission_controller_v3", 1388):at(b, 4):set_int(1)
	end
end

local function TS_KortzGlass()
	for g = 0, 4 do
		ScriptLocal("fm_mission_controller_v3", 32855 + 3):at(g, 13):set_float(100)
	end
end

local function TS_KortzFinish()
	script.run_in_callback(function()
		while true do
			if scripts.is_active("fm_mission_controller_v3") and ScriptLocal("fm_mission_controller_v3", 57250 + 1):get_int() == 17718273 then
				ScriptLocal("fm_mission_controller_v3", 57250):set_int(9)
				ScriptLocal("fm_mission_controller_v3", 57250 + 1776):at(0, 1):set_int(1250)
			elseif scripts.is_active("fm_mission_controller_v3") and ScriptLocal("fm_mission_controller_v3", 57250 + 1):get_int() == 17456129 then
				ScriptLocal("fm_mission_controller_v3", 57250):set_int(9)
				ScriptLocal("fm_mission_controller_v3", 57250 + 1776):at(0, 1):set_int(1250)
			elseif scripts.is_active("fm_mission_controller_v3") and ScriptLocal("fm_mission_controller_v3", 57250 + 1):get_int() == 17456128 then
				if HUD.IS_HELP_MESSAGE_BEING_DISPLAYED() then
					FindNewSession() return
				end
			end
			script.yield(0)
		end
	end)
end

local kortz_doors = {
	-1989843262, -636649650, -763344841, 1671614326, 275743652,
	507130236, -1286517865, -421484378, -1864833911, -1925236194,
	2049614127, 454689787, -79540289, 390646248, 1895050696,
	361395225, 1430444526, -861563755, 956014487, 897048274,
	-1120166274, -1717616443, -1854411159, -1158448783, -646395663,
	-780184685, 511378549, -159586315, -434711109, -1993257312, 186527079
}

commandmgr.add_looped_command("kortz_opendoors", "打开所有门##kortz", "打开所有门", function()
	for _, d in ipairs(kortz_doors) do
		OBJECT.DOOR_SYSTEM_SET_DOOR_STATE(d, 0, false, true)
	end
	if not scripts.is_active("fm_mission_controller_v3") then
		commandmgr.get_command("kortz_opendoors"):set_value(false)
	end
	end, function()
	for _, t in ipairs({0, 1, 5, 6, 7, 20, 21}) do
		ScriptGlobal(4980736 + 29174):at(t, 333):at(68):set_int(0) -- Credits to tidmouth
		ScriptGlobal(4980736 + 29174):at(t, 333):at(143):set_int(0)
	end
	for _, h in ipairs(entities.get_all_objects_as_handles()) do
		if Entity(h):get_model() == -1974437642 then
			if ENTITY.IS_ENTITY_A_MISSION_ENTITY(h)	then
				ENTITY.SET_ENTITY_AS_MISSION_ENTITY(h, false, true) -- false true or true true?
			end
			Entity(h):delete() break
		end
	end
end)

local kortz_cams = {
    [-630156392] = true,
    [1301284833] = true,
    [19326568] = true,
    [302330246] = true,
    [506184131] = true,
	[825790471] = true,
	[365062191] = true,
	[-301330169] = true,
	[1417894488] = true,
	[-247409812] = true,
	[-1233322078] = true
}

local kortzcamtimer = 0
local function KortzDelCams()
	for _, h in ipairs(entities.get_all_objects_as_handles()) do
		if kortz_cams[Entity(h):get_model()] then
			if ENTITY.IS_ENTITY_A_MISSION_ENTITY(h)	then
				ENTITY.SET_ENTITY_AS_MISSION_ENTITY(h, false, true)
			end
			Entity(h):delete()
		end
	end
end

commandmgr.add_looped_command("kortz_delcams", "禁用所有摄像头", "禁用所有摄像头", function()
	if util.time() < kortzcamtimer + 12000 then
		KortzDelCams()
	else
		commandmgr.get_command("kortz_delcams"):set_value(false)
	end
	if not scripts.is_active("fm_mission_controller_v3") then
		commandmgr.get_command("kortz_delcams"):set_value(false)
	end
	end, function()
	kortzcamtimer = util.time()
	notify.info("TinkerScript - 科兹中心破解", "Cameras Disabled!\nCameras rebooting in 12 seconds.")
	end, function()
	kortzcamtimer = 0
end)

local ch_doors = {
	-104143029, 1633148016, -1730152782, -1450870697, -1870500531,
	686757512, 1512975268, -1260608781, -503379382, 1649238266,
	-230581957, 277015006, -791522594, -1854580890, 714193794,
	1037783830, -1798315374, -219406021, -7449383, 1467373945,
	280344137, 1391515407, 320263035, -545816134, -1735742237,
	327933309, -1164440132, -1865839062, -1608865147, -1783267585, -104143029
}

local ch_lstacks = {
	[-2143906120] = true,
	[1228147776] = true,
	[-2143192170] = true,
	[-180074230] = true,
	[822904642] = true
}


local ch_pnts = {
	[-327407186] = true,
	[-590378411] = true,
	[-1035053785] = true,
	[-775883720] = true,
	[-1073786699] = true,
	[-1227899306] = true,
	[-1701280280] = true,
	[-1968970241] = true
}

local function ch_delcam()
	for _, h in ipairs(entities.get_all_objects_as_handles()) do
		if Entity(h):get_model() == -1233322078 then
			if ENTITY.IS_ENTITY_A_MISSION_ENTITY(h)	then
				ENTITY.SET_ENTITY_AS_MISSION_ENTITY(h, false, true)
			end
			Entity(h):delete()
		end
	end
end

commandmgr.add_looped_command("ch_opendoors", "打开所有门##Cayo", "打开所有门", function()
	for _, d in ipairs(ch_doors) do
		OBJECT.DOOR_SYSTEM_SET_DOOR_STATE(d, 0, false, true)
	end
	if not scripts.is_active("fm_mission_controller_2020") then
		commandmgr.get_command("ch_opendoors"):set_value(false)
	end
	end, function()
	for _, h in ipairs(entities.get_all_objects_as_handles()) do
		if ch_lstacks[Entity(h):get_model()] then
			if ENTITY.IS_ENTITY_A_MISSION_ENTITY(h)	then
				ENTITY.SET_ENTITY_AS_MISSION_ENTITY(h, false, true)
			end
			local blip = HUD.ADD_BLIP_FOR_ENTITY(h)
			HUD.SET_BLIP_SPRITE(blip, 618)
			HUD.SET_BLIP_COLOUR(blip, 4)
			HUD.SET_BLIP_SCALE(blip, 0.800000)
			HUD.SET_BLIP_PRIORITY(blip, 7)
		end
		if ch_pnts[Entity(h):get_model()] then
			if ENTITY.IS_ENTITY_A_MISSION_ENTITY(h)	then
				ENTITY.SET_ENTITY_AS_MISSION_ENTITY(h, false, true)
			end
			local blip = HUD.ADD_BLIP_FOR_ENTITY(h)
			HUD.SET_BLIP_SPRITE(blip, 776)
			HUD.SET_BLIP_COLOUR(blip, 4)
			HUD.SET_BLIP_SCALE(blip, 0.800000)
			HUD.SET_BLIP_PRIORITY(blip, 7)
		end
	end
end)

commandmgr.add_looped_command("autoloot", "自动拾取", "自动拾取战利品", function()
	if scripts.is_active("fm_mission_controller") then
		ScriptLocal("fm_mission_controller", 10713):set_int(4)
		ScriptLocal("fm_mission_controller", 10713 + 14):set_float(2)
		if ScriptLocal("fm_mission_controller", 10713):get_int() == 5 then
			commandmgr.get_command("autoloot"):set_value(false)
		end
	end

	if scripts.is_active("fm_mission_controller_2020") then
		ScriptLocal("fm_mission_controller_2020", 31275):set_int(4)
		ScriptLocal("fm_mission_controller_2020", 31275 + 14):set_float(2)
		script.yield(100)
		if ScriptLocal("fm_mission_controller_2020", 31275):get_int() == 5 then
			commandmgr.get_command("autoloot"):set_value(false)
		end
	end
end)

local function Fmmc2020Finish()
	if scripts.is_active("fm_mission_controller_2020") then
		ScriptLocal("fm_mission_controller_2020", 56504):set_int(9)
		ScriptLocal("fm_mission_controller_2020", 56504 + 1776):at(0, 1):set_float(50)
	end
end

local criminalmmbonus = false

---|| Recovery + (Other Missions) ||------------------------------------------------------------------------------

local AutoShop_Contract = {
	{ 0,	"联合储蓄",    "抢劫案" },
	{ 1,	"超级美钞交易",    "抢劫案" },
	{ 2,	"银行合约", 	   "连环抢劫" },
	{ 3,	"ECU 任务",		   "抢劫案" },
	{ 4,	"监狱合约", 	   "暗杀" },
	{ 5,	"事务所交易", 		   "突袭" },
	{ 6,	"失落摩托帮合约", 	   "任务" },
	{ 7,	"数据合约", 	   "抢劫案" },
	{ 8,	"无" }
}

commandmgr.add_list_command("autoshop_contracts", "合约", "", AutoShop_Contract, stats.get_int("MPX_TUNER_CURRENT"), function()
	stats.set_int("MPX_TUNER_CURRENT", commandmgr.get_command("autoshop_contracts"):get_value())
	local selected_autoshopcontract = AutoShop_Contract[stats.get_int("MPX_TUNER_CURRENT") + 1][2]
	if commandmgr.get_command("autoshop_contracts"):get_value() ~= 8 then
		notify.success("TinkerScript - 改装铺合约", "已选择合约： "..selected_autoshopcontract, 3000)
	else
		stats.set_int("MPX_TUNER_CURRENT", -1)
	end
	STATS.STAT_SAVE(0, 0, 3, 0)
end)

local function AutoShop_Reload()
	if scripts.is_active("tuner_planning") then ScriptLocal("tuner_planning", 418):set_int(2) end
end

-- [DOG] 佩里科岛：跳过全部前置（现代数值，社区多源验证）
local function Cayo_SkipPreps()
	stats.set_int("MPX_H4CNF_UNIFORM", -1)
	stats.set_int("MPX_H4CNF_GRAPPEL", -1)
	stats.set_int("MPX_H4CNF_TROJAN", 5)
	stats.set_int("MPX_H4CNF_WEP_DISRP", 3)
	stats.set_int("MPX_H4CNF_ARM_DISRP", 3)
	stats.set_int("MPX_H4CNF_HEL_DISRP", 3)
	stats.set_int("MPX_H4_PLAYTHROUGH_STATUS", 10)
	stats.set_int("MPX_H4CNF_BS_GEN", -1)
	stats.set_int("MPX_H4CNF_BS_ENTR", 63)
	stats.set_int("MPX_H4CNF_BS_ABIL", 63)
	stats.set_int("MPX_H4CNF_APPROACH", -1)
end

local function Cayo_ReloadBoard()
	if scripts.is_active("heist_island_planning") then ScriptLocal("heist_island_planning", 1580):set_int(2) end
end

local CluckinBellRaid = {
	GetSetupStats = { ApproachPB = stats.get_packed_bool(42108) and 1 or 0, WeaponsPI = stats.get_packed_int(51019), GearPI = stats.get_packed_int(51021), GetawayVehiclePI = stats.get_packed_int(51023) }, -- Unnecessary, just testing tables
	Approach = {
		{ 0, "潜行方式" },
		{ 1, "强攻方式" }
	},
	Weapons = {
		{ 0, "大毒蛇帮" },
		{ 1, "职业杀手" },
		{ 2, "无名民兵" }
	},
	Gear = {
		{ 0, "大毒蛇帮" },
		{ 1, "职业杀手" },
		{ 2, "无名民兵" }
	},
	GetawayVehicle = {
		{ 0, "德克拉斯 郁金香" },
		{ 1, "德克拉斯 月光（改装）" },
		{ 2, "德克拉斯 穿刺者 LX" },
		{ 3, "欧斯洛 颈动脉" },
		{ 4, "丁卡 素晴" },
		{ 5, "线圈 雷电" },
		{ 6, "猛犸 爱国者 军规版" },
		{ 7, "卡尼斯 终点" },
		{ 8, "猛犸 新兵" }
	}
}

local OzcarGuzmanFliesAgain = { -- I'm learning luaaaaaaaaaaaaaaaaaa
	Difficulty = { HardMode = false, DifficultyPB = 51272 },
	S_Mogul = { Setup = false, SetupPB = { 51265, 51266 } },
	S_IronMule = { Setup = false, SetupPB = { 51264, 51268, 51269, 51270, 51271 } },
	S_Ammunition = { Setup = false, SetupPB = { 51260, 51261, 51262, 51263 } }
}

commandmgr.add_list_command("cbr_approach", "方式", "", CluckinBellRaid.Approach, CluckinBellRaid.GetSetupStats.ApproachPB, function()
	if commandmgr.get_command("cbr_approach"):get_value() == 1 then
		stats.set_packed_bool(42108, true)
	else
		stats.set_packed_bool(42108, false)
	end
end)

commandmgr.add_list_command("cbr_weapons", "武器", "", CluckinBellRaid.Weapons, CluckinBellRaid.GetSetupStats.WeaponsPI, function()
	stats.set_packed_int(51019, commandmgr.get_command("cbr_weapons"):get_value())
end)

commandmgr.add_list_command("cbr_gear", "装备", "", CluckinBellRaid.Gear, CluckinBellRaid.GetSetupStats.GearPI, function()
	stats.set_packed_int(51021, commandmgr.get_command("cbr_gear"):get_value())
end)

commandmgr.add_list_command("cbr_getawayvehicle", "逃亡载具", "", CluckinBellRaid.GetawayVehicle, CluckinBellRaid.GetSetupStats.GetawayVehiclePI, function()
	stats.set_packed_int(51023, commandmgr.get_command("cbr_getawayvehicle"):get_value())
end)

local FIB_File = {
	{ 0,  "黑匣子档案" },
	{ 1,  "暴力破解档案" },
	{ 2,  "艺术品档案" },
	{ 3,  "突围计划档案" },
	{ 4,  "无" }
}

commandmgr.add_list_command("fib_files", "档案", "", FIB_File, stats.get_int("MPX_HACKER24_ACTIVE_ROB"), function()
	stats.set_int("MPX_HACKER24_ACTIVE_ROB", commandmgr.get_command("fib_files"):get_value())
	local selected_fibfile = FIB_File[stats.get_int("MPX_HACKER24_ACTIVE_ROB") + 1][2]
	if commandmgr.get_command("fib_files"):get_value() ~= 4 then
		notify.success("TinkerScript - FIB 档案", "已选择档案： "..selected_fibfile, 3000)
	else
		stats.set_int("MPX_HACKER24_ACTIVE_ROB", -1)
	end
	STATS.STAT_SAVE(0, 0, 3, 0)
end)

local function HackerDen_Reload()
	scripts.start_new_script("apphackerden", 4592)
end

---|| Recovery + (Content Unlocks) ||------------------------------------------------------------------------------

local Rplus_Config = {
	AW_tier = false,
	AW_stats = false,
	LSCM_rep = false,
	FacePaint_Opacity = 1.0,
	EyesColor = 1,
	ComboToFile = false,
	FiletoChar = false
}

---|| Recovery + (Tunables) ||------------------------------------------------------------------------------

commandmgr.add_bool_command("Tunaggle_Independence", "独立日", "启用独立日内容", false, function()
	for _, independenceday in ipairs (RplusTuna_IndependenceDay) do
		tunables.set_bool(independenceday.Tunable, independenceday.tunaVal)
	end
	notify.success("TinkerScript - 独立日", "独立日内容已启用！", 3000)
end,function()
	for _, independenceday in ipairs (RplusTuna_IndependenceDay) do
		tunables.set_bool(independenceday.Tunable, not independenceday.tunaVal)
	end
	notify.info("TinkerScript - 独立日", "独立日内容已关闭。", 3000)
end)

commandmgr.add_bool_command("Tunaggle_Halloween", "万圣节", "启用万圣节内容", false, function()
	for _, halloween in ipairs (RplusTuna_Halloween) do
		tunables.set_bool(halloween.Tunable, halloween.tunaVal)
	end
	notify.success("TinkerScript - 万圣节", "万圣节内容已启用！", 3000)
end,function()
	for _, halloween in ipairs (RplusTuna_Halloween) do
		tunables.set_bool(halloween.Tunable, not halloween.tunaVal)
	end
	notify.info("TinkerScript - 万圣节", "万圣节内容已关闭。", 3000)
end)

local xmas_snow = false
commandmgr.add_bool_command("Tunaggle_Xmas", "圣诞节", "启用圣诞节内容", false, function()
	for _, xmas in ipairs (RplusTuna_Christmas) do
		tunables.set_bool(xmas.Tunable, xmas.tunaVal)
	end
	notify.success("TinkerScript - 圣诞节", "圣诞节内容已启用！", 3000)
end,function()
	for _, xmas in ipairs (RplusTuna_Christmas) do
		tunables.set_bool(xmas.Tunable, not xmas.tunaVal)
	end
	notify.info("TinkerScript - 圣诞节", "圣诞节内容已关闭。", 3000)
end)

---|| Recovery + (Money) ||------------------------------------------------------------------------------

local SindyBar = {
	Loop = false,
	Money = 100000,
	Delay = 3000,
	ManualBarMoney = false
}

---|| Recovery + (Human canvas) ||------------------------------------------------------------------------------

commandmgr.add_list_command("humcanv_fp1list", "##fp1list", "", HumanC_FP, stats.get_packed_int(451), function()
	stats.set_packed_int(451, commandmgr.get_command("humcanv_fp1list"):get_value())
end)

commandmgr.add_list_command("humcanv_fp2list", "##fp2list", "", HumanC_FP2, stats.get_packed_int(3942), function()
	stats.set_packed_int(3942, commandmgr.get_command("humcanv_fp2list"):get_value())
end)


TS_RecoveryPlus:imgui(function() if not network.is_session_started() then ImGui.TextDisabled("请先进入自由模式战局。") return end

	ImGui.BeginTabBar("recoplus") -- Learned tabs ;D
	if ImGui.BeginTabItem("保险柜破解") then

		ImGui.BeginGroup()
		ImGui.BeginChild("##ineedanameforthis", 424, 584, 1)
		CenteredText("抢劫任务", false, true)

		--ImGui.PushStyleVar(ImGuiStyleVar.TabBarBorderSize, 0) -- issues/4859 ocornut
		ImGui.BeginTabBar("抢劫任务"--[[, ImGuiTabBarFlags.NoTabListScrollingButtons + ImGuiTabBarFlags.FittingPolicyScroll]])
		if ImGui.BeginTabItem("克拉克快餐突袭") then

			ImGui.Text("克拉克飞贼")ImGui.Separator()ImGui.Spacing()
			ImGui.BeginDisabled(not STREAMING.IS_IPL_ACTIVE("cs1_02_cf_onmission4"))

			ImGui.BeginGroup()
			if ImGui.Button("传送至信号点", 200) then
				CBTpToPC()
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("传送到信号最强的电脑旁") end

			if ImGui.Button("传送至货箱", 200) then
				CBTpToCrate()
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("Teleports you to the stashed drugs.\nTeleports you to the Office PC if there are no crates left to search.") end

			if scripts.is_active("fm_mission_controller_2020") and ScriptLocal("fm_mission_controller_2020", 21088):get_int() == 1149534208 then -- Previously just a TpToBlip but it only worked when near the crowbar (when blip appears)
				if not WEAPON.HAS_PED_GOT_WEAPON(PLAYER.PLAYER_PED_ID(), "WEAPON_CROWBAR", false) then
					if ImGui.Button("获取撬棍", 200) then
						WEAPON.GIVE_WEAPON_TO_PED(PLAYER.PLAYER_PED_ID(), "WEAPON_CROWBAR", 1, false, true)
					end
				end
			end

			commandmgr.get_command("cbr_opendoors"):draw()
			ImGui.EndGroup()

			ImGui.SameLine() ImGui.BeginGroup()
			if ImGui.Button("撬开克拉克快餐保险柜", 200) then
				script.run_in_callback(CrackCB)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("撬开保险柜") end

			if ImGui.Button("传送至办公室钥匙##cbr", 200) then
				TpToEntity(-1423372530)
			end

			if ImGui.Button("瞬间完成##cbr", 200) then
				Fmmc2020Finish()
			end
			ImGui.EndGroup()

			ImGui.EndDisabled()
			ImGui.EndTabItem()
		end

		if ImGui.BeginTabItem("科兹中心劫案") then
			ImGui.Text("科兹中心破解")ImGui.Separator()ImGui.Spacing()

			if ScriptGlobal(1980570 + 1090):get_int() == 3 then
				if ImGui.Button("快速开始劫案", 200) then
					script.run_in_callback(TS_KortzStart)
				end
			end

			ImGui.BeginDisabled(not scripts.is_active("fm_mission_controller_v3"))

			ImGui.BeginGroup()
			if ImGui.Button("跳过数据破解", 200) then
				TS_KortzDC()
			end

			if ImGui.Button("跳过指纹破解", 200) then
				TS_KortzFP()
			end

			if ImGui.Button("自动输入电脑访问码", 200) then
				script.run_in_callback(TS_KortzPCAC)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("自动输入访问码") end

			if ImGui.Button("禁用激光", 200) then
				TS_KortzPwrL()
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("禁用激光网") end

			if ImGui.Button("跳过金库门破解", 200) then
				TS_KortzSN()
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("跳过信号节点破解") end

			if ImGui.Button("传送至出口钥匙", 200) then
				TpToBlip(true, Blips.CRIM_CUFF_KEYS, false)
			end
			ImGui.EndGroup()

			ImGui.SameLine() ImGui.BeginGroup()
			if ImGui.Button("拿取主要目标", 200) then
				script.run_in_callback(TS_KortzPaint)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("立即拿取主要目标") end

			if ImGui.Button("拿取次要目标", 200) then
				TS_KortzPaint2()
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("立即拿取次要目标") end

			if ImGui.Button("切玻璃", 200) then
				TS_KortzGlass()
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("立即切开展示柜玻璃") end

			if ImGui.Button("禁用所有摄像头", 200) then
				if ScriptLocal("fm_mission_controller_v3", 57250 + 1):get_int() == 17456129 and not scripts.is_active("fmmc_lasers") then
					if not commandmgr.get_command("kortz_delcams"):get_value() then
						commandmgr.get_command("kortz_delcams"):set_value(true)
					else
						commandmgr.get_command("kortz_delcams"):set_value(false)
					end
				else
					ScriptLocal("fm_mission_controller_v3", 70176):at(0, 295):at(237 + 1):set_int(-2145222410)
				end
			end

			if ImGui.IsItemHovered() then
				if ScriptLocal("fm_mission_controller_v3", 57250 + 1):get_int() == 17456129 and not scripts.is_active("fmmc_lasers") then
					ImGui.SetTooltip("Exterior: Disables All Cameras for 12 seconds\nMISSION WILL BREAK IF YOU ABUSE THIS OPTION!")
				else
					ImGui.SetTooltip("室内：禁用监控系统。")
				end
			end

			if ImGui.Button("传送至门禁卡##k26_card", 200) then
				TpToBlip(true, Blips.KEYCARD, false)
			end

			if ImGui.Button("瞬间完成##k26", 200) then
				if ScriptLocal("fm_mission_controller_v3", 57250 + 1):get_int() == 17718273 then
					TS_KortzFinish()
				else
					notify.error("TinkerScript - 科兹中心破解", "必须在建筑内部才能使用瞬间完成！", 3000)
				end
			end

			ImGui.EndGroup()

			if stats.get_masked_int("MPX_K26_GENERAL_BS", 27, 1) == 0 then
				if ImGui.Button("传送至井盖钥匙", 200) then
					TpToBlip(false, Blips.MANHOLE_KEY, true)
				end
				ImGui.SameLine()
			end

			commandmgr.get_command("kortz_opendoors"):draw()

			if util.time() < kortzcamtimer + 12000 then
				ImGui.SameLine()
				ImGui.TextDisabled(string.format("已禁用摄像头：%.1f", (kortzcamtimer + 12001 - util.time()) / 1000))
			end

			if scripts.is_active("fmmc_lasers") then
				K26_Leasy = ImGui.Checkbox("简单激光", K26_Leasy)
				ImGui.SameLine()
				K26_Lnodamage = ImGui.Checkbox("激光无伤", K26_Lnodamage)
				if K26_Leasy then
					ScriptLocal("fmmc_lasers", 1058):set_int(1)
					ScriptLocal("fmmc_lasers", 1059):set_int(0)
				else
					ScriptLocal("fmmc_lasers", 1058):set_int(0)
					ScriptLocal("fmmc_lasers", 1059):set_int(1)
				end
				if K26_Lnodamage then
					ScriptLocal("fmmc_lasers", 1060):set_int(1)
				else
					ScriptLocal("fmmc_lasers", 1060):set_int(0)
				end if ImGui.IsItemHovered() then ImGui.SetTooltip("穿过激光不受伤害。") end
			end

			if scripts.is_active("fm_mission_controller_v3") then
				ImGui.Text("战利品")ImGui.Separator()ImGui.Spacing()
				local k26_take

				ImGui.SetNextItemWidth(140)
				if ScriptLocal("fm_mission_controller_v3", 60737 + 1376 + 60):get_int() ~= nil then
					k26_take = ImGui.InputInt("拿取", ScriptLocal("fm_mission_controller_v3", 60737 + 1376 + 60):get_int())
				end
				ScriptLocal("fm_mission_controller_v3", 60737 + 1376 + 60):set_int(k26_take)

				ImGui.SetNextItemWidth(120)
				local k26_bagcap = ImGui.InputInt("背包容量", tunables.get_int(6971439))
				tunables.set_int(6971439, k26_bagcap)
			end

			ImGui.EndDisabled()
			ImGui.EndTabItem()
		end

		if ImGui.BeginTabItem("佩里科岛劫案") then
			ImGui.Text("佩里科岛")ImGui.Separator()ImGui.Spacing()
			ImGui.BeginDisabled((not STREAMING.IS_IPL_ACTIVE("h4_islandx_sea_mines") and not scripts.is_active("fm_mission_controller_2020")))

			if ImGui.Button("单人闸门", 200) then
				script.run_in_callback(function()
					ScriptLocal("fm_mission_controller_2020", 69374):at(0, 293):at(236):set_int(7)
					script.yield(200)
					ScriptLocal("fm_mission_controller_2020", 21215):set_int(1)
				end)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("绕过双门禁系统") end

			ImGui.SameLine() if ImGui.Button("拿取次要目标##Cayo", 200) then
				ScriptLocal("fm_mission_controller_2020", 29373 + 11):set_int(3)
				PAD.SET_CONTROL_VALUE_NEXT_FRAME(0, 219, 1.0)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("立即拿取次要目标") end

			if ImGui.Button("传送至门禁卡", 200) then
				TpToBlip(true, Blips.KEYCARD, false)
				script.run_in_callback(function()
					script.yield(500)
					PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), 5012.4, -5755.6, 28.9)
				end)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("击杀全部敌人并传送到可用的门禁卡旁") end

			ImGui.SameLine()
			if ImGui.Button("传送至大门钥匙", 200) then
				TpToBlip(true, Blips.CRIM_CUFF_KEYS, false)
			end

			if ImGui.Button("删除摄像头", 200) then
				script.run_in_callback(ch_delcam) -- It took me a whole year to realize I can call functions this way
			end

			commandmgr.get_command("ch_opendoors"):draw()

			if scripts.is_active("fm_mission_controller_2020") then
				ImGui.Text("战利品")ImGui.Separator()ImGui.Spacing()
				local ch_take

				ImGui.SetNextItemWidth(140)

				if ScriptLocal("fm_mission_controller_2020", 59986 + 1376 + 60):get_int() ~= nil then
					ch_take = ImGui.InputInt("拿取", ScriptLocal("fm_mission_controller_2020", 59986 + 1376 + 60):get_int())
				end
				ScriptLocal("fm_mission_controller_2020", 59986 + 1376 + 60):set_int(ch_take)

				ImGui.SetNextItemWidth(120)
				local ch_bagcap = ImGui.InputInt("背包容量",  tunables.get_int(1859395035))
				tunables.set_int(1859395035, ch_bagcap)
			end

			ImGui.EndDisabled()
			ImGui.EndTabItem()
		end
		--ImGui.PopStyleVar()
	ImGui.EndTabBar()
	ImGui.EndChild()
	ImGui.EndGroup()

	ImGui.SameLine(0, 6.8)

	ImGui.BeginGroup()
	ImGui.BeginChild("##missionskips", 406, 584, 1) -- Almost perfectly aligned with last category (by chance)

	CenteredText("额外功能", false, true) -- Previously "Other Missions", I really don't know what to names these things

	ImGui.Text("任务跳过与前置") if ImGui.IsItemHovered() then ImGui.SetTooltip("仅限无法通过暂停菜单重玩的任务") end ImGui.Separator()ImGui.Spacing()

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("Dr. Dre 合约  ##"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("##drecontract", 210, 104, 1) then
				if ImGui.Button("跳过：别惹 Dre", -1) then
					stats.set_int("MPX_FIXER_STORY_BS", 4095)
					notify.success("TinkerScript - Dr. Dre 合约跳过", "Success! All preps skipped.\nNext mission: Don't F* With Dre", 3000)
				end
				ImGui.Separator()
				if ImGui.Button("瞬间完成") then
					Fmmc2020Finish()
				end
				if ImGui.Button("传送至事务所") then
					TpToBlip(false, Blips.Property.AGENCY.ID, false)
				end
			end ImGui.EndChild()
		end

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("改装铺合约  ##"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("##autoshopchild", 320, 134, 1) then
				local autoshop_contractfinale
				if stats.get_int("MPX_TUNER_CURRENT") > -1 then
					autoshop_contractfinale = AutoShop_Contract[stats.get_int("MPX_TUNER_CURRENT") + 1][3]
					if ImGui.Button("跳过： "..autoshop_contractfinale, -1) then
						stats.set_int("MPX_TUNER_GEN_BS", -1)
						notify.success("TinkerScript - 改装铺跳过", "Success! All preps skipped.\nNext mission: "..autoshop_contractfinale, 3000)
					end
					ImGui.Separator()
				end
				commandmgr.get_command("autoshop_contracts"):draw()
				if ImGui.Button("重载任务板") then AutoShop_Reload() end
				if ImGui.Button("传送至改装铺") then
					TpToBlip(false, Blips.Property.AUTO_SHOP_PROPERTY.ID, false)
				end
			end ImGui.EndChild()
		end

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("克拉克快餐突袭  ##"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("##cbrchild", 390, 192, 1) then
				if ImGui.Button("跳过：犯罪现场", -1) then
					stats.set_int("MPX_SALV23_INST_PROG", 31)
					notify.success("TinkerScript - 克拉克快餐突袭跳过", "Success! All preps skipped.\nNext mission: Scene of the Crime", 3000)
				end
				ImGui.Separator()
				commandmgr.get_command("cbr_approach"):draw()
				commandmgr.get_command("cbr_weapons"):draw()
				commandmgr.get_command("cbr_gear"):draw()
				commandmgr.get_command("cbr_getawayvehicle"):draw()
				if ImGui.Button("传送至 L.S.P.D.") then
					TpToBlip(false, Blips.VINCENT, false)
				end
			end ImGui.EndChild()
		end

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("LSA 行动 ##"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("##avopchild", 260, 42, 1) then
				if ImGui.Button("瞬间完成", -1) then
					if scripts.is_active("fm_content_smuggler_ops") then
						ScriptLocal("fm_content_smuggler_ops", 7881 + 1306):set_int(1)
						LocalSetBit(ScriptLocal("fm_content_smuggler_ops", 7743 + 1), 1, 11)
					end
				end
				-- Cooldowns can be skipped but finishing a mission will triger a transaction failed screen
			end ImGui.EndChild()
		end

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("FIB 档案  ##fibsetups"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("#fibchild#", 320, 134, 1) then
				local fib_filefinale
				if stats.get_int("MPX_HACKER24_ACTIVE_ROB") > -1 then
					fib_filefinale = FIB_File[stats.get_int("MPX_HACKER24_ACTIVE_ROB") + 1][2]
					if ImGui.Button("跳过： "..fib_filefinale, -1) then
						stats.set_int("MPX_HACKER24_GEN_BS", -1)
						notify.success("TinkerScript - FIB 档案跳过", "Success! All preps skipped.\nNext mission: "..fib_filefinale, 3000)
					end
					ImGui.Separator()
				end
				commandmgr.get_command("fib_files"):draw()
				if ImGui.Button("重载电脑") then HackerDen_Reload() end
				if ImGui.Button("传送至制衣厂") then
					TpToBlip(false, Blips.Property.GARMENT_FACTORY.ID, false)
				end
			end ImGui.EndChild()
		end

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("奥斯卡·古兹曼再起飞  ##"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("##ogfachild", 320, 192, 1) then
				if ImGui.Button("跳过：泰坦任务", -1) then
					stats.set_int("MPX_HACKER24_INST_BS", -1)
					notify.success("TinkerScript - 奥斯卡·古兹曼跳过", "Success! All preps skipped.\nNext mission: The Titan Job", 3000)
				end
				ImGui.Separator()
				OzcarGuzmanFliesAgain.Difficulty.HardMode = ImGui.Checkbox("困难模式", OzcarGuzmanFliesAgain.Difficulty.HardMode) -- I completed this part withour errors on first try :')
				OzcarGuzmanFliesAgain.S_Mogul.Setup = ImGui.Checkbox("前置：莫古尔", OzcarGuzmanFliesAgain.S_Mogul.Setup)
				OzcarGuzmanFliesAgain.S_IronMule.Setup = ImGui.Checkbox("前置：铁骡", OzcarGuzmanFliesAgain.S_IronMule.Setup)
				OzcarGuzmanFliesAgain.S_Ammunition.Setup = ImGui.Checkbox("前置：弹药", OzcarGuzmanFliesAgain.S_Ammunition.Setup)
				stats.set_packed_bool(OzcarGuzmanFliesAgain.Difficulty.DifficultyPB, OzcarGuzmanFliesAgain.Difficulty.HardMode)
				for _, pbstat in ipairs(OzcarGuzmanFliesAgain.S_Mogul.SetupPB) do stats.set_packed_bool(pbstat, OzcarGuzmanFliesAgain.S_Mogul.Setup) end
				for _, pbstat in ipairs(OzcarGuzmanFliesAgain.S_IronMule.SetupPB) do stats.set_packed_bool(pbstat, OzcarGuzmanFliesAgain.S_IronMule.Setup) end
				for _, pbstat in ipairs(OzcarGuzmanFliesAgain.S_Ammunition.SetupPB) do stats.set_packed_bool(pbstat, OzcarGuzmanFliesAgain.S_Ammunition.Setup) end
				if ImGui.Button("传送至麦肯齐机场机库") then
					TpToBlip(false, Blips.Property.FIELD_HANGAR.ID, false)
				end
			end ImGui.EndChild()
		end

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("KnoWay 突围 ##"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("##knowayoutchild", 260, 104, 1) then
				if ImGui.Button("跳过：彻底决裂", -1) then
					stats.set_int("MPX_M25_AVI_MISSION_CURRENT", 4)
					notify.success("TinkerScript - KnoWay 突围跳过", "Success! All preps skipped.\nNext mission: A Clean Break", 3000)
				end
				ImGui.Separator()
				if ImGui.Button("传送至公用电话") then
					TpToBlip(false, Blips.ARMENIAN_FAMILY, false)
				end
				if ImGui.Button("瞬间完成") then
					Fmmc2020Finish()
				end
			end ImGui.EndChild()
		end

		ImGui.Spacing()

		ImGui.Spacing()ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("佩里科岛  ##cayopericopreps"..nomoretreeplease, 8219) then
			if ImGui.BeginChild("##cayoprepchild", 320, 134, 1) then
				if ImGui.Button("跳过：全部前置", -1) then
					Cayo_SkipPreps()
					script.run_in_callback(function()
						script.yield(500)
						Cayo_ReloadBoard()
					end)
					notify.success("TinkerScript - 佩里科岛跳过", "Success! All preps skipped.\n建议换装或购买任意物品触发一次存档", 3000)
				end
				if ImGui.Button("瞬间完成终章", -1) then
					Fmmc2020Finish()
					notify.success("TinkerScript - 佩里科岛终章", "已请求瞬间完成终章（需在任务中）", 3000)
				end
				ImGui.Separator()
				if ImGui.Button("重载规划板") then Cayo_ReloadBoard() end
			end ImGui.EndChild()
		end

		ImGui.Text("杂项")ImGui.Separator()ImGui.Spacing()

		if ImGui.Button("启用每周加成") then
			stats.set_int("MPX_WEEKLY_BOOST_BS", 0)
			notify.success("TinkerScript - 每周加成", "每周加成已重置！劫案终章将获得最高收益。", 3000)
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("Resetting the weekly boost will get you the max payout in heist finales.\nNo one has *reported getting banned for this (yet).") end

		if ImGui.Button("犯罪之神奖励") then -- unknowncheats.me/forum/grand-theft-auto-v/453340
			if not criminalmmbonus then
				stats.set_int("MPPLY_HEISTFLOWORDERPROGRESS", 268435455)
				stats.set_int("MPPLY_HEISTTEAMPROGRESSBITSET", 268435455)
				stats.set_int("MPPLY_HEISTNODEATHPROGREITSET", 268435455)
				stats.set_bool("MPPLY_AWD_HST_ORDER", false)
				stats.set_bool("MPPLY_AWD_HST_SAME_TEAM", false)
				stats.set_bool("MPPLY_AWD_HST_ULT_CHAL", false)
				criminalmmbonus = true
				notify.success("TinkerScript - 犯罪之神挑战","1200 万奖励已启用！", 3000)
			else
				stats.set_int("MPPLY_HEISTFLOWORDERPROGRESS", -1)
				stats.set_int("MPPLY_HEISTTEAMPROGRESSBITSET", -1)
				stats.set_int("MPPLY_HEISTNODEATHPROGREITSET", -1)
				stats.set_bool("MPPLY_AWD_HST_ORDER", true)
				stats.set_bool("MPPLY_AWD_HST_SAME_TEAM", true)
				stats.set_bool("MPPLY_AWD_HST_ULT_CHAL", true)
				criminalmmbonus = false
				notify.info("TinkerScript - 犯罪之神挑战","1200 万奖励已关闭。", 3000)
			end
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("启用完成“犯罪之神挑战”后的 1200 万奖励。") end

		if ImGui.Button("赌场劫案 P.O.I 重置") then
			stats.set_int("MPX_H3OPT_POI", 0)
			stats.set_int("MPX_H3OPT_ACCESSPOINTS", 0)
			notify.success("TinkerScript - 赌场劫案 P.O.I 重置", "钻石赌场劫案的 P.O.I 与出入点已重置。", 3000)
		end

		if stats.get_int("MPX_CH_ARC_CAB_DISPLAY_SLOT36") ~= 18 or stats.get_int("MPX_CH_ARC_CAB_DISPLAY_SLOT37") ~= 19 then
			if ImGui.Button("赌场劫案附加项重置") then
				stats.set_int("MPX_CAS_HEIST_FLOW", -1610744001)
				notify.success("TinkerScript - 赌场劫案附加项重置", "保险库密码盘与金库门的可用状态已修复。", 3000)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("Resets Secure Keypad & Vault Door at the Arcade, making them available for purchase again.\nYou'll only need this if you can't use them. Once purchased, you'll never have this problem again.") end
		end

		if ImGui.Button("撬开藏匿屋保险柜") then
			if scripts.is_active("fm_content_stash_house") then script.run_in_callback(CrackSH) end
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("撬开保险柜") end

		ImGui.EndChild()
		ImGui.EndGroup()

		ImGui.Text("战利品自动拾取")ImGui.Separator()ImGui.Spacing()
		commandmgr.get_command("autoloot"):draw()

		ImGui.EndTabItem()
	end

	if ImGui.BeginTabItem("解锁") then
		ImGui.Text("内容解锁")ImGui.Separator()ImGui.Spacing()

		if ImGui.Button("地堡") then
			Rplus_Bunker()
		end

		if ImGui.Button("竞技场之战##unlock") then
			Rplus_ArenaWar()
		end

		ImGui.SameLine() Rplus_Config.AW_tier = ImGui.Checkbox("等级 1000", Rplus_Config.AW_tier)
		ImGui.SameLine() Rplus_Config.AW_stats = ImGui.Checkbox("写入数据", Rplus_Config.AW_stats)

		if ImGui.Button("收藏品") then
			Rplus_Collectibles()
		end

		if ImGui.Button("纹身") then
			Rplus_Tattoos()
		end

		if ImGui.Button("洛圣都改车王") then
			Rplus_LSCustoms()
		end

		if ImGui.Button("洛圣都车友会") then
			Rplus_LSCM()
		end

		ImGui.SameLine() Rplus_Config.LSCM_rep = ImGui.Checkbox("声望等级 1000", Rplus_Config.LSCM_rep)

		--if ImGui.Button("Eye Colors") then -- Works but doesn't save
		--	PED.SET_HEAD_BLEND_EYE_COLOR(PLAYER.PLAYER_PED_ID(), Rplus_Config.EyesColor)
		--end
		--
		--ImGui.SameLine() Rplus_Config.EyesColor = ImGui.InputInt("Eyes Color", Rplus_Config.EyesColor)

		if ImGui.Button("万圣节面绘") then
			stats.set_packed_bool_range(4270, 4299, true)
		end

		if ImGui.Button("豪宅奖杯") then
			Rplus_MansionTrophies()
		end

		if ImGui.Button("全部服装") then
			Rplus_Cloooathes()
		end

		ImGui.Spacing()ImGui.Spacing()
		ImGui.Text("角色属性")ImGui.Separator()ImGui.Spacing()

		if ImGui.Button("全部技能拉满") then
			stats.set_int("MPX_SCRIPT_INCREASE_STAM", 100)
			stats.set_int("MPX_SCRIPT_INCREASE_STRN", 100)
			stats.set_int("MPX_SCRIPT_INCREASE_DRIV", 100)
			stats.set_int("MPX_SCRIPT_INCREASE_FLY", 100)
			stats.set_int("MPX_SCRIPT_INCREASE_STL", 100)
			stats.set_int("MPX_SCRIPT_INCREASE_LUNG", 100)
			stats.set_int("MPX_SCRIPT_INCREASE_SHO", 100)
			stats.set_int("MPX_CHAR_FM_HEALTH_1_UNLCK", -1)
			stats.set_int("MPX_CHAR_FM_HEALTH_2_UNLCK", -1)
		end

		if ImGui.Button("快速奔跑") then
			Rplus_FastRun()
		end

		if ImGui.Button("锁定等级") then
			Rplus_FrozenRank()
		end

		ImGui.Spacing()ImGui.Spacing()
		ImGui.Text("奖项")ImGui.Separator()ImGui.Spacing()
		if ImGui.Button("解锁全部奖项") then ImGui.OpenPopup("##warnallawards") end if ImGui.IsItemHovered() then ImGui.SetTooltip("解锁全部奖项。") end

		if ImGui.BeginPopupModal("##warnallawards", nil, 65) then
			ImGui.Text("确定要解锁全部奖项吗？")
			ImGui.Spacing()
			if ImGui.Button("是") then
				for _, allAwards in ipairs(Rplus_Awards) do
					allAwards.Unlock()
				end
				notify.success("TinkerScript - 仅全部奖项", "全部奖项已解锁！", 3000)
				ImGui.CloseCurrentPopup()
			end
			ImGui.SameLine()
			if ImGui.Button("否") then
				ImGui.CloseCurrentPopup()
			end
			ImGui.EndPopup()
		end

		ImGui.SameLine()
		ImGui.Spacing()
		ImGui.SameLine(0, 3.8)
		if ImGui.TreeNodeEx("分类  ##"..nomoretreeplease, 8219) then
			for i, Awards in ipairs(Rplus_Awards) do
				if (i - 1) % 4 ~= 0 then ImGui.SameLine() end

				if ImGui.Button(Awards.Category) then
					Awards.Unlock()
					notify.success("TinkerScript - 仅全部奖项", string.format("All \"%s\" Awards Unlocked!", Awards.Category))
				end
			end
		end

		ImGui.Spacing()ImGui.Spacing()
		ImGui.Text("生涯进度")ImGui.Separator()ImGui.Spacing()
		if ImGui.Button("完成全部挑战") then
			Rplus_CareerProgress()
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("完成全部挑战。") end

		ImGui.Spacing()ImGui.Spacing()
		ImGui.Text("杂项")ImGui.Separator()ImGui.Spacing()

		if ImGui.Button("车友会周奖励载具") then
			if not stats.get_bool("MPX_CARMEET_PV_CLMED") then
				stats.set_bool("MPX_CARMEET_PV_CHLLGE_CMPLT", true)
				notify.success("TinkerScript - 车友会周奖励载具", "成功！本周奖励载具已可领取！")
			else
				notify.error("TinkerScript - 车友会周奖励载具", "你本周的奖励载具已经领过了！")
			end
		end

		if ImGui.Button("跳过珍妮特对话") then
			stats.set_packed_bool_range(51192, 51195, true)
			notify.success("TinkerScript - 哑巴珍妮特", "成功！珍妮特的对话已跳过！")
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("在保释办公室用笔记本时跳过珍妮特的对话。") end

		ImGui.EndTabItem()
	end

	if ImGui.BeginTabItem("配置项") then
		ImGui.Text("内容配置项")ImGui.Separator()ImGui.Spacing()

		commandmgr.get_command("Tunaggle_Independence"):draw()
		commandmgr.get_command("Tunaggle_Halloween"):draw()
		commandmgr.get_command("Tunaggle_Xmas"):draw()

		if commandmgr.get_command("Tunaggle_Xmas"):get_value() then
			ImGui.SameLine() xmas_snow = ImGui.Checkbox("开启下雪", xmas_snow)

			if xmas_snow then
				tunables.set_bool(-1146554960, true)
				tunables.set_bool(-1195222077, false)
			else
				tunables.set_bool(-1146554960, false)
				tunables.set_bool(-1195222077, true)
			end
		end

		ImGui.EndTabItem()
	end

	if ImGui.BeginTabItem("金钱") then
		ImGui.Text("金钱")ImGui.Separator()ImGui.Spacing()

		if ImGui.Button("好行为奖金") then
			ScriptGlobal(2697091):set_int(2000)
			ScriptGlobal(2697090):set_int(1)
		end

		if ImGui.Button("赌场会员奖金") then
			ScriptGlobal(1973325):set_int(1)
		end

		if not SindyBar.Loop then
			if ImGui.Button("Sindy 循环") then
				if scripts.is_active("ob_jukebox") then
					SindyBar.Loop = true
					script.run_in_callback(function()
						while true do
							script.yield(SindyBar.Delay)
							if SindyBar.Loop then
								ScriptGlobal(PropGlob.mcbar):at(PLAYER.PLAYER_ID(), 884):set_int(SindyBar.Money)
								script.yield(200)
								LocalSetBit(ScriptLocal("am_mp_property_int", 230), 1, 18)
							else
								notify.info("TinkerScripts - Sindy 循环", "循环已取消。", 3000) return
							end
						end
					end)
				else
					notify.error("TinkerScripts - Sindy 循环", "必须待在会所里才能收取酒吧收益！", 3000)
				end
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("别跟歌手辛迪·劳珀搞混了。") end
		else
			if ImGui.Button("取消") then SindyBar.Loop = false end
		end

		ImGui.SameLine()

		SindyBar.ManualBarMoney = ImGui.Checkbox("手动选项", SindyBar.ManualBarMoney)

		if SindyBar.ManualBarMoney then
			if ImGui.BeginChild("##sindylooperchild", 282, 132, 1) then
				ImGui.SetNextItemWidth(128) SindyBar.Money = ImGui.InputInt("收益", SindyBar.Money)
				ImGui.SameLine() if ImGui.Button("设定", 41) then ScriptGlobal(PropGlob.mcbar):at(PLAYER.PLAYER_ID(), 884):set_int(SindyBar.Money) end
				ImGui.SetNextItemWidth(108) SindyBar.Delay, MCBD_changed = ImGui.InputInt("循环间隔", SindyBar.Delay)
				ImGui.Spacing()
				if SindyBar.Money > 100000 then SindyBar.Money = 100000 end
				if ImGui.Button("传送至会所") then
					TpToBlip(false, Blips.Property.BIKER_CLUBHOUSE.ID, false)
				end
				if ImGui.Button("收取酒吧收益") then
					if scripts.is_active("ob_jukebox") then
						LocalSetBit(ScriptLocal("am_mp_property_int", 230), 1, 18)
					else
						notify.error("TinkerScripts - Sindy 循环", "必须待在会所里才能收取酒吧收益！", 3000)
					end
				end
			end ImGui.EndChild()
		end
		ImGui.EndTabItem()
	end

	if ImGui.BeginTabItem("人体画布") then

		ImGui.Text("纹身") if ImGui.IsItemHovered() then ImGui.SetTooltip("Allows you to stack tattoos.\nFind a new session to see changes") end ImGui.Separator()

		ImGui.BeginGroup()
		if next(TattooZone) == nil then -- from stackoverflow... again...
			for _, TatZone in ipairs(HumanCanvas()) do
				TattooZone[TatZone.BPart] = { selectedTatName = "选择……", searchTat = "" }
			end
		end

		for _, TatZone in ipairs(HumanCanvas()) do -- from Weapons category
			local ZoneName = TatZone.BPart
			local Tattoo = TattooZone[ZoneName]
			local TatPopup = "##tattoo_popup"..ZoneName

			ImGui.BeginGroup()
			ImGui.Dummy(75, 0) -- I don't know if this is the right way to use ImGui.Dummy, but it works
			ImGui.AlignTextToFramePadding()
			ImGui.Text(ZoneName..":")
			ImGui.EndGroup()
			ImGui.SameLine()

			ImGui.BeginGroup()
			ImGui.Dummy(0, 0)
			ImGui.SetNextItemWidth(300)
			ImGui.BeginCombo("##tattoos"..ZoneName, Tattoo.selectedTatName)

			if ImGui.IsItemActive() and not ImGui.IsPopupOpen(TatPopup) then
				ImGui.OpenPopup(TatPopup)
				Tattoo.searchTat = ""
			end

			if ImGui.BeginPopup(TatPopup, ImGuiWindowFlags.NoResize + ImGuiWindowFlags.NoMove) then
				ImGui.Text("搜索：")
				ImGui.SameLine()
				ImGui.SetNextItemWidth(250)
				Tattoo.searchTat = ImGui.InputText("##searchtattoo"..ZoneName, Tattoo.searchTat)

				local searchLower = string.lower(Tattoo.searchTat)

				for i, tat in ipairs(TatZone.Tattoos) do
					local tattooLower = string.lower(tat.tatName.." ")

					if tattooLower:find(searchLower) then
						if ImGui.Selectable(tat.tatName) then
							Tattoo.selectedTatName = tat.tatName
							Tattoo.selectedTattoo = tat.tatStat
							Tattoo.selectedTatVal = tat.tatVal
						end
					end
				end
				ImGui.EndPopup()
			end

			ImGui.SameLine()
			ImGui.BeginDisabled(Tattoo.selectedTatName == "选择……")

			if ImGui.Button("应用##"..ZoneName) then
				stats.set_masked_bool(Tattoo.selectedTattoo, Tattoo.selectedTatVal, true) -- I should probably use set_masked_int but this is more convenient
				notify.success("TinkerScript - 人体画布", "已应用： "..Tattoo.selectedTatName)
			end

			ImGui.SameLine()

			if Tattoo.selectedTattoo ~= nil then
				if stats.get_masked_bool(Tattoo.selectedTattoo, Tattoo.selectedTatVal) ~= false then -- Could be useful after applying the wrong tattoo or something
					if ImGui.Button("移除##"..ZoneName) then
						stats.set_masked_bool(Tattoo.selectedTattoo, Tattoo.selectedTatVal, false)
						notify.info("TinkerScript - 人体画布", "已移除： " .. Tattoo.selectedTatName)
						Tattoo.selectedTatName = "选择……"
					end
				end
			end

			ImGui.EndDisabled()
			ImGui.EndGroup()
		end
		ImGui.EndGroup()

		--ImGui.SameLine()
		ImGui.BeginGroup()

		ImGui.Spacing()
		--ImGui.BeginChild("##hc_tattoooptionschild", 316, 104, 1) -- I'm not completely sure about the ui here
		if ImGui.Button("导入纹身", 154) then
			if not Rplus_Config.FiletoChar then
				for stat in ImGui.GetClipboardText():gmatch("[^\r\n]+") do -- from stackoverflow
					if stat:match("MPX_TATTOO_FM_CURRENT_(%d+) = (%-?%d+)") then
						local tatstat, tatvalue = stat:match("^(.-) = (.-)$")
						stats.set_int(tatstat, tonumber(tatvalue))
					else
						log.error(string.format("%s%sTinkerScript - Human Canvas: \27[0;31mWrong Tattoo format!\27[m Make sure you copied the stats correctly.", cls, lual))
						notify.error("TinkerScript - 人体画布", "纹身格式错误！请确认数据复制完整。", 3000) break
					end
					notify.success("TinkerScript - 人体画布", "Success! Tattoo Combo applied correctly.\nPlease change sesions to see the changes", 3000)
					STATS.STAT_SAVE(0, 0, 3, 0)
				end
			else
				for stat in TS_PATH_FMCharTatCombo():gmatch("[^\r\n]+") do
					if stat:match("MPX_TATTOO_FM_CURRENT_(%d+) = (%-?%d+)") then
						local tatstat, tatvalue = stat:match("^(.-) = (.-)$")
						stats.set_int(tatstat, tonumber(tatvalue))
					else
						log.error(string.format("%s%sTinkerScript - Human Canvas: \27[0;31mWrong Tattoo File format!\n\27[mValid format: MPX_TATTOO_FM_CURRENT_X = Value", cls, lual))
						notify.error("TinkerScript - 人体画布", "纹身文件格式错误！正确格式：MPX_TATTOO_FM_CURRENT_X = 数值", 3000) break
					end
					notify.success("TinkerScript - 人体画布", "Success! Tattoo Combo applied correctly.\nPlease change sesions to see the changes", 3000)
					STATS.STAT_SAVE(0, 0, 3, 0)
				end
			end
		end

		ImGui.SameLine() Rplus_Config.FiletoChar = ImGui.Checkbox("从文件加载", Rplus_Config.FiletoChar) if ImGui.IsItemHovered() then ImGui.SetTooltip("开启后从文件读取纹身数据。") end

		if ImGui.Button("导出纹身", 154) then
			local ExpTatCombo = {}
			for i = 0, 53 do
				local tatCombo = stats.get_int("MPX_TATTOO_FM_CURRENT_"..i)
				table.insert(ExpTatCombo, string.format("MPX_TATTOO_FM_CURRENT_%d = %d", i, tatCombo))
			end
			if Rplus_Config.ComboToFile then
				FileMgr.WriteFileContent(TinkerPath.."/TinkerScripts/HumanCanvas/Exported_TattooCombo.txt", table.concat(ExpTatCombo, "\n"), false)
				notify.success("TinkerScript - 人体画布", "成功！纹身组合已导出到：Exported_TattooCombo.txt", 3000)
			else
				ImGui.SetClipboardText(table.concat(ExpTatCombo, "\n"))
				notify.success("TinkerScript - 人体画布", "成功！纹身组合已导出到剪贴板", 3000)
			end
		end if ImGui.IsItemHovered() then ImGui.SetTooltip("把当前纹身组合导出到剪贴板") end

		ImGui.SameLine() Rplus_Config.ComboToFile = ImGui.Checkbox("导出到文件", Rplus_Config.ComboToFile) if ImGui.IsItemHovered() then ImGui.SetTooltip("开启后把当前纹身数据写入文件。") end

		if Rplus_Config.ComboToFile then
		ImGui.SameLine()
		ImGui.SetNextItemWidth(360)
			if ImGui.Button("复制路径") then
				ImGui.SetClipboardText("%AppData%/YimMenuV2/scripts/TinkerScripts/HumanCanvas/Exported_TattooCombo.txt")
				notify.success("TinkerScript - 人体画布", "导出纹身的文件路径已复制到剪贴板！", 3000)
			end if ImGui.IsItemHovered() then ImGui.SetTooltip("Copies Exported Tattoos \"File\" path to clipboard.") end
		end
		ImGui.EndGroup()
		--ImGui.EndChild()

		ImGui.Spacing()

		if ImGui.Button("全部应用", 89) then ImGui.OpenPopup("##warnfullbodytat") end if ImGui.IsItemHovered() then ImGui.SetTooltip("Applies All Tattoos.\nThey won't display all at once. Actual combos look better.") end

		if ImGui.BeginPopupModal("##warnfullbodytat", nil, 65) then
			ImGui.Text("确定要应用全部纹身吗？")
			ImGui.Spacing()
			if ImGui.Button("是") then
				for i = 0, 53 do
					stats.set_int("MPX_TATTOO_FM_CURRENT_"..i, -1)
				end
				notify.success("TinkerScript - 人体画布", "成功！已应用全部纹身。", 3000)
				ImGui.CloseCurrentPopup()
			end
			ImGui.SameLine() if ImGui.Button("否") then
				ImGui.CloseCurrentPopup()
			end
			ImGui.EndPopup()
		end

		ImGui.SameLine()

		if ImGui.Button("全部移除") then ImGui.OpenPopup("##warnremovetats") end if ImGui.IsItemHovered() then ImGui.SetTooltip("幸运钻石是谁？") end

		if ImGui.BeginPopupModal("##warnremovetats", nil, 65) then
			ImGui.Text("确定要移除全部纹身吗？")
			ImGui.Spacing()
			if ImGui.Button("是") then
				for i = 0, 53 do
					stats.set_int("MPX_TATTOO_FM_CURRENT_"..i, 0)
				end
				notify.success("TinkerScript - 人体画布", "成功！已移除全部纹身。", 3000)
				ImGui.CloseCurrentPopup()
			end
			ImGui.SameLine() if ImGui.Button("否") then
				ImGui.CloseCurrentPopup()
			end
			ImGui.EndPopup()
		end

		ImGui.Spacing()
		ImGui.Text("面绘") if ImGui.IsItemHovered() then ImGui.SetTooltip("Allows you to stack face paints.\nSelected face paint will be applied automatically.\nOpacity works only for the items on the first list.") end ImGui.Separator()ImGui.Spacing()
		commandmgr.get_command("humcanv_fp1list"):draw()
		commandmgr.get_command("humcanv_fp2list"):draw() if ImGui.IsItemHovered() then ImGui.SetTooltip("If any of these don't get applied, buy any of them first (Cheapest one is \"Vertical Stripe\").") end

		ImGui.SetNextItemWidth(100)
		Rplus_Config.FacePaint_Opacity, fpchange = ImGui.SliderFloat("面绘/妆容不透明度", Rplus_Config.FacePaint_Opacity, 0.0, 1.0) if ImGui.IsItemHovered() then ImGui.SetTooltip([[Looks cool ¯\_(°-°)_/¯]]) end
		if fpchange then stats.set_float("MPX_HEADBLEND_OVERLAY_MAKEUP_PC", Rplus_Config.FacePaint_Opacity) end

		ImGui.Spacing()
		ImGui.Text("发型")ImGui.Separator()ImGui.Spacing()

		ImGui.BeginGroup()
		if ImGui.TreeNodeEx("发色  ##haircol"..nomoretreeplease, 8219) then
			ImGui.SameLine(0, 14)

			ImGui.Text("当前： "..stats.get_int(HC_HairColor.HighlightOnOff.Stat)) if ImGui.IsItemHovered() then ImGui.SetTooltip(string.format("This is you real hair color value.\nHovering over the colors below will display the value from Barber Shops.", i)) end

			ImGui.SameLine() HC_HairColor.HiddenColToggle = ImGui.Checkbox("隐藏颜色", HC_HairColor.HiddenColToggle)
			ImGui.SameLine() HC_HairColor.HighlightOnOff.Toggle = ImGui.Checkbox("挑染", HC_HairColor.HighlightOnOff.Toggle)
			for i, HairB in ipairs(HC_HairColor.Regular) do
				if (i - 1) % 12 ~= 0 then ImGui.SameLine() end

				if ImGui.ColorButton("##haircol"..HairB.statVal, HairB.bCol, 64) then
					stats.set_int(HC_HairColor.HighlightOnOff.Stat, HairB.statVal)
					if not HC_HairColor.HiddenColToggle then
						notify.success("TinkerScript - 人体画布", "成功！已应用发色： "..i, 3000)
					else
						notify.success("TinkerScript - 人体画布", "成功！已应用发色： "..stats.get_int(HC_HairColor.HighlightOnOff.Stat), 3000)
					end
				end if ImGui.IsItemHovered() then if not HC_HairColor.HiddenColToggle then ImGui.SetTooltip(string.format("颜色（%d / 48）", i)) else ImGui.SetTooltip(string.format("颜色 %d", HairB.statVal)) end end
			end
		end
		ImGui.EndGroup()

		ImGui.BeginGroup()
		if HC_HairColor.HiddenColToggle then
			--ImGui.NewLine()
			for i, HairB in ipairs(HC_HairColor.Hidden) do
				if (i - 1) % 12 ~= 0 then ImGui.SameLine() end

				if ImGui.ColorButton("##haircol"..HairB.statVal, HairB.bCol, 64) then
					stats.set_int(HC_HairColor.HighlightOnOff.Stat, HairB.statVal)
					notify.success("TinkerScript - 人体画布", "成功！已应用隐藏发色： "..stats.get_int(HC_HairColor.HighlightOnOff.Stat), 3000)
				end if ImGui.IsItemHovered() then ImGui.SetTooltip(string.format("颜色 %d", HairB.statVal)) end
			end
		end

		if HC_HairColor.HighlightOnOff.Toggle then
			HC_HairColor.HighlightOnOff.Stat = "MPX_SEC_HAIR_TINT"
		else
			HC_HairColor.HighlightOnOff.Stat = "MPX_HAIR_TINT"
		end

		ImGui.EndGroup()

		ImGui.EndTabItem()
	end
	ImGui.EndTabBar()
end)

local Stngsplus_Config = {
	CloseBCSonUnload = TS_Settings.CloseBCSonUnload or true,
	LoadSettings = TS_Settings.LoadSettings or false
}

local function CloseBCSonUnload()
	if Stngsplus_Config.CloseBCSonUnload then
		FileMgr.WriteFileContent(TinkerPath.."/TinkerScripts/Settings/BlockCloudSaves/NoSave.txt", "关闭", false)
	end
	return Stngsplus_Config.CloseBCSonUnload
end

local function SaveSettings(tabl) -- Also from stackoverflow (darkfrei) but just what I need. Could've done more progress on the script but decided to mess around with this thing (I wish i didn't). I don't even know if this is a serializer anymore
    local set = {}
	local order = { -- It seems that this is the only way to "preserve" the order
		"HGWHrestock",
		"HGWHmaxgoods",
		"HGsetgood",
		"HGgoodtype",
		"WHsetgood",
		"WHgoodtype",
		"MCresup",
		"MCrestock",
		"NCgoods",
		"NoClipState",
		"NoClipWindowTop",
		"LoadSettings",
		"CloseBCSonUnload"
	}
    for _, key in ipairs(order) do
        table.insert(set, key.." = "..tostring(tabl[key]))
    end
    return "TS_Settings = {}\n".."TS_Settings."..table.concat(set, "\nTS_Settings.") -- previously a regular table
end

local function LoadSavedSettings() -- My brain started melting since last function, i feel like somethings wrong but i dont know what
	load(TS_PATH_Settings())()
	Stngsplus_Config.LoadSettings = TS_Settings.LoadSettings
	Stngsplus_Config.CloseBCSonUnload = TS_Settings.CloseBCSonUnload
	NoClipWindowTop = TS_Settings.NoClipWindowTop
	commandmgr.get_command("noclip_onscreen"):set_value(TS_Settings.NoClipState)
	commandmgr.get_command("HGWH_restock"):set_value(TS_Settings.HGWHrestock)
	commandmgr.get_command("HGWH_maxgoods"):set_value(TS_Settings.HGWHmaxgoods)
	commandmgr.get_command("HG_setgood"):set_value(TS_Settings.HGsetgood)
	commandmgr.get_command("WH_setgood"):set_value(TS_Settings.WHsetgood)
	commandmgr.get_command("MC_resup"):set_value(TS_Settings.MCresup)
	commandmgr.get_command("MC_restock"):set_value(TS_Settings.MCrestock)
	commandmgr.get_command("NC_goods"):set_value(TS_Settings.NCgoods)
	commandmgr.get_command("HG_goodtype"):set_value(TS_Settings.HGgoodtype)
	commandmgr.get_command("WH_goodtype"):set_value(TS_Settings.WHgoodtype)
end

TS_SettingsPlus:imgui(function()

	if ImGui.BeginChild("##setttingschild", 271, 132, 1) then

		CenteredText("子菜单设置", false, true) ImGui.Spacing()

		if ImGui.Button("保存当前设置") then
			FileMgr.WriteFileContent(TinkerPath.."/TinkerScripts/Settings/TS_Settings.lua", SaveSettings({
				HGWHrestock = commandmgr.get_command("HGWH_restock"):get_value(),
				HGWHmaxgoods = commandmgr.get_command("HGWH_maxgoods"):get_value(),
				HGsetgood = commandmgr.get_command("HG_setgood"):get_value(),
				WHsetgood = commandmgr.get_command("WH_setgood"):get_value(),
				MCresup = commandmgr.get_command("MC_resup"):get_value(),
				MCrestock = commandmgr.get_command("MC_restock"):get_value(),
				NCgoods = commandmgr.get_command("NC_goods"):get_value(),
				HGgoodtype = commandmgr.get_command("HG_goodtype"):get_value(),
				WHgoodtype = commandmgr.get_command("WH_goodtype"):get_value(),
				NoClipState = commandmgr.get_command("noclip_onscreen"):get_value(),
				NoClipWindowTop = NoClipWindowTop,
				LoadSettings = Stngsplus_Config.LoadSettings,
				CloseBCSonUnload = Stngsplus_Config.CloseBCSonUnload
			}))
		end

		if ImGui.Button("加载已保存设置") then
			LoadSavedSettings()
		end

		Stngsplus_Config.LoadSettings = ImGui.Checkbox("启动时自动加载已保存设置", Stngsplus_Config.LoadSettings)

	end ImGui.EndChild()

	if ImGui.BeginChild("##cloudsaveschild", 296, 196, 1) then

		CenteredText("阻止云存档", false, true) ImGui.Spacing()

		ImGui.Text("云存档状态： ")

		if TS_PATH_NoCloudSave() == "" then
			ImGui.SameLine(0, 0) ImGui.TextColored(0, 1, 1, 1, "就绪")
		elseif TS_PATH_NoCloudSave() == "已禁用" then
			ImGui.SameLine(0, 0) ImGui.TextColored(1, 0, 0, 1, "OFF")
		elseif TS_PATH_NoCloudSave() == "已启用" then
			ImGui.SameLine(0, 0) ImGui.TextColored(0, 1, 0, 1, "ON")
		elseif TS_PATH_NoCloudSave() == "已关闭" or TS_PATH_NoCloudSave() == "关闭" or TS_PATH_NoCloudSave() == "禁用" or TS_PATH_NoCloudSave() == "启用" then
			ImGui.SameLine(0, 0) ImGui.TextDisabled("WAITING")
		end

		ImGui.SameLine()
		if TS_PATH_NoCloudSave() ~= "" then ImGui.TextDisabled("（？）") end if ImGui.IsItemHovered() then ImGui.SetTooltip("ON: Cloud Saves ENABLED\nOFF: Cloud Saves DISABLED\n\nWAITING: BlockCloudSaves.bat is not running") end
		ImGui.Spacing()

		if ImGui.Button("禁用云存档") then
			FileMgr.WriteFileContent(TinkerPath.."/TinkerScripts/Settings/BlockCloudSaves/NoSave.txt", "禁用", false)
		end

		if ImGui.Button("启用云存档") then
			FileMgr.WriteFileContent(TinkerPath.."/TinkerScripts/Settings/BlockCloudSaves/NoSave.txt", "启用", false)
		end

		ImGui.Spacing()ImGui.Spacing()
		if ImGui.Button("复制路径##blocksaves") then
			ImGui.SetClipboardText("%AppData%/YimMenuV2/scripts/TinkerScripts/Settings/BlockCloudSaves/BlockCloudSaves.bat")
			notify.success("TinkerScript - 阻止云存档", "BlockCloudSaves.bat 的路径已复制到剪贴板！", 3000)
		end

		Stngsplus_Config.CloseBCSonUnload = ImGui.Checkbox("菜单卸载时关闭此工具", Stngsplus_Config.CloseBCSonUnload) if ImGui.IsItemHovered() then ImGui.SetTooltip("Should BlockCloudSaves.bat close itself on menu unload? (Enabled by default)\nThis will remove the firewall rule added by the tool, so you don't have problems joining Online in your next game session.") end

	end ImGui.EndChild()

end)

if Stngsplus_Config.LoadSettings then LoadSavedSettings() end

event.register_handler(menu_event.Unload, function()
	CloseBCSonUnload()
end)