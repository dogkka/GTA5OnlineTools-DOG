local BASE = 1845740

local selected_warehouse = 0
local selected_amount = 30


local function get_capacity(type)
    if type == 18 then
        return 111
    end

    if type == 17 then
        return 16
    end

    return nil
end



local function get_warehouse(slot)
    local base = BASE + (slot * 6)

    local wh = {}

    wh.slot = slot
    wh.type = ScriptGlobal(base):get_int()
    wh.amount = ScriptGlobal(base+1):get_int()
    wh.state = ScriptGlobal(base+3):get_int()

    wh.capacity = get_capacity(wh.type)

    wh.amount_global = base+1
    wh.state_global = base+3

    return wh
end



local function stock_display(wh)
    if not wh.capacity then
        return "Unknown"
    end

    if wh.amount > wh.capacity then
        return "Unknown (Raw "..wh.amount..")"
    end

    return tostring(wh.amount)
end



local function dump_warehouses()
    log.info("===== WAREHOUSES =====")

    for slot=0,4 do
        local wh = get_warehouse(slot)

        if wh.type ~= 0 then
            log.info(
                string.format(
                    "Slot %d | Type %d | Stored %s | Capacity %s",
                    wh.slot,
                    wh.type,
                    stock_display(wh),
                    tostring(wh.capacity)
                )
            )
            notify.info(
                "Warehouse Slot "..wh.slot,
                string.format(
                    "Capacity: %s\nStored: %s",
                    tostring(wh.capacity or "?"),
                    stock_display(wh)
                )
            )

        end

    end
    log.info("====================")
end



local function set_stock()
    local wh =
        get_warehouse(selected_warehouse)

    if not wh.capacity then
        notify.error(
            "Warehouse",
            "Unknown capacity"
        )
        return
    end

    if selected_amount > wh.capacity then
        notify.error(
            "Warehouse",
            "Maximum "..wh.capacity
        )
        return
    end

    notify.info(
        "Warehouse",
        string.format(
            "Setting stock in warehouse %d to %d",
            selected_warehouse,
            selected_amount
        )
    )

    ScriptGlobal(
        wh.amount_global
    ):set_int(selected_amount)

    ScriptGlobal(
        wh.state_global
    ):set_int(1)

    notify.success(
        "Warehouse",
        "Stock updated"
    )
end


script.run_in_callback(function()
    natives.load_natives()
    log.info([[

 	⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⠶⢦⡀⠀⠀⢀⣀⡀⠀⠀
	⠀⠀⠀⣀⣤⣄⡀⠀⠀⠀⠀⠀⠀⢠⠖⠒⢆⠀⠀⠀⡏⠀⠀⠀⠙⣇⡞⠋⠙⢿⣷⠀
	⠀⠀⢀⡟⠁⠉⠛⣧⠀⠀⠀⠀⣠⠇⠀⠀⠈⢇⠀⢸⠁⠀⠀⠀⠀⡟⠀⠀⠀⠀⣿⠃
	⠀⠀⣾⠃⠀⠀⠀⠈⠁⠒⠊⠉⠁⠀⠀⠀⠀⠘⢢⡈⡆⠀⠀⠀⣰⠃⠀⠀⠀⠀⡟⠀
	⠀⣀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡴⠋⠙⠲⡄⠀⠁⠀⠀⠀⢀⣞⠁⠀   Thank you for downloading!
	⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠀⡼⠁⠀⠀⠀⢧⠀⠀⠀⠀⠐⠋⠀⢱⡀   Warehouse Manager v1.0
	⡇⠀⠀⠀⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠃⠀⣏⠀⠸⣄⡤⠇⠀⠀⢀⡞⠀⠀⠀⢠⠇
	⡇⠀⠀⠀⠉⠀⠀⢠⠀⣠⣄⣰⠀⠀⠀⠀⠀⠈⢧⡀⠀⠀⠀⠀⠀⢸⡀⠀⠀⡰⠃⠀   Created by HeXif <3
	⠙⣄⠀⠀⠀⠀⠀⠈⠛⠁⠀⠀⠀⠀⠀⣀⣀⣴⠿⠃⠀⠀⠀⠀⠀⢀⡛⠒⠚⠁⠀⠀
	⠀⠈⠳⠤⣀⣀⣀⣀⣀⣠⡤⠤⠔⠒⠈⠁⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⠀⠀⠀⠀⠀⠀   https://github.com/xHeXifx
	⠀⠀⠀⠀⣠⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡖⠦⠤⣄⣀⡤⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀   https://hexif.vercel.app
	⠀⠀⢀⡞⠁⠀⡄⠀⠀⠀⠀⠀⠀⠀⠀⢠⡛⣆⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
	⠀⠸⣇⣀⣴⢀⣧⠀⠀⠀⠀⠀⠀⠀⢀⡏⠣⣈⠙⠉⢁⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
	⠀⠀⠀⠀⠈⠉⠈⡇⢰⠒⠒⠒⢺⣠⠏⠀⠀⠈⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
	⠀⠀⠀⠀⠀⠀⠀⠙⠚⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
]])

    local wh =
        get_warehouse(selected_warehouse)

    notify.info(
        "Warehouse Editor",
        string.format(
            "Current set warehouse: %d\nCapacity: %s\nStored: %s",
            selected_warehouse,
            tostring(wh.capacity or "?"),
            stock_display(wh)
        )
    )
    dump_warehouses()



    while true do
        if PAD.IS_DISABLED_CONTROL_JUST_PRESSED(0,194)
        or PAD.IS_CONTROL_JUST_PRESSED(0,194) then


            set_stock()

            script.yield(1000)
        end

        script.yield(100)
    end
end)